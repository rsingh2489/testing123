package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class UpdateForgettedPassword extends Activity {
    private static String NAMESPACE = "http://tempuri.org/";
    private static String SOAP_ACTION1 = "http://tempuri.org/UpdateForgetPassword";
    private  static  String METHOD_NAME1="UpdateForgetPassword";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    String GetPswrd;
    String MobNo,UId;
    ProgressDialog pDialog;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_update_forgetted_password);

        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butHome);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(UpdateForgettedPassword.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });

        final EditText TxtMobNo=(EditText)findViewById(R.id.edt_MobNochg);
        if(getIntent().hasExtra("UserId")) {
            String messageId = getIntent().getStringExtra("UserId").toString();
            UId=messageId;
            TxtMobNo.setText(messageId);
            TxtMobNo.setEnabled(false);
        }

        if(getIntent().hasExtra("MobileNo")) {
            String message = getIntent().getStringExtra("MobileNo").toString();
            MobNo=message;
        }

        //=======================================
        final EditText myPwd = (EditText) findViewById(R.id.edt_ConfrmMobnoUpd);
        myPwd.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
                EditText myPwdAddd = (EditText) findViewById(R.id.edt_NewPwdUpd);
                String Pwdnewd = myPwdAddd.getText().toString();

                /////////////////////////password Validation//////
                String Exppressionn = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
                if(!Pwdnewd.matches(Exppressionn))
                {
                    myPwdAddd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");

                }
                ////////////////////////End Validation/////////////
                            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });



        Button buttonSub = (Button) findViewById(R.id.Btn_SubmitPwd);
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                pd = new ProgressDialog(UpdateForgettedPassword.this);
                pd.setTitle("Please Wait....");
                pd.show();

                ///Validation////////////////////
                final EditText UName = (EditText) findViewById(R.id.edt_MobNochg);
                final String GetUName = UName.getText().toString();
                if (GetUName.equals("") || GetUName.equals("0")) {
                    UName.setError("Enter User Id");
                    return;
                }

                final EditText Email = (EditText) findViewById(R.id.edt_NewPwdUpd);
                final String GetEmail = Email.getText().toString();
                if (GetEmail.equals("") || GetEmail.equals("0")) {
                    Email.setError("Enter New Password");
                    return;
                }
                final EditText Pwd = (EditText) findViewById(R.id.edt_ConfrmMobnoUpd);
                final String GetPwd = Pwd.getText().toString();
                if (GetPwd.equals("") || GetPwd.equals("0")) {
                    Pwd.setError("Enter Confirm Password");
                    return;
                }

                final EditText Pswrd = (EditText) findViewById(R.id.edt_NewPwdUpd);

                GetPswrd = Pswrd.getText().toString();
                String Expn =
                        "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,10})";

                if (GetPswrd.matches(Expn) && GetPswrd.length() > 0) {
                   /* EmailId.setText("valid email");*/
                } else {
                    Pswrd.setError("invalid New Password");
                    return;
                }
                EditText myPwdCon = (EditText) findViewById(R.id.edt_ConfrmMobnoUpd);
                String getNewPwdCon = myPwdCon.getText().toString();
                if (GetPswrd.equals(getNewPwdCon)) {

                } else {
                    myPwdCon.setError("Confirm Password Not Matching..!!");
                    return;
                }
////////////end validation

                // Call web service


                //=================== ====================
                SoapAccessTask task = new SoapAccessTask();
                task.execute();

                //=======================================
                ///////////////Button Exit

            }
        });

    }
    ///////////////Start async task///////
    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("Password", GetPswrd);
                request.addProperty("PhoneNo", MobNo);
                request.addProperty("Userid", UId);

                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(UpdateForgettedPassword.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(UpdateForgettedPassword.this);
                            pDialog.setMessage("Please Wait ...");
                            pDialog.setIndeterminate(false);
                            pDialog.setCancelable(true);
                            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();

                        if (abb.equals("1")) {
                            Toast.makeText(UpdateForgettedPassword.this,
                                    "Password Changed Successfully!!", Toast.LENGTH_LONG)
                                    .show();
                            Intent inte = new Intent(getApplicationContext(),LoginActivity.class);
                            startActivity(inte);
                        } else if (abb.equals("2")) {
                            Toast.makeText(UpdateForgettedPassword.this,
                                    "User Doesn't Exists!!", Toast.LENGTH_LONG)
                                    .show();
                        } else {
                            Toast.makeText(UpdateForgettedPassword.this,
                                    "Some Error occured!!", Toast.LENGTH_LONG)
                                    .show();
                        }

            }
        }}

    ///////////End async task //////////

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_update_forgetted_password, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
