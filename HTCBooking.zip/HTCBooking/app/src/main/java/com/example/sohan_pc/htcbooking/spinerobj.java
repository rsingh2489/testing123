package com.example.sohan_pc.htcbooking;

/**
 * Created by Sohan-pc on 9/22/2015.
 */
public class spinerobj {
    private  String databaseId;
    private String databaseValue;

    public spinerobj ( String databaseId , String databaseValue ) {
        this.databaseId = databaseId;
        this.databaseValue = databaseValue;
    }

    public String getId () {
        return databaseId;
    }

    public String getValue () {
        return databaseValue;
    }

    @Override
    public String toString () {
        return databaseValue;
    }
}
