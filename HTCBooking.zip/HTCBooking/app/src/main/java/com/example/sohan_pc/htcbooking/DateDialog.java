package com.example.sohan_pc.htcbooking;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Sohan-pc on 9/10/2015.
 */

public class DateDialog extends DialogFragment implements DatePickerDialog.OnDateSetListener {
    final Calendar myCalendar = Calendar.getInstance();
    EditText TxtDate;
    public DateDialog(View view){
    TxtDate=(EditText)view;
            }
    public Dialog onCreateDialog(Bundle SavedInstanceState){
     final Calendar c=Calendar.getInstance();

        int year=c.get(Calendar.YEAR);
        int month=c.get(Calendar.MONTH);
        int day=c.get(Calendar.DAY_OF_MONTH);
return new DatePickerDialog(getActivity(),this,year,month,day);

    }


    public  void  onDateSet(DatePicker view,int year,int month,int day){
        String myFormat = "dd MMMM yyyy"; // your format
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.getDefault());
        TxtDate.setText(sdf.format(myCalendar.getTime()));
     // String Date=day+"/"+(month+1)+"/"+year;
       /* String DateSel=year+"-"+(month+1)+"-"+day;*/
       // DatePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
      /*  long date = System.currentTimeMillis();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat sdfTime = new SimpleDateFormat("h:mm a");
        String dateString = sdf.format(date);
        String TimeString=sdfTime.format(date);
        String CDate=TimeString;
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        String sday = (""+day);
        String smonth=("-"+month);
        String syear=("-"+year);
        String y=(""+sday+smonth+syear);
        Date pickerdate = formatter.parse(y);
        final  String DateSelected=
        if(dateString.compareTo(DateSelected)>0){
            TxtDate.setText(dateString);
        }else if(dateString.compareTo(DateSelected)<0){
            TxtDate.setText(DateSelected);
        }else if(dateString.compareTo(DateSelected)==0){
            TxtDate.setText(DateSelected);
        }*/
      /*  TxtDate.setText(DateSel);*/

    }

}
