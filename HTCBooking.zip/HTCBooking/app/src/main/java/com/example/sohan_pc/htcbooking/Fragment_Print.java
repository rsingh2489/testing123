package com.example.sohan_pc.htcbooking;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Deepak on 11/4/2015.
 */
public class Fragment_Print extends Fragment {
@Nullable

    public View OnCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){

    return super.onCreateView(inflater,container,savedInstanceState);
}
}
