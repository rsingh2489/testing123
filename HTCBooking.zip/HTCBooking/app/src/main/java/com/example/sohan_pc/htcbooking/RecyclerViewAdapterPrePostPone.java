package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.List;

/**
 * Created by Deepak on 6/28/2016.
 */
public class RecyclerViewAdapterPrePostPone  extends RecyclerView.Adapter<RecyclerViewAdapterPrePostPone.MyViewHolder>  {
    private List<ModalPrint> modalListP;
    private static String SOAP_ACTION1 = "http://tempuri.org/GetDetailsPrepostpone";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetDetailsPrepostpone";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    ModalPrint mod1;
    public Button PrepostBooked;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, year, genre,dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo;

        public MyViewHolder(final View view) {
            super(view);

            title = (TextView) view.findViewById(R.id.Custname);
            genre = (TextView) view.findViewById(R.id.CustAdd);
            year = (TextView) view.findViewById(R.id.Email);
            dest_name=(TextView) view.findViewById(R.id.destname);
            pay_amount=(TextView) view.findViewById(R.id.pay_amount);
            noofunits=(TextView) view.findViewById(R.id.noofunits);
            Srno=(TextView) view.findViewById(R.id.Srno);
            Cat=(TextView) view.findViewById(R.id.Category);
            UnitNo=(TextView) view.findViewById(R.id.noofunits);
            Datefrom=(TextView) view.findViewById(R.id.checindate);
            DateTo=(TextView) view.findViewById(R.id.checkoutdate);
            PrepostBooked=(Button)view.findViewById(R.id.Btn_Prepostpone);


            PrepostBooked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                     mod1 = modalListP.get(getAdapterPosition());
                    // Call web service
                    //=================== ====================
                    SoapAccessTask task = new SoapAccessTask();
                            task.execute();

                }
            });


        }

    }



    public RecyclerViewAdapterPrePostPone(List<ModalPrint> modalListP) {
        this.modalListP = modalListP;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_list_view_prepostpone, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ModalPrint movieP = modalListP.get(position);

        holder.title.setText(movieP.getTitle());
        holder.genre.setText(movieP.getGenre());
        holder.year.setText(movieP.getname());
        holder.dest_name.setText(movieP.getDest_name());
        holder.pay_amount.setText(movieP.getpay_amount());
        holder.noofunits.setText(movieP.getUnitNo());
        holder.Cat.setText(movieP.getCat());
        holder.UnitNo.setText(movieP.getUnitNo());
        holder.Datefrom.setText(movieP.getDatefrom());
        holder.DateTo.setText(movieP.getDateTo());
        holder.Srno.setText(movieP.getSrno());

    }

    @Override
    public int getItemCount() {
        return modalListP.size();
    }


    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("CustId", mod1.getname());
                request.addProperty("UserLogin",mod1.getUserLgin());
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {


            }
            return webResponse;

        }

        protected void onPreExecute() {
//                            pDialog = new ProgressDialog(RecyclerViewAdapterPrePostPone.this);
//                            pDialog.setMessage("Please Wait ...");
//                            pDialog.setIndeterminate(false);
//                            pDialog.setCancelable(true);
//                            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
//                            pDialog.dismiss();

            if (result != null) {
                SubmitRes = result.toString();

                if (mod1.getpay_amount().equals("0")) {
                    PrepostBooked.setText("Already Cancelled");
                }
                else  if (SubmitRes.equals("1")) {
                    Toast.makeText(PrepostBooked.getContext(),
                            "Sorry..! You cannot Preponed and postponed Booking..", Toast.LENGTH_LONG)
                            .show();
                }
                else if (SubmitRes.equals("2")) {
//                                             else if (SubmitRes.equals("srno")) {
                    Toast.makeText(PrepostBooked.getContext(),
                            "Sorry..! You cannot Prepone and postpone because you have already crossed 48 hours before check in..", Toast.LENGTH_LONG)
                            .show();

                } else if (SubmitRes.equals("3")) {
                    PrepostBooked.setText("Already Pre/Postponed");
                    Toast.makeText(PrepostBooked.getContext(),
                            "Sorry..! You have already Preponed and postponed Once..", Toast.LENGTH_LONG)
                            .show();
                }
                else if (SubmitRes.equals("4")) {
                    Toast.makeText(PrepostBooked.getContext(),
                            "Some Error Occured!!", Toast.LENGTH_LONG)
                            .show();
                }
                else  if (SubmitRes.contains("srno"))
//                                             else  if (SubmitRes.contains("2"))
                {

                    Intent inte = new Intent(PrepostBooked.getContext(), PrePostPoneActivity.class);
                    inte.putExtra("DestName", mod1.getDest_name());
                    inte.putExtra("Category",mod1.getCat());
                    inte.putExtra("NoOfrooms", mod1.getUnitNo());
                    inte.putExtra("BookingFrm", mod1.getDatefrom());
                    inte.putExtra("BookingTo",  mod1.getDateTo());
                    inte.putExtra("CustName", mod1.getTitle());
                    inte.putExtra("CustId",mod1.getname());
                    inte.putExtra("NewDateFrm",  mod1.getDatefrom());
                    inte.putExtra("NewDtTo",mod1.getDateTo());
                    inte.putExtra("Srno",   mod1.getSerialNo());
                    inte.putExtra("UserId", mod1.getUserLgin());
                    inte.putExtra("EmailId", mod1.getGenre());
                    inte.putExtra("MobileNo", mod1.getMobileNo());
                    PrepostBooked.getContext().startActivity(inte);
                }
            }
        }

    }

}
