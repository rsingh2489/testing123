package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class cancellationActivity extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/GetDetails";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetDetails";
    //////////////Already cancel/////////////
    private static String SOAP_ACTION2 = "http://tempuri.org/Show_Cancellation_Details";
    private static String METHOD_NAME2 = "Show_Cancellation_Details";
    ////////////////////////////////////////

    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    private static String SubmitResForChild = "pp";
    String messagecustid,noofunits,Email,MobileNo;
    private List<Modal> movieList = new ArrayList<>();
    private List<Modal> movieChildList = new ArrayList<>();
    public RecyclerView recyclerView;
    public RecyclerViewAdapter mAdapter;
    String EmailID,IsMob;
    ProgressDialog pDialog;
    String namecustid,name1,idModule,Dest_name,pay_amount,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,UserLgin,PrePost,noOfRows,RoomNos,Entrydate,Paymodeno,Paymode,PayRecdBy;
    String  cust_id,prebookfrm,prebookto,predatefrm,preDateTo,datefrom,dateTo,transactionDate,NoOfRooms,unitType,Rateperunit,amount,amountPaid,PaymentMod;

    // Session Manager Class
    SessionManagement session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_cancellation);

                                    recyclerView = (RecyclerView) findViewById(R.id.myList);
                                    mAdapter = new RecyclerViewAdapter(movieList);
                                    mAdapter.notifyDataSetChanged();
                                    recyclerView.setHasFixedSize(true);
                                    RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                                    recyclerView.setLayoutManager(mLayoutManager);
                                    recyclerView.addItemDecoration(new DividerItemDecoration(cancellationActivity.this, LinearLayoutManager.HORIZONTAL));
                                    recyclerView.setItemAnimator(new DefaultItemAnimator());
                                    recyclerView.setAdapter(mAdapter);

        // Session class instance
        session = new SessionManagement(getApplicationContext());
      //  Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();
        // get user data from session
        HashMap<String, String> user = session.getUserDetails();
        // name
        String name = user.get(SessionManagement.KEY_NAME);
        // email
        String email = user.get(SessionManagement.KEY_EMAIL);
        // mobile
        String mobile = user.get(SessionManagement.KEY_MOBILE);
        if (getIntent().hasExtra("MobileNo")) {
            messagecustid = getIntent().getStringExtra("MobileNo").toString();
        }
        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            if (messageMail.contains("/")) {
                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
            }

            else
            EmailID=messageMail;
        }
        if (getIntent().hasExtra("Contactno")) {

            String messageConctno = getIntent().getStringExtra("Contactno").toString();
            if (messageConctno.equals("1"))
            {

            }
            else
            {
                IsMob=messageConctno;
            }
        }
        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);
        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    session.logoutUser();
                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                    startActivity(inte);
                } catch (Exception e)
                {

                    Toast.makeText(cancellationActivity.this, "Please try again !!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(),NavigationScreen .class);
                    inte.putExtra("MobileNo", messagecustid);
                    inte.putExtra("MailId", EmailID);
                    inte.putExtra("Contactno", IsMob);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(cancellationActivity.this, "Please try again !!", Toast.LENGTH_SHORT).show();

                }
            }
        });
        GetDetailsAsynctask getDetailsTask = new GetDetailsAsynctask();
        getDetailsTask.execute();

    }

    public void showcancelDetails(final String Cust_Id, final TextView name,final TextView preboodatefrm,final TextView prebookdatTo,final TextView preDatefrm,final TextView preDateTo, final  TextView dateFrom, final TextView dateTo, final TextView trasationOnDate,
                                  final TextView NoOf_Room, final TextView unitCatg, final TextView ratePer_Unit, final TextView refundedAmount, final TextView AmtPaid
    , final TextView _PayMod)
    {

        new Thread() {
            @Override
            public void run() {

                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
                request.addProperty("CustomerID",Cust_Id);

                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                    //this is the actual part that will call the webservice
                    androidHttpTransport.call(SOAP_ACTION2, envelope);
                    // Get the SoapResult from the envelope body.
                    SoapObject result = (SoapObject) envelope.bodyIn;

                    if (result != null) {
                        //Get the first property and change the label text
                        SubmitResForChild = result.getProperty(0).toString();
                        ////////t1o replace spaces
                        String str1=SubmitResForChild.replace(" ","");
                        runOnUiThread(new Runnable() {
                                          @Override
                                          public void run() {
                                              try {
//                                    JSONArray jsonArray = new JSONArray(SubmitResForChild);
                                                  JSONObject jsonObject = new JSONObject(SubmitResForChild);

                                                  if (jsonObject != null) {
                                                      name.setText(jsonObject.getString("Cust_id"));
                                                      preboodatefrm.setText(jsonObject.getString("date_from"));
                                                      prebookdatTo.setText(jsonObject.getString("date_to"));
                                                      preDatefrm.setText(jsonObject.getString("current_date_from"));
                                                      preDateTo.setText(jsonObject.getString("current_date_to"));
                                                      dateFrom.setText(jsonObject.getString("Date_from"));
                                                      dateTo.setText(jsonObject.getString("Date_To"));
                                                      trasationOnDate.setText(jsonObject.getString("Transaction_Date"));
                                                      NoOf_Room.setText(jsonObject.getString("No_Of_Rooms_Booked"));
                                                      unitCatg.setText(jsonObject.getString("Unit_Type"));
                                                      ratePer_Unit.setText(jsonObject.getString("Rate Per Unit"));
                                                      refundedAmount.setText(jsonObject.getString("Amount"));
                                                      AmtPaid.setText(jsonObject.getString("Amount_Paid"));
                                                      _PayMod.setText(jsonObject.getString("PaymentMode"));
                                                  }
                                              }

                                              catch (JSONException e)
                                              {
                                                  Toast.makeText(cancellationActivity.this, "Please try again !!", Toast.LENGTH_SHORT).show();


                                              }
                                          }
                                      }
                        );
                    }
                } catch (Exception e)
                {
                    Toast.makeText(cancellationActivity.this, "Please try again !!", Toast.LENGTH_SHORT).show();

                }
            }
        }.start();

    }
/////////
// ////////end/////////////////////////////////
/////////////Async task  of method 1////////////
private class GetDetailsAsynctask extends AsyncTask<String, Void, String> {
    @Override
    protected String doInBackground(String... params) {
        String webResponse = "";
        try {
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
            request.addProperty("UserID", messagecustid);
            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.call(SOAP_ACTION1, envelope);
            SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
            webResponse = response.toString();

        } catch (Exception e) {
            Toast.makeText(cancellationActivity.this, "Please try again", Toast.LENGTH_SHORT).show();
        }
        return webResponse;

    }

    protected void onPreExecute() {
        pDialog = new ProgressDialog(cancellationActivity.this);
        pDialog.setMessage("Please Wait ...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(true);
        pDialog.show();
        super.onPreExecute();
    }

    protected void onPostExecute(String result) {
        pDialog.dismiss();
        if (result != null) {
            //Get the first property and change the label text
            SubmitRes = result.toString();
            ////////to replace spaces
            String str1=SubmitRes.replace(" ","");
                    try {
                        JSONArray jsonArray = new JSONArray(SubmitRes);
                        Integer Arraylen=jsonArray.length();
                        if (jsonArray != null) {
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject youValue = jsonArray.getJSONObject(i);
                                idModule = youValue.getString("cust_name");
                                name1 = youValue.getString("cust_id");
                                Email=youValue.getString("cust_phone");
                                Dest_name=youValue.getString("dest_name");
                                pay_amount=youValue.getString("pay_amount");
                                Srno=youValue.getString("NewNo");
                                Cat=youValue.getString("unit_name");
                                UnitNo=youValue.getString("unit_no");
                                Datefrom=youValue.getString("date_from");
                                DateTo=youValue.getString("date_to");
                                cnlFrm=youValue.getString("gg");
                                SerialNo=youValue.getString("srno");
                                UserLgin=messagecustid;
                                PrePost=youValue.getString("pp");
                                RoomNos="";
                                if(!youValue.isNull("arrival_date"))
                                {
                                    RoomNos=youValue.getString("arrival_date");
                                }
                                else
                                {
                                    RoomNos="";
                                }

                                MobileNo=youValue.getString("Phone");
                                Entrydate=youValue.getString("entry_date");
                                Paymode=youValue.getString("pay_mode");
                                Paymodeno=youValue.getString("pay_mode_no");
                                PayRecdBy=youValue.getString("pay_rcvd_by");
                                //  String IPaddress=youValue.getString("entry_date");
                                noOfRows=Integer.toString(Arraylen);
                                //  Resorts.add(idModule);

                                Modal movie = new Modal(idModule,name1,Email,Dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,noOfRows,RoomNos,UserLgin,MobileNo,Entrydate,Paymode,Paymodeno,PayRecdBy,PrePost,
                                        cust_id,prebookfrm,prebookto,predatefrm,preDateTo,datefrom,dateTo,transactionDate,NoOfRooms,unitType,Rateperunit,amount,amountPaid,PaymentMod);
                                movieList.add(movie);

                            }
                        }
                        mAdapter.notifyDataSetChanged();

                    } catch (JSONException e) {
                        Toast.makeText(cancellationActivity.this, "Please try again !!", Toast.LENGTH_SHORT).show();

                    }
        }
    }}
    ////////////End Async task////////////





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cancellation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

   public void onBackPressed()
   {
       finish();
       Intent intent = new Intent(cancellationActivity.this, NavigationScreen.class);
       startActivity(intent);

   }

}


