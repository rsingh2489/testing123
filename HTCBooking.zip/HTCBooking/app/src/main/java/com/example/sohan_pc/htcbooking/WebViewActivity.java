package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewActivity extends Activity {

    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_web_view);

        webView = (WebView) findViewById(R.id.webview);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new InsideWebViewClient());
        final String GetUrl=(getIntent().getExtras().getString("URL"));
        webView.loadUrl(getIntent().getExtras().getString("URL"));

    }
    private class InsideWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

    @Override
    public void onPageFinished(WebView view, String url) {
        if(url.toLowerCase().contains("htcandroidws/responsetoandroid.aspx")){
            Uri uri=Uri.parse(url);
            if(uri.getQueryParameter("Status").toString().equals("success"))
            {
                Intent inte=new Intent(getApplicationContext(),GetRsponse.class);
                inte.putExtra("Status",uri.getQueryParameter("Status"));
                inte.putExtra("TransactionId",uri.getQueryParameter("TransactionId"));
                inte.putExtra("Firstname",uri.getQueryParameter("Firstname"));
                inte.putExtra("Mobile",uri.getQueryParameter("Mobile"));
                inte.putExtra("Email",uri.getQueryParameter("Email"));
                inte.putExtra("BookingDateFROM",uri.getQueryParameter("BookingDateFROM"));
                inte.putExtra("BookingDateTO",uri.getQueryParameter("BookingDateTO"));
                inte.putExtra("Rate",uri.getQueryParameter("Rate"));
                inte.putExtra("TotalAmount",uri.getQueryParameter("TotalAmount"));
                inte.putExtra("ResortName",uri.getQueryParameter("ResortName"));
                inte.putExtra("UnitName",uri.getQueryParameter("UnitName"));
                inte.putExtra("ReciptNo",uri.getQueryParameter("ReciptNo"));
                inte.putExtra("BankType", uri.getQueryParameter("BankType"));
                inte.putExtra("BarCodeNo", uri.getQueryParameter("BarCodeNo"));
                inte.putExtra("Custid",uri.getQueryParameter("Custid"));
                inte.putExtra("UserLogin",uri.getQueryParameter("UserLogin"));
                startActivity(inte);
            }
            else
            {
                Intent inte=new Intent(getApplicationContext(),FailedResponse.class);
                startActivity(inte);
            }
        }
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_web_view, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
