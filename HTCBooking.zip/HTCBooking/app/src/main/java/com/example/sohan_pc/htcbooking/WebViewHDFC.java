package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.sohan_pc.htcbooking.R.id.view;

public class WebViewHDFC extends Activity {
    private WebView webView;
//    ProgressDialog pd;
    private int pStatus = 0;
    ProgressBar progressBar;
    TextView txtProgress;
    private Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_web_view_hdfc);

        webView = (WebView) findViewById(R.id.webviewhdfc);
       progressBar = (ProgressBar) findViewById(R.id.progressBar1);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new InsideWebViewClient());
        final String GetUrl=(getIntent().getExtras().getString("URL"));
        webView.loadUrl(getIntent().getExtras().getString("URL"));
        ////////////////////Start progress bar
        progressBar.setVisibility(View.VISIBLE);
        txtProgress=(TextView)findViewById(R.id.txtProgress) ;

//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while (pStatus <= 100) {
//                    handler.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            progressBar.setProgress(pStatus);
//                            txtProgress.setText(pStatus + " %");
//                        }
//                    });
//                    try {
//                        Thread.sleep(120);
//                    } catch (InterruptedException e) {
//
//                    }
//                    pStatus++;
//                }
//            }
//        }).start();
        //////End of progress bar

//        progressBar.getIndeterminateDrawable().setColorFilter(0xFFFF0000, android.graphics.PorterDuff.Mode.MULTIPLY);



    }
    private class InsideWebViewClient extends WebViewClient {

//        ProgressDialog pd = null;
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            view.loadUrl(url);

            return true;
        }
        @Override
        public void onPageFinished(WebView view, String url) {
//            pd.dismiss();

//            progressBar.setVisibility(View.GONE);

            if(url.toLowerCase().contains("htcandroidws/responsetoandroid.aspx")){
                Uri uri=Uri.parse(url);

                if(uri.getQueryParameter("Status").toString().equals("success"))
                {
                    Intent inte=new Intent(getApplicationContext(),GetResponseHdfc.class);
                    inte.putExtra("Status",uri.getQueryParameter("Status"));
                    inte.putExtra("TransactionId",uri.getQueryParameter("TransactionId"));
                    inte.putExtra("Firstname",uri.getQueryParameter("Firstname"));
                    inte.putExtra("Mobile",uri.getQueryParameter("Mobile"));
                    inte.putExtra("Email",uri.getQueryParameter("Email"));
                    inte.putExtra("BookingDateFROM",uri.getQueryParameter("BookingDateFROM"));
                    inte.putExtra("BookingDateTO",uri.getQueryParameter("BookingDateTO"));
                    inte.putExtra("Rate",uri.getQueryParameter("Rate"));
                    inte.putExtra("TotalAmount",uri.getQueryParameter("TotalAmount"));
                    inte.putExtra("ResortName",uri.getQueryParameter("ResortName"));
                    inte.putExtra("UnitName",uri.getQueryParameter("UnitName"));
                    inte.putExtra("ReciptNo",uri.getQueryParameter("ReciptNo"));
                    inte.putExtra("BankType", uri.getQueryParameter("BankType"));
                    inte.putExtra("BarCodeNo", uri.getQueryParameter("BarCodeNo"));
                    inte.putExtra("Custid",uri.getQueryParameter("Custid"));
                    inte.putExtra("UserLogin",uri.getQueryParameter("UserLogin"));
                    startActivity(inte);

                }
                else
                {

                    Intent inte=new Intent(getApplicationContext(),FailedResponse.class);
                    startActivity(inte);
                }
            }


        }



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_web_view_hdfc, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
