package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
public class ForgotPassword extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/getpasswordVerification";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "getpasswordVerification";
    //   private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    ProgressDialog pDialog;
    String getNewPwd,getMbNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_forgot_password);
        final ImageView Btn_Logout = (ImageView) findViewById(R.id.butHome);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(ForgotPassword.this, "Try again", Toast.LENGTH_SHORT).show();

                }
            }
        });

        //Buttton Click
        Button BtnPwd = (Button) findViewById(R.id.BtnNewPwd);
        BtnPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ///Validation////////////////////
                final EditText MobNo = (EditText) findViewById(R.id.Edt_MobNo);
                getMbNo = MobNo.getText().toString();
                if (getMbNo.equals("") || getMbNo.equals("0")) {
                    MobNo.setError("Enter Correct User Id");
                    return;
                }
                final EditText NewPwd = (EditText) findViewById(R.id.Edt_NewPwd);
                getNewPwd = NewPwd.getText().toString();
                if (getNewPwd.equals("") || getNewPwd.equals("0")) {
                    NewPwd.setError("Enter Correct Mobile No");
                    return;
                }
                //End validation
                // Call web service
                SoapAccessTask task = new SoapAccessTask();
                task.execute();
                //=======================================
                ///////////////Button Exit
            }

        });

    }

    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
//
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("Userid", getMbNo);
                request.addProperty("MobileNo", getNewPwd);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(ForgotPassword.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(ForgotPassword.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();

                if (abb.equals("1")) {

                    Toast.makeText(ForgotPassword.this,
                            "user doesn't exists!!", Toast.LENGTH_LONG)
                            .show();
                                           /* Intent inte = new Intent(getApplicationContext(), OTPVerification.class);
                                            inte.putExtra("MobileNo", getMbNo);
                                            startActivity(inte);*/
                } else if (abb.equals("2")) {
                    Toast.makeText(ForgotPassword.this,
                            "User verified !!", Toast.LENGTH_LONG)
                            .show();
                    Intent inte = new Intent(getApplicationContext(), UpdateForgettedPassword.class);
                    inte.putExtra("MobileNo", getNewPwd);
                    inte.putExtra("UserId", getMbNo);
                    startActivity(inte);
                } else if (abb.equals("3")) {
                    Toast.makeText(ForgotPassword.this,
                            "Mobile Number did not match !!", Toast.LENGTH_LONG)
                            .show();

                } else if (abb.equals("4")) {
                    Toast.makeText(ForgotPassword.this,
                            "User OTP is not verified !!", Toast.LENGTH_LONG)
                            .show();
                    // final String Uname = abb.substring(abb.indexOf("/") + 1, abb.length());
                    Intent inte = new Intent(getApplicationContext(), NewOtpVerification.class);
                    inte.putExtra("MobileNo", getNewPwd);
                    inte.putExtra("UserName", getMbNo);
                    inte.putExtra("UserId", getMbNo);
                    startActivity(inte);
                } else {
                    Toast.makeText(ForgotPassword.this,
                            "Some Error Occured!!", Toast.LENGTH_LONG)
                            .show();
                }
            }
        }
    }
}
