package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.content.SharedPreferences;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.HashMap;

public class NavigationScreen extends Activity {
String PhoneNo,EmailID,ContactOn;
 private   Boolean getUserStatus;
    // Session Manager Class
    SessionManagement session;
    ProgressDialog pd;

//    private ProgressBar spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_navigation_screen);
//        spinner=(ProgressBar)findViewById(R.id.progressBar);
//        spinner.setVisibility(View.GONE);
        sessionManage();

        SharedPreferences sharedPref = NavigationScreen.this.getPreferences(Context.MODE_PRIVATE);
        final String DefMobile = sharedPref.getString("MobileNo", "0");
        Log.e("name =", DefMobile);
        final    String DefMail = sharedPref.getString("MailId", "0");
        Log.e("name1 =", DefMail);
        final    String DefContactno = sharedPref.getString("Contactno", "0");
        Log.e("name2 =", DefContactno);
        final    boolean Defuserlogin = sharedPref.getBoolean("isLogged", false);

        final EditText Txtmail = (EditText) findViewById(R.id.edt_NavEmail);
        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            Txtmail.setText(messageMail);
            EmailID=messageMail;
            Log.e("EmailID =", EmailID);
        }

        final EditText LoginEditText = (EditText) findViewById(R.id.edt_navLoginid);
                if (getIntent().hasExtra("MobileNo")) {
            String message = getIntent().getStringExtra("MobileNo").toString();
            LoginEditText.setText(message);
                    PhoneNo=message;
                    Log.e("PhoneNo =", PhoneNo);
        }

        if (getIntent().hasExtra("Contactno")) {
            String messagecontct = getIntent().getStringExtra("Contactno").toString();
            ContactOn=messagecontct;
            Log.e("ContactOn =", ContactOn);
        }

        if (getIntent().hasExtra("IsUserLogIn")){
           getUserStatus=getIntent().getExtras().getBoolean("IsUserLogIn");
            if (getUserStatus=false){

                Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                startActivity(inte);
            }
        }
      //  Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
     final   String name = user.get(SessionManagement.KEY_NAME);
//        Log.e("name =", name);

        // email
        final    String email = user.get(SessionManagement.KEY_EMAIL);
//        Log.e("email =", email);
        // mobile
        final  String mobile = user.get(SessionManagement.KEY_MOBILE);
//        Log.e("mobile =",mobile);
        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    util.writePreference(NavigationScreen.this, "isLogged", false);
                    session.logoutUser();
                   /* getUserStatus=false;
                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                     startActivity(inte);*/
                } catch (Exception e) {
                    Toast.makeText(NavigationScreen.this, "Try after sometime", Toast.LENGTH_SHORT).show();

                }
            }
        });


        Button btnRev = (Button) findViewById(R.id.nav_btn_Reservtn);
        btnRev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

//                pd = new ProgressDialog(NavigationScreen.this);
//                pd.setTitle("Please Wait....");
//                pd.setCancelable(false);
//                pd.setCanceledOnTouchOutside(false);
//                pd.show();


                Intent inte = new Intent(getApplicationContext(),Reservation.class);
             /*   inte.putExtra("MobileNo", PhoneNo);
                inte.putExtra("MailId", EmailID);
                inte.putExtra("Contactno", ContactOn);
                inte.putExtra("IsUserLogIn",getUserStatus);*/

                inte.putExtra("MobileNo", name);
                inte.putExtra("MailId", email);
                inte.putExtra("Contactno", mobile);
                inte.putExtra("IsUserLogIn",Defuserlogin);
                startActivity(inte);
//                spinner.setVisibility(View.VISIBLE);
            }
        });

        Button btnCncl = (Button) findViewById(R.id.nav_btn_CnlBooking);
        btnCncl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent inte = new Intent(getApplicationContext(),cancellationActivity.class);
                inte.putExtra("MobileNo", name);
                inte.putExtra("MailId", email);
                inte.putExtra("Contactno", mobile);
                startActivity(inte);
            }
        });
        // final EditText MobNo = (EditText) findViewById(R.id.edt_login);

        Button btnPrnt = (Button) findViewById(R.id.nav_btn_Print);
        btnPrnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
//                pd = new ProgressDialog(NavigationScreen.this);
//                pd.setTitle("Please Wait....");
//                pd.setCancelable(false);
//                pd.setCanceledOnTouchOutside(false);
//                pd.show();
                Intent inte = new Intent(getApplicationContext(), PrintBooking.class);
                inte.putExtra("MobileNo", name);
                inte.putExtra("MailId", email);
                inte.putExtra("Contactno", mobile);
                startActivity(inte);
//                inte.putExtra("MobileNo", PhoneNo);
//                inte.putExtra("MailId", EmailID);
//                inte.putExtra("Contactno", ContactOn);
//                inte.putExtra("Contactno", mobile);
//                startActivity(inte);
            }
        });
        Button btnEdtPrfl = (Button) findViewById(R.id.Nav_btn_EditProfyl);
        btnEdtPrfl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
//                pd = new ProgressDialog(NavigationScreen.this);
//                pd.setTitle("Please Wait....");
//                pd.setCancelable(false);
//                pd.setCanceledOnTouchOutside(false);
//                pd.show();

                Intent inte = new Intent(getApplicationContext(), EditProfile.class);


//               inte.putExtra("MobileNo", PhoneNo);
//                inte.putExtra("MailId", EmailID);
//                inte.putExtra("Contactno", ContactOn);
                    inte.putExtra("MobileNo", name);
                    inte.putExtra("MailId", email);
                    inte.putExtra("Contactno", mobile);
                    startActivity(inte);
                }
              /*  Intent inte = new Intent(getApplicationContext(), BaseCodeToImage.class);
                startActivity(inte);*/

        });
        Button btnChngpwd = (Button) findViewById(R.id.Nav_btn_ChngPwd);
        btnChngpwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
//                pd = new ProgressDialog(NavigationScreen.this);
//                pd.setTitle("Please Wait....");
//                pd.setCancelable(false);
//                pd.setCanceledOnTouchOutside(false);
//                pd.show();
                Intent inte = new Intent(getApplicationContext(), ChangePassword.class);
               /* inte.putExtra("MobileNo", PhoneNo);
                inte.putExtra("MailId", EmailID);
                inte.putExtra("Contactno", ContactOn);*/
                inte.putExtra("MobileNo", name);
                inte.putExtra("MailId", email);
                inte.putExtra("Contactno", mobile);
                startActivity(inte);
            }
        });
        Button btnprepostpone = (Button) findViewById(R.id.Nav_btn_Prepostpone);
        btnprepostpone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
//                pd = new ProgressDialog(NavigationScreen.this);
//                pd.setTitle("Please Wait....");
//                pd.setCancelable(false);
//                pd.setCanceledOnTouchOutside(false);
//                pd.show();
                Intent inte = new Intent(getApplicationContext(), PreponePostponeBooking.class);
                inte.putExtra("MobileNo", name);
                inte.putExtra("MailId", email);
                inte.putExtra("Contactno", mobile);
                startActivity(inte);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_navigation_screen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //////////////Check internet connectivity
    public static boolean isNetworkAvailable(final Context context) {
        boolean isNetAvailable = false;
        if (context != null) {
            final ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                final NetworkInfo activeNetwork = mConnectivityManager.getActiveNetworkInfo();
                if(activeNetwork != null) isNetAvailable = true;
            }
        }
        return isNetAvailable;
    }
    //////////////////End internet connectivity

    @Override
    public void onBackPressed() {
        ////call exit method
        dialogOnBackPress();
    }
       /////Method to show the exit  dialogue box

        protected void dialogOnBackPress() {
        new AlertDialog.Builder(this)
                .setMessage("Are you sure you want to exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        NavigationScreen.this.finish();
                        Intent intCloseApp = new Intent(Intent.ACTION_MAIN);
        intCloseApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intCloseApp.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        intCloseApp.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intCloseApp.addCategory(Intent.CATEGORY_HOME);
        intCloseApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intCloseApp);

                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

//        Intent intCloseApp = new Intent(Intent.ACTION_MAIN);
//        intCloseApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        intCloseApp.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
//        intCloseApp.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//        intCloseApp.addCategory(Intent.CATEGORY_HOME);
//        intCloseApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intCloseApp);

    private void sessionManage()
    {
        session = new SessionManagement(getApplicationContext());
    }
}
