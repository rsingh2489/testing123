package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PreponePostponeBooking extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/GetDetails";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetDetails";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    String messagecustid,noofunits,Email,MobileNo;
    private List<ModalPrint> movieListP = new ArrayList<>();
    private RecyclerView recyclerView;
    private RecyclerViewAdapterPrePostPone mAdapter;
    String EmailID,IsMob;
    ProgressDialog pDialog;
    // Session Manager Class
    SessionManagement session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_prepone_postpone_booking);

        // Session class instance
        session = new SessionManagement(getApplicationContext());

        if (getIntent().hasExtra("MobileNo")) {
            messagecustid = getIntent().getStringExtra("MobileNo").toString();
        }

        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            if (messageMail.contains("/")) {
                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
            }
            else
                EmailID=messageMail;
        }
        if (getIntent().hasExtra("Contactno")) {

            String messageConctno = getIntent().getStringExtra("Contactno").toString();
            if (messageConctno.equals("1")) {

            } else {
                IsMob = messageConctno;

            }
        }
       // Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();

       final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    session.logoutUser();
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(PreponePostponeBooking.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });

        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
                    inte.putExtra("MobileNo", messagecustid);
                    inte.putExtra("MailId", EmailID);
                    inte.putExtra("Contactno", IsMob);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(PreponePostponeBooking.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });
        SoapAccessTask task = new SoapAccessTask();
        task.execute();

    }

    /////////////Async task ////////////
    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("UserID", messagecustid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(PreponePostponeBooking.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(PreponePostponeBooking.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                SubmitRes = result.toString();

                        try {
                            JSONArray jsonArray = new JSONArray(SubmitRes);
                            final String[] items = new String[jsonArray.length()];
                            Integer Arraylen=jsonArray.length();
                            if (jsonArray != null) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject youValue = jsonArray.getJSONObject(i);

                                    String idModule = youValue.getString("cust_name");
                                    String name = youValue.getString("cust_id");
                                    Email=youValue.getString("cust_phone");
                                    String Dest_name=youValue.getString("dest_name");
                                    String pay_amount=youValue.getString("pay_amount");
                                    String Srno=youValue.getString("NewNo");
                                    String Cat=youValue.getString("unit_name");
                                    String UnitNo=youValue.getString("unit_no");
                                    String Datefrom=youValue.getString("current_date_from");
                                    String DateTo=youValue.getString("current_date_to");
                                    String cnlFrm=youValue.getString("gg");
                                    String SerialNo=youValue.getString("srno");
                                    String UserLgin=messagecustid;
                                    Log.e("gg =", youValue.getString("gg"));
                                    String RoomNos="";
                                    if(!youValue.isNull("room_no"))
                                    {
                                        RoomNos=youValue.getString("room_no");

                                    }
                                    else
                                    {
                                        RoomNos="";
                                    }
                                    Log.e("RoomNos =",RoomNos);
                                    MobileNo=youValue.getString("Phone");
                                    String Entrydate=youValue.getString("entry_date");
                                    String Paymode=youValue.getString("pay_mode");
                                    String Paymodeno=youValue.getString("pay_mode_no");
                                    String PayRecdBy=youValue.getString("pay_rcvd_by");
                                    //  String IPaddress=youValue.getString("entry_date");
                                    String noOfRows=Integer.toString(Arraylen);

                                    //  Resorts.add(idModule);
                                    ModalPrint movie = new ModalPrint(idModule,name,Email,Dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,noOfRows,RoomNos,UserLgin,MobileNo,Entrydate,Paymode,Paymodeno,PayRecdBy);
                                    movieListP.add(movie);
                                }
                            }

                            recyclerView = (RecyclerView) findViewById(R.id.Preponepostpone);
                            mAdapter = new RecyclerViewAdapterPrePostPone(movieListP);
                            recyclerView.setHasFixedSize(true);
                            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
                            recyclerView.setLayoutManager(mLayoutManager);
                            recyclerView.addItemDecoration(new DividerItemDecoration(PreponePostponeBooking.this, LinearLayoutManager.HORIZONTAL));
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(mAdapter);

                        } catch (JSONException e) {
                            Toast.makeText(PreponePostponeBooking.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }
            }
        }}
    ////////////End Async task////////////



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_prepone_postpone_booking, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
        inte.putExtra("MobileNo", messagecustid);
        inte.putExtra("MailId", EmailID);
        inte.putExtra("Contactno", IsMob);
        startActivity(inte);
    }
}
