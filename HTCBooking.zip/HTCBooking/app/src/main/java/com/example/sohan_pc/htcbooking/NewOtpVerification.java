package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.net.URISyntaxException;

public class NewOtpVerification extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/VerifyOTPNEW";
    private static String SOAP_ACTION2 = "http://tempuri.org/Update";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "VerifyOTPNEW";
    private static String METHOD_NAME2 = "Update";
    //   private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    String UserPho,UserId,UserName,getOTP;
    String getPhone=null;
    TextView TxtMobNo;
    ImageView backBtn;
    EditText otp_edtTxt;
    String otpValue;
    ProgressDialog pd;

    private static int SPLASH_TIME_OUT = 10000;
//    SmsVerifyCatcher smsVerifyCatcher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_new_otp_verification);
        backBtn=(ImageView) findViewById(R.id.butHome);
        otp_edtTxt=(EditText)findViewById(R.id.Edt_OTP);

        //////////progress Dialog to generate otp

        if (getIntent().hasExtra("OTP")) {
            otpValue = getIntent().getStringExtra("OTP");
        }

        pd = new ProgressDialog(NewOtpVerification.this);
        pd.setTitle("Retriving OTP. Please Wait....");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);
        pd.show();
        new Handler().postDelayed(new Runnable() {

            /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

            @Override
            public void run() {
                if (pd != null) {
                    pd.dismiss();
                }

                otp_edtTxt.setText(otpValue);


            }
        }, SPLASH_TIME_OUT);

////testing to set otp on a edit text
//        if(getIntent().hasExtra("OTP")) {
//            String otp = getIntent().getStringExtra("OTP").toString();
//            getOTP =otp.toString();
//            otp_edtTxt.setText(otp);
//        }
        ////////////end testing
        /////////////////////////////To Auto Detect Otp call broadcast receiver////////

//        SmsReceiver.bindListener(new SmsListner() {
//            @Override
//            public void messageReceived(String messageText) {
//                Log.d("Text",messageText);
//
//                otp_edtTxt.setText(messageText);
//
//                Toast.makeText(NewOtpVerification.this,"Message: "+messageText,Toast.LENGTH_LONG).show();
//
//            }
//        });

        /////////////////////end broadcast receiver////////////////////


        backBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), MobileNoRegisteration.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(NewOtpVerification.this, "Try again after some time", Toast.LENGTH_SHORT).show();
                }
            }
        });

        TxtMobNo=(TextView)findViewById(R.id.txt_MobNo);
        if(getIntent().hasExtra("UserName")) {
            String messageUname = getIntent().getStringExtra("UserName").toString();
            TxtMobNo.setText(messageUname);
            UserName=messageUname.toString();
        }



        if(getIntent().hasExtra("MobileNo")) {
            String messagePh = getIntent().getStringExtra("MobileNo").toString();
            UserPho=messagePh.toString();
        }

//////////Button Click
        Button BtnVerify=(Button)findViewById(R.id.btn_Verify);
        BtnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
               // Verifyotp();

                getPhone=TxtMobNo.getText().toString();
                getOTP  = otp_edtTxt.getText().toString();
                SoapAccessTask task = new SoapAccessTask();
                task.execute();
                //eeeee
            }
        });
        //End Button Click
        //Regenerate OTP
        TextView RegenerateOTPLink= (TextView) findViewById(R.id.Txt_Regenerate);
        RegenerateOTPLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call web service
                SoapAccessRenerateOtp regenrate =new SoapAccessRenerateOtp();
                regenrate.execute();
            }
        });
        //End Regenerate Password
    }

/////////////Start asyn task  to verify OTP ////////
    private class SoapAccessTask extends AsyncTask<String, Void, String>
    {
        protected void onPreExecute() {
            pd = new ProgressDialog(NewOtpVerification.this);
            pd.setMessage("Please Wait ...");
            pd.setIndeterminate(false);
            pd.setCancelable(true);
            pd.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("OTP", getOTP);
                request.addProperty("PhoneNo", UserPho);

                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;

                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();
            }
            catch(Exception e)
            {
                Toast.makeText(NewOtpVerification.this, "Some Error", Toast.LENGTH_SHORT).show();
            }

             return webResponse;
        }

        protected void onPostExecute(String result) {
           pd.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                abb = result.toString();
                String[] namesList = abb.split("/");
                UserPho = namesList[1];
                getPhone = namesList[2];
                if (abb.contains("/")) {
                    Toast.makeText(NewOtpVerification.this,
                            "OTP verified!!", Toast.LENGTH_LONG)
                            .show();

                    Intent inte = new Intent(getApplicationContext(), NewRegistration.class);
                    inte.putExtra("MobileNo", UserPho);
                    inte.putExtra("PhoneNo", getPhone);
                    startActivity(inte);
                } else if (abb.equals("2")) {
                    Toast.makeText(NewOtpVerification.this,
                            "Incorrect OTP!!", Toast.LENGTH_LONG)
                            .show();

                } else {
                    Toast.makeText(NewOtpVerification.this,
                            "Some Error Occured!!", Toast.LENGTH_LONG)
                            .show();
                }
            }
        }
    }
    //////////End  async task//////////////////

    /////Start async to regenrate OTP
    private class SoapAccessRenerateOtp extends AsyncTask<String, Void, String>
    {
        protected void onPreExecute() {
            pd = new ProgressDialog(NewOtpVerification.this);
            pd.setMessage("Please Wait ...");
            pd.setIndeterminate(false);
            pd.setCancelable(true);
            pd.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
                request.addProperty("Password",0 );
                request.addProperty("IsRegenerated",1);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;

                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION2, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();
            }
            catch(Exception e)
            {
                Toast.makeText(NewOtpVerification.this, "Some Error", Toast.LENGTH_SHORT).show();
            }

            return webResponse;
        }

        protected void onPostExecute(String result) {
            pd.dismiss();
            if(result != null)
            {
                //Get the first property and change the label text
                abb = result.toString();

                        final EditText OTPno=(EditText) findViewById(R.id.Edt_OTP);
                        if(abb.equals("1")) {

                            OTPno.setText("");
                            OTPno.setFocusable(true);
                        }
                        else if(abb.equals("2")){
                            OTPno.setText("");
                            OTPno.setFocusable(true);
                            Toast.makeText(NewOtpVerification.this,
                                    "User Not Found!!", Toast.LENGTH_LONG)
                                    .show();

                        }
                        else if(abb.equals("3")) {
                            Toast.makeText(NewOtpVerification.this,
                                    "You can regenerate after 5 minutes!!", Toast.LENGTH_LONG)
                                    .show();
                        }
                        else
                        {
                            Toast.makeText(NewOtpVerification.this,
                                    "Some Error Occured!!", Toast.LENGTH_LONG)
                                    .show();
                        }
                    }
            }
        }
    }
    //////////End async task//////////////////
    //////////====================Method to Verify OTP by Himani===============//////

