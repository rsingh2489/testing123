package com.example.sohan_pc.htcbooking;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.preference.PreferenceManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by hp on 20-07-2016.
 */
public class util {
    public static final String PREF_NAME = "file";

    @SuppressWarnings("deprecation")
    public static final int MODE = Context.MODE_PRIVATE;

    public static File convertBitmapToFile(Bitmap result, String PATH, String fileName){
        File file = new File(PATH, fileName);

        OutputStream outStream = null;
        try
        {
            if(!file.exists()) {
                file.createNewFile();
            }
            outStream = new FileOutputStream(file,false);
            //saving as a JPEG image
            result.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            outStream.flush();
            outStream.close();
            //  Toast.makeText(DownloadAndSaveImage.this, "Saved", Toast.LENGTH_LONG).show();
        }
        catch(FileNotFoundException e)
        {
            //TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch(IOException e)
        {
            //TODO Auto-generated catch block
            e.printStackTrace();
        }
        return file;


    }

    public static boolean isLogged(Context context){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        return settings.getBoolean("isLogged",false);

    }
    public static String isMobile(Context context){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        return settings.getString("isMobile", "0");

    }
    public static void writePreference(Context mContext,String preferenceName,boolean preferenceValue){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(mContext);
        SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(preferenceName, preferenceValue);
               editor.commit();
    }
    public static void writePreferenceString(Context mContext,String preferenceName,String preferenceValue){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(mContext);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(preferenceName, preferenceValue);
        editor.commit();
    }
    public static String readStrPreference(Context mContext,String preference){
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(mContext);

        return settings.getString(preference, "");
    }

    public static void writeString(Context context, String key, String value) {
        getEditor(context).putString(key, value).commit();

    }

    public static String readString(Context context, String key, String defValue) {
        return getPreferences(context).getString(key, defValue);
    }

    public static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, MODE);
    }

    public static SharedPreferences.Editor getEditor(Context context) {
        return getPreferences(context).edit();
    }

}
