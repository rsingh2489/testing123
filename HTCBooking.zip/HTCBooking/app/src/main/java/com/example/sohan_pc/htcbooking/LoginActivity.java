package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

/**
 * Created by Himani22 on 04-10-2017.
 */

public class LoginActivity extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/AuthenticateUser";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "AuthenticateUser";
    //private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
    // private static String URL = "http://10.89.179.45/htcbooking/WS_Payment.asmx";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    ProgressDialog pDialog;
    private Boolean IsUserLogIn = true;
    ProgressBar progressBar;
    String getphone, getpwd;
    // Session Manager Class
    SessionManagement session;
    EditText Phone, Pwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_login);
        Phone = (EditText) findViewById(R.id.txt_phoneno);
        Pwd = (EditText) findViewById(R.id.txt_pwd);
        // Session Manager
        session = new SessionManagement(getApplicationContext());
        //  Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();

        //Login Submit Button Click/////////////////
        Button button = (Button) findViewById(R.id.button1);
     /*   sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);*/
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //calling Method
                ///Validation////////////////////
//                final EditText Phone = (EditText) findViewById(R.id.txt_phoneno);
                getphone = Phone.getText().toString();
                if (getphone.equals("") || getphone.equals("0")) {
                    Phone.setError("Enter Valid Number");
                    return;
                }
//                final EditText Pwd = (EditText) findViewById(R.id.txt_pwd);
                getpwd = Pwd.getText().toString();
                if (getpwd.equals("") || getpwd.equals("0")) {
                    Pwd.setError("Enter Password");
                    return;
                }
                SoapAccessTask task = new SoapAccessTask();
                //passes values for the urls string array
//                task.execute(new String[] { "USD","LKR"});
                task.execute();
//                LoginButton();
            }
        });


        LinearLayout RegisterLink = (LinearLayout) findViewById(R.id.CreateAcount);
        RegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(getApplicationContext(), MobileNoRegisteration.class);
                startActivity(inte);
            }
        });
        LinearLayout ForgetPwd = (LinearLayout) findViewById(R.id.ForgetPAssLAyout);
        ForgetPwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(getApplicationContext(), ForgotPassword.class);
                startActivity(inte);
            }
        });
    }

    //starting asynchronus task/////////////////////////////
    private class SoapAccessTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            pDialog = new ProgressDialog(LoginActivity.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {
            String webResponse = "";
            try {
//
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("UserID", getphone);
                request.addProperty("Password", getpwd);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Cannot access the web service" + e.toString(), Toast.LENGTH_LONG).show();
            }
            return webResponse;
        }

        @Override
        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();


                if (abb.toString().contains("@")) {
                    String IsVerified = abb.substring(0, abb.indexOf(","));
                    if (IsVerified.equals("5")) {

                        session.createLoginSession(getphone, abb, "1");
                        IsUserLogIn = true;
                        util.writePreference(LoginActivity.this, "isLogged", true);
                        util.writeString(LoginActivity.this, "MobileNo", getphone);
                        util.writeString(LoginActivity.this, "MailId", abb);
                        util.writeString(LoginActivity.this, "Contactno", "1");
                        Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
                        inte.putExtra("MobileNo", getphone);
                        inte.putExtra("MailId", abb);
                        inte.putExtra("Contactno", "1");
                        inte.putExtra("IsUserLogIn", IsUserLogIn);
                        startActivity(inte);
                    } else if (IsVerified.equals("4")) {
                        final String Uname = abb.substring(abb.indexOf(",") + 1, abb.indexOf("/"));
                        final String Phone = abb.substring(abb.indexOf("/") + 1, abb.length());
                        // session.createLoginSession(getphone, "anroidhive@gmail.com");

                        util.writePreference(LoginActivity.this, "isLogged", true);
                        util.writeString(LoginActivity.this, "MobileNo", Phone);
                        util.writeString(LoginActivity.this, "UserName", Uname);
                        util.writeString(LoginActivity.this, "UserId", getphone);


                        IsUserLogIn = true;
                        Intent inte = new Intent(getApplicationContext(), NewOtpVerification.class);
                        inte.putExtra("MobileNo", Phone);
                        inte.putExtra("UserName", Uname);
                        inte.putExtra("UserId", getphone);
                        inte.putExtra("IsUserLogIn", IsUserLogIn);
                        startActivity(inte);
                    }
                } else if (abb.equals("2")) {
                    Toast.makeText(LoginActivity.this,
                            "Incorrect Password!!", Toast.LENGTH_LONG)
                            .show();
                } else if (abb.equals("3")) {
                    Toast.makeText(LoginActivity.this,
                            "Incorrect User Id!!", Toast.LENGTH_LONG)
                            .show();
                } else {
                    Toast.makeText(LoginActivity.this,
                            "Some Error Occured!", Toast.LENGTH_LONG)
                            .show();
                }

            } else {

                Toast.makeText(getApplicationContext(), "No Response", Toast.LENGTH_LONG).show();
            }


            //if you started progress dialog dismiss it here
//            textView.setText(result);
//            Toast.makeText(getApplicationContext(),"Completed...", Toast.LENGTH_LONG).show();
        }
    }


    ///////////////////End asynctask


//    public void LoginButton()
//    {
//        ///Validation////////////////////
//        final EditText Phone = (EditText) findViewById(R.id.txt_phoneno);
//        final String getphone = Phone.getText().toString();
//        if (getphone.equals("") || getphone.equals("0")) {
//            Phone.setError("Enter Valid Number");
//            return;
//        }
//        final EditText Pwd = (EditText) findViewById(R.id.txt_pwd);
//        final String getpwd = Pwd.getText().toString();
//        if (getpwd.equals("") || getpwd.equals("0")) {
//            Pwd.setError("Enter Password");
//            return;
//        }
//
//        pd = new ProgressDialog(LoginActivity.this);
//        pd.setTitle("Please Wait....");
//        pd.setCancelable(false);
//        pd.setCanceledOnTouchOutside(false);
//        pd.show();
////        if(connectionAvailable())
////        {
////            Toast.makeText(LoginActivity.this, "No internet", Toast.LENGTH_SHORT).show();
////
////        }
//
//
//        //end validation
//        // Call web service
//        //=================== ====================
//        new Thread() {
//            @Override
//            public void run() {
//
//
//                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                request.addProperty("UserID", getphone);
//                request.addProperty("Password", getpwd);
//                //Declare the version of the SOAP request
//                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                envelope.setOutputSoapObject(request);
//                envelope.dotNet = true;
//
//                try {
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                    //this is the actual part that will call the webservice
//                    androidHttpTransport.call(SOAP_ACTION1, envelope);
////                    pd = new ProgressDialog(LoginActivity.this);
////                    pd.setTitle("Please Wait....");
////                    pd.show();
//                    // Get the SoapResult from the envelope body.
//                    SoapObject result = (SoapObject) envelope.bodyIn;
//                    ;
//                    if (result != null) {
//                        //Get the first property and change the label text
//                        if(pd!=null){
//                            pd.dismiss();
//
//                        }
//                        abb = result.getProperty(0).toString();
//                        Log.e(abb,"result of Login user");
////                        if(!connectionAvailable()){
//
////
//
//
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//
//                                if (abb.toString().contains("@")) {
//                                    String IsVerified = abb.substring(0, abb.indexOf(","));
//                                    if (IsVerified.equals("5")) {
//
//                                        session.createLoginSession(getphone,abb,"1");
//
//
//                                        IsUserLogIn=true;
//                                        util.writePreference(LoginActivity.this, "isLogged", true);
//                                        util.writeString(LoginActivity.this, "MobileNo", getphone);
//                                        util.writeString(LoginActivity.this,"MailId",abb);
//                                        util.writeString(LoginActivity.this,"Contactno","1");
//                                        Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
//                                        inte.putExtra("MobileNo", getphone);
//                                        inte.putExtra("MailId", abb);
//                                        inte.putExtra("Contactno","1");
//                                        inte.putExtra("IsUserLogIn",IsUserLogIn);
//                                        startActivity(inte);
//                                    } else if (IsVerified.equals("4")) {
//                                        final String Uname = abb.substring(abb.indexOf(",") + 1, abb.indexOf("/"));
//                                        final String Phone = abb.substring(abb.indexOf("/") + 1, abb.length());
//                                        // session.createLoginSession(getphone, "anroidhive@gmail.com");
//
//                                        util.writePreference(LoginActivity.this, "isLogged", true);
//                                        util.writeString(LoginActivity.this, "MobileNo", Phone);
//                                        util.writeString(LoginActivity.this,"UserName",Uname);
//                                        util.writeString(LoginActivity.this,"UserId",getphone);
//
//                                        IsUserLogIn=true;
//                                        Intent inte = new Intent(getApplicationContext(),OTPVerification.class);
//                                        inte.putExtra("MobileNo", Phone);
//                                        inte.putExtra("UserName", Uname);
//                                        inte.putExtra("UserId", getphone);
//                                        inte.putExtra("IsUserLogIn",IsUserLogIn);
//                                        startActivity(inte);
//                                    }
//                                } else if (abb.equals("2")) {
//                                    Toast.makeText(LoginActivity.this,
//                                            "Incorrect Password!!", Toast.LENGTH_LONG)
//                                            .show();
//                                } else if (abb.equals("3")) {
//                                    Toast.makeText(LoginActivity.this,
//                                            "Incorrect User Id!!", Toast.LENGTH_LONG)
//                                            .show();
//                                } else {
//                                    Toast.makeText(LoginActivity.this,
//                                            "Some Error Occured!", Toast.LENGTH_LONG)
//                                            .show();
//                                }
//
//                            }
//                        });
//
//                    } else {
//
//                        //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                    }
//                } catch (Exception e) {
//
//                    e.printStackTrace();
//
//                }
//            }
//        }.start();
//        }
        //=======================================
        ///////////////Button Exit




    @Override
    public void onBackPressed() {
        //Code by soumya
//        Intent intent = new Intent(this, LoginActivity.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//        this.startActivity(intent);
//        this.finish();

        //Changes by HImani
        moveTaskToBack(true);
    }



//    private boolean connectionAvailable() {
//        boolean connected = false;
//        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
//        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
//                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
//            //we are connected to a network
//            Toast.makeText(LoginActivity.this, "No Internet connection!!!!!!!!", Toast.LENGTH_SHORT).show();
//            connected = true;
//        }
//        return connected;
//    }


}
