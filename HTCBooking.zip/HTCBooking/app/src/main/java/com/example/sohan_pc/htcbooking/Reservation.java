package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.view.ContextThemeWrapper;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.DatePicker;
import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;


import android.app.DatePickerDialog.OnDateSetListener;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;




import java.util.ArrayList;
import  java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class Reservation extends Activity implements OnClickListener {
    private static String SOAP_ACTION6 = "http://tempuri.org/GetDisttName";
    private static String SOAP_ACTION1 = "http://tempuri.org/GetResortName";
    private static String SOAP_ACTION2 = "http://tempuri.org/GetUnitType";
    private static String SOAP_ACTION3 = "http://tempuri.org/GetNoOfRooms";
    private static String SOAP_ACTION4 = "http://tempuri.org/Submit_Payment";
    private static String SOAP_ACTION5 = "http://tempuri.org/amtcal";
    private static String SOAP_ACTION7 = "http://tempuri.org/CheckAvailability";
    private static String NAMESPACE = "http://tempuri.org/";
    private  static  String METHOD_NAME6="GetDisttName";
    private static String METHOD_NAME1 = "GetResortName";
    private static String METHOD_NAME2 = "GetUnitType";
    private  static  String METHOD_NAME3="GetNoOfRooms";
    private  static  String METHOD_NAME4="Submit_Payment";
    private  static  String METHOD_NAME5="amtcal";
    private  static  String METHOD_NAME7="CheckAvailability";

    //UI Referebnce
    ProgressDialog pDialog;
    private EditText fromDateEtxt;
    private EditText toDateEtxt;
    RadioButton radioButton;
    RadioGroup  radioGroup;
    String CustLoginId,NoOfRooms ;
    ImageView imgFirst,resortSpin,spinRoomCategory,roomNo,idSpinner,imgNationality;
    private DatePickerDialog fromDatePickerDialog;
    private DatePickerDialog toDatePickerDialog;
    String Restid, RsortName , CatyName , GetCheckInDate,CusName,CusEId,CusPhNO ;
    private SimpleDateFormat dateFormatter;
    private   Boolean getUserStatus;
    TextView calAmt;
    // Session Manager Class
    SessionManagement session;
    Spinner sp1, sp2, sp3, sp4, sp5, sp6;
 //   private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
  private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    private static String SubmitRes = "pp";
    private String[] arraySpinner;
    private String[] arraySpinnerNationality;
    String EmailID,IsMob,PhoneNo;
    TextView textRsrtValue,textTariffValue,textFirstDtValue,textSecDtValue,textThrdDtValue,textForthDtValue,textFiveDtValue;
    WebView web;
    int id;
    Button button;
    ProgressDialog ProgressD;
    EditText ChkInDate,CName,CEmailId,CPhoneNo,LoginId,ChkOutDate;
    TextView TaxAmt;
    Button buttonCalAmt;
    String RsrtName , CatgryName ,UnitNo , CatName , GetCheckIn , GetCheckOut , GetSecserchDt,GetThrdserchDt,GetForthserchDt,GetFiveserchDt;

    String GetServiceTax,GetLuxuryTax,GetTotalAmt,GetTotAmtFinal,RName,CtName,getChkOutDate, CusIdentityProf,CusNationality,CustTax;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
       // getSupportActionBar().hide();
        setContentView(R.layout.activity_reservation);

        // Session class instance
        session = new SessionManagement(getApplicationContext());
        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        String name = user.get(SessionManagement.KEY_NAME);
        // email
        String email = user.get(SessionManagement.KEY_EMAIL);
        // mobile
        String mobile = user.get(SessionManagement.KEY_MOBILE);

        final EditText Txtmail = (EditText) findViewById(R.id.edt_EmailId);
        final EditText PhoneEditText = (EditText) findViewById(R.id.edt_PhoneNum);
        imgFirst = (ImageView) findViewById(R.id.imgFirst);
        imgFirst.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sp6.showContextMenu();
                sp6.performClick();
            }
        });
        resortSpin= (ImageView)findViewById(R.id.resortspin_img);
        resortSpin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                sp1.showContextMenu();
                sp1.performClick();
            }
        });
        spinRoomCategory=(ImageView)findViewById(R.id.roomCat_Spinimg);
        spinRoomCategory.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                sp2.showContextMenu();
                sp2.performClick();
            }
        });
        roomNo=(ImageView)findViewById(R.id.room_no_spin);
        roomNo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                sp3.showContextMenu();
                sp3.performClick();
            }
        });
        idSpinner=(ImageView)findViewById(R.id.idProof_Spinner);
        idSpinner.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                sp4.showContextMenu();
                sp4.performClick();
            }
        });
        imgNationality=(ImageView)findViewById(R.id.nationality_Spinner);
        imgNationality.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                sp5.showContextMenu();
                sp5.performClick();
            }
        });

        if (getIntent().hasExtra("MailId")) {
                        String messageMail = getIntent().getStringExtra("MailId").toString();
            if (messageMail.contains("/")) {
                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
                Txtmail.setText(EmailID);
                PhoneEditText.setText(IsMob);
            }
            else
                Txtmail.setText(messageMail);
                 EmailID=messageMail;
        }

        final EditText LoginEditText = (EditText) findViewById(R.id.edt_loginid);
        if (getIntent().hasExtra("MobileNo")) {
            String messageMbno = getIntent().getStringExtra("MobileNo").toString();
            LoginEditText.setText(messageMbno);
            PhoneNo=messageMbno;
                   }
        if (getIntent().hasExtra("Contactno")) {

            String messageConctno = getIntent().getStringExtra("Contactno").toString();
            if (messageConctno.equals("1")){

            }
            else
            {
                IsMob=messageConctno;
                PhoneEditText.setText(IsMob);
            }

        }

        if (getIntent().hasExtra("IsUserLogIn")){
            getUserStatus=getIntent().getExtras().getBoolean("IsUserLogIn");
            if (getUserStatus=false){

                Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                startActivity(inte);
            }
        }
        EditText testEditText = (EditText) findViewById(R.id.edt_CustName);
        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);
        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    session.logoutUser();
                    getUserStatus=false;
                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });
        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);
        Btn_Home.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(),NavigationScreen .class);
                    inte.putExtra("MobileNo", PhoneNo);
                    inte.putExtra("MailId", EmailID);
                    inte.putExtra("Contactno", IsMob);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });

        dateFormatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.US);
        findViewsById();
        setDateTimeField();

        //Id Proofs dropdown
        this.arraySpinner = new String[]{
                "Voter Id", "Aadhar Card", "Pan Card", "Passport", "Driving License"
        };
        Spinner sIdentity = (Spinner) findViewById(R.id.spin_IdProofs);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        sIdentity.setAdapter(adapter);
        //end
        //Date Selection
        EditText txtEdit = (EditText) findViewById(R.id.edt_CustName);
        //End Date Selection
        //Nationality dropdown
        this.arraySpinnerNationality = new String[]{
                "Indian", "Foreign"
        };
        Spinner sNaionality = (Spinner) findViewById(R.id.spin_Nationality);
        ArrayAdapter<String> adapterN = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arraySpinnerNationality);
        sNaionality.setAdapter(adapterN);

        TextView TermsLink= (TextView) findViewById(R.id.TextViewHp);
        TermsLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alert = new AlertDialog.Builder(new ContextThemeWrapper(Reservation.this,R.style.Base_Theme_AppCompat_DialogWhenLarge));
                alert.setTitle("Terms And Conditions");
                WebView wv = new WebView(getApplicationContext());
                wv.getSettings().setBuiltInZoomControls(true);
                wv.setVerticalScrollBarEnabled(false);
                wv.loadUrl("http://web1.hry.nic.in/HTCAndroidWS/frminformation.htm");
                wv.setHorizontalScrollBarEnabled(false);
              //  wv.loadDataWithBaseURL("http://web1.hry.nic.in/HTCAndroidWS/frminformation.htm", "http://web1.hry.nic.in/HTCAndroidWS/frminformation.htm","text/html", "utf-8", null);
              //  wv.loadDataWithBaseURL(null, "HTML content here", "text/html", "utf-8", null);
                alert.setView(wv);
                alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                alert.show();
            }

        });


        int count;
        sp1 = (Spinner) findViewById(R.id.spin_Resort);
        sp2 = (Spinner) findViewById(R.id.spin_RoomCat);
        sp3 = (Spinner) findViewById(R.id.spin_NoOfRooms);
        sp4 = (Spinner) findViewById(R.id.spin_IdProofs);
        sp5 = (Spinner) findViewById(R.id.spin_Nationality);
        sp6 = (Spinner) findViewById(R.id.spin_Distt);

        sp6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,
                                       View view, int pos, long id) {

                EditText ChekOuate = (EditText) findViewById(R.id.edt_chkOutDate);
                Restid = parent.getItemAtPosition(pos).toString();
                ////////////call webservice//////////
                SoapAccessTask task = new SoapAccessTask();
                task.execute();
                //End Web service resort names
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        //End Distt Selection

        //Resort Seletion
        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,
                                       View view, int pos, long id) {
                EditText ChekOuate = (EditText) findViewById(R.id.edt_chkOutDate);
                 Restid = parent.getItemAtPosition(pos).toString();

                SoapAccessGetUNitType getUnitypeTask= new SoapAccessGetUNitType();
                getUnitypeTask.execute();
                //End Web service resort name
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }
        });
        //On Roomm Selection
        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,
                                       View view, int pos, long id) {
                 RsortName = sp1.getSelectedItem().toString();
                final String CatgriName = parent.getItemAtPosition(pos).toString();
                 CatyName = CatgriName.substring(CatgriName.indexOf(",") + 1, CatgriName.indexOf("("));

                //=================== ====================
                SoapGetNoRooms getnoOfRooms= new SoapGetNoRooms();
                getnoOfRooms.execute();

            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
//Bank Selection
        RadioGroup radGrp = (RadioGroup) findViewById(R.id.radiogrpPayType);

        int checkedRadioButtonID = radGrp.getCheckedRadioButtonId();

        radGrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup arg0, int id) {
                RadioButton rbu2 = (RadioButton) findViewById(R.id.radioButtonHdfc);
                RadioButton rbu3 = (RadioButton) findViewById(R.id.radioButtonAxis);
                switch (id) {
                    case -1:
                        Toast.makeText(Reservation.this,
                                "Incorrect Selction!!", Toast.LENGTH_LONG)
                                .show();
                        break;
                    case R.id.Rd_tsest1:
                        rbu2.setChecked(true);
                        rbu3.setEnabled(false);
                        break;
                    case R.id.test2t:
                        rbu3.setEnabled(true);
                        rbu3.setChecked(true);
                        break;
                    default:
                        break;
                }
            }
        });

        //On button check availability

        Button buttonChkavail = (Button) findViewById(R.id.Btn_ChkAvailbility);
        buttonChkavail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ChkInDate = (EditText) findViewById(R.id.edt_ChkInDate);
                GetCheckIn = ChkInDate.getText().toString();
                final Dialog dialog = new Dialog(Reservation.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                // Include dialog.xml file
                dialog.setContentView(R.layout.activity_show_availability);
          //    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.green(1)));
                //Set dialog title
                dialog.setTitle("Haryana Tourism Room Available");
                TextView text = (TextView) dialog.findViewById(R.id.CheckdateOne);
                text.setText(GetCheckIn);
                Integer  GetSelDate= Integer.parseInt( GetCheckIn.substring( 0, GetCheckIn.indexOf("-")));
                String  GetSelMon=  GetCheckIn.substring(GetCheckIn.indexOf("-") + 1, GetCheckIn.lastIndexOf("-"));
                Integer  GetSelYear=Integer.parseInt(GetCheckIn.substring(GetCheckIn.lastIndexOf("-") + 1, GetCheckIn.length()));
                Integer MonthOfSel=  monthStringToInt(GetSelMon);
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.DATE, GetSelDate+1);
                cal.set(Calendar.MONTH, MonthOfSel-1);
                cal.set(Calendar.YEAR, GetSelYear);
                Date GetdAtetwo=cal.getTime();
                String myFormat = "dd-MMM-yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                TextView textSec = (TextView) dialog.findViewById(R.id.CheckdateTwo);
                textSec.setText(sdf.format(GetdAtetwo.getTime()));
                cal.add(Calendar.DATE, 1);

                TextView textThree = (TextView) dialog.findViewById(R.id.CheckdateThree);
                textThree.setText(sdf.format(cal.getTime()));
                cal.add(Calendar.DATE, 1);

                TextView textFour = (TextView) dialog.findViewById(R.id.Checkdatefour);
                textFour.setText(sdf.format(cal.getTime()));
                cal.add(Calendar.DATE, 1);

                TextView textFive = (TextView) dialog.findViewById(R.id.Checkdatefive);
                textFive.setText(sdf.format(cal.getTime()));
                cal.add(Calendar.DATE, 1);

                textRsrtValue = (TextView) dialog.findViewById(R.id.GetResortName);
                textTariffValue = (TextView) dialog.findViewById(R.id.GetTariff);
                textFirstDtValue = (TextView) dialog.findViewById(R.id.GetdateOne);
                textSecDtValue = (TextView) dialog.findViewById(R.id.GetdateTwo);
                textThrdDtValue = (TextView) dialog.findViewById(R.id.GetdateThree);
                textForthDtValue = (TextView) dialog.findViewById(R.id.Getdatefour);
                textFiveDtValue = (TextView) dialog.findViewById(R.id.Getdatefive);
                dialog.show();
                ///Validation////////////////////

                final EditText ChkOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
                GetCheckOut = ChkOutDate.getText().toString();
                RsrtName = sp1.getSelectedItem().toString();
                final String CatgryName = sp2.getSelectedItem().toString();
                CatName = CatgryName.substring(CatgryName.indexOf(",") + 1, CatgryName.indexOf("("));
                GetSecserchDt = textSec.getText().toString();
                GetThrdserchDt = textThree.getText().toString();
                GetForthserchDt = textFour.getText().toString();
                GetFiveserchDt = textFive.getText().toString();
                // Call web service
                //=================== ====================
                CheckAvailbilityAsynctask checkAvailabilityTask= new CheckAvailbilityAsynctask();
                checkAvailabilityTask.execute();

                //=======================================
                ///////////////Button Exit
            }
        });

        //calculate amount

        //Button Click/////////////////
        Button buttonCal = (Button) findViewById(R.id.Btn_CalAmt);
        buttonCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                ///Validation////////////////////
                ChkInDate = (EditText) findViewById(R.id.edt_ChkInDate);
                GetCheckInDate = ChkInDate.getText().toString();
                final EditText ChkOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
                getChkOutDate = ChkOutDate.getText().toString();
                RName = sp1.getSelectedItem().toString();
                CatgryName = sp2.getSelectedItem().toString();
                NoOfRooms = sp3.getSelectedItem().toString();
                CtName = CatgryName.substring(CatgryName.indexOf(",") + 1, CatgryName.indexOf("("));
                calAmt = (TextView) findViewById(R.id.edt_TaxAmount);
                //end validation
                // Call web service

                //=================== ====================
                AmountCalculateAsynctask calAmounttask = new AmountCalculateAsynctask();
                calAmounttask.execute();

                //=======================================
                ///////////////Button Exit
            }
        });

      button = (Button) findViewById(R.id.Btn_Submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ///Validation////////////////////
                ChkInDate=(EditText)findViewById(R.id.edt_ChkInDate);
                GetCheckInDate = ChkInDate.getText().toString();
                ChkOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
                getChkOutDate = ChkOutDate.getText().toString();
                if (getChkOutDate.equals("") || getChkOutDate.equals("0")) {
                    Toast.makeText(Reservation.this, "Enter Valid CheckOutDate", Toast.LENGTH_LONG).show();
                    ChkOutDate.requestFocus();
                    return;
                }
                //end validation
                RName = sp1.getSelectedItem().toString();
                CatName = sp2.getSelectedItem().toString();
                CtName = CatName.substring(CatName.indexOf(",") + 1, CatName.indexOf("("));
                NoOfRooms = sp3.getSelectedItem().toString();
                CName = (EditText) findViewById(R.id.edt_CustName);
                CusName = CName.getText().toString();
                if (CusName.equals("") || CusName.equals("0")) {
                    CName.setError("Enter Customer Name");
                    CName.requestFocus();
                    return;
                }
                //   final EditText CAdd = (EditText) findViewById(R.id.edt_);
                //    final String CusAdd=CName.getText().toString();
                CEmailId = (EditText) findViewById(R.id.edt_EmailId);
                CusEId = CEmailId.getText().toString();
                if (CusEId.equals("") || CusEId.equals("0")) {
                    CEmailId.setError("Enter Email Id");
                    return;
                }

               CPhoneNo = (EditText) findViewById(R.id.edt_PhoneNum);
                CusPhNO = CPhoneNo.getText().toString();
                if (CusPhNO.equals("") || CusPhNO.equals("0")) {
                    CPhoneNo.setError("Enter Phone Number");
                    return;
                }
                CusIdentityProf = sp4.getSelectedItem().toString();
                CusNationality = sp5.getSelectedItem().toString();
                LoginId = (EditText) findViewById(R.id.edt_loginid);
                CustLoginId = LoginId.getText().toString();
                TaxAmt = (TextView) findViewById(R.id.edt_TaxAmount);
                CustTax = TaxAmt.getText().toString();
                buttonCalAmt = (Button) findViewById(R.id.Btn_CalAmt);
                if (CustTax.equals("") || CustTax.equals("0")) {
                    buttonCalAmt.requestFocus();
                    Toast.makeText(Reservation.this, "Calculate  Amount..", Toast.LENGTH_LONG).show();
                    return;
                }
                final TextView RCalAmt = (TextView) findViewById(R.id.edt_TaxAmt);
               radioGroup = (RadioGroup) findViewById(R.id.radiogrp);
                // get selected radio button from radioGroup
                int selectedId = radioGroup.getCheckedRadioButtonId();
                // find the radiobutton by returned id
                 radioButton = (RadioButton) findViewById(selectedId);
                //Recalculate AmountTo be paid
                // Call web service
                //=================== ====================
                new Thread() {
                    @Override
                    public void run() {
                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME5);
                        request.addProperty("Checkin", GetCheckInDate);
                        request.addProperty("CheckOut", getChkOutDate);
                        request.addProperty("NoOfUnits", NoOfRooms);
                        request.addProperty("DestCode", RName);
                        request.addProperty("UnitType", CtName);

                        //Declare the version of the SOAP request
                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                        envelope.setOutputSoapObject(request);
                        envelope.dotNet = true;

                        try {
                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                            //this is the actual part that will call the webservice
                            androidHttpTransport.call(SOAP_ACTION5, envelope);
                            // Get the SoapResult from the envelope body.
                            SoapObject result = (SoapObject) envelope.bodyIn;

                            if (result != null) {
                                //Get the first property and change the label text

                                SubmitRes = result.getProperty(0).toString();
                                GetTotAmtFinal=SubmitRes.substring( 0, abb.indexOf("/"));
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (GetTotAmtFinal.equals(CustTax)) {
                                            CheckBox cb1 = (CheckBox) findViewById(R.id.Chk_Box);
                                            if (cb1.isChecked() == true) {
                                                SoapSubmitPayment submitPaymenttask = new SoapSubmitPayment();
                                                submitPaymenttask.execute();
                                            }
                                            else
                                            {
                                                Toast.makeText(Reservation.this, "Please Accept the terms and conditions.", Toast.LENGTH_LONG).show();
                                            }

                                        } else {
                                            Toast.makeText(Reservation.this, "Recalculate Amount..", Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });

                            } else {

                                Toast.makeText(getApplicationContext(), "No Response", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }
                    }
                }.start();
                ///////////////Button Exit
            }
        });
        //=======================================
        /////////Call dist name method
        GetDistNameAsynctask DistNameTask = new GetDistNameAsynctask();
        DistNameTask.execute();

    }     ///////////////Button Exit


    public class myWebClient extends WebViewClient
    {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            // TODO Auto-generated method stub
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            // TODO Auto-generated method stub

            view.loadUrl(url);
            return true;

        }
    }

        private void findViewsById() {
        fromDateEtxt = (EditText) findViewById(R.id.edt_ChkInDate);
        fromDateEtxt.setInputType(InputType.TYPE_NULL);
                 fromDateEtxt.requestFocus();

        toDateEtxt = (EditText) findViewById(R.id.edt_chkOutDate);
        toDateEtxt.setInputType(InputType.TYPE_NULL);
    }
    private void setDateTimeField() {
        fromDateEtxt.setOnClickListener(this);
        toDateEtxt.setOnClickListener(this);

        Calendar newCalendar = Calendar.getInstance();
        fromDatePickerDialog = new DatePickerDialog(this, new OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                fromDateEtxt.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        String myFormat = "dd-MMM-yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        fromDateEtxt.setText(sdf.format(newCalendar.getTime()));
        Date newDate2 = newCalendar.getTime();
        fromDatePickerDialog.getDatePicker().setMinDate(newDate2.getTime());





        newCalendar.add(Calendar.DATE, 1);
        toDatePickerDialog = new DatePickerDialog(this, new OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                toDateEtxt.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        String myFormatTo = "dd-MMM-yyyy"; //In which you need put here
        SimpleDateFormat sdfTo = new SimpleDateFormat(myFormatTo, Locale.US);
        toDateEtxt.setText(sdfTo.format(newCalendar.getTime()));
        Date newDate23 = newCalendar.getTime();
        toDatePickerDialog.getDatePicker().setMinDate(newDate23.getTime());
    }


    @Override
    public void onClick(View view) {
        if(view == fromDateEtxt) {
            fromDatePickerDialog.show();
        } else if(view == toDateEtxt) {
            toDatePickerDialog.show();
        }
    }

    /////////////Async task  of method 6 ////////////
    private class GetDistNameAsynctask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME6);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION6, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();
                        ArrayList<spinerobj> Distts = new ArrayList<spinerobj>();
                        try {
                            JSONObject jsonResponse = new JSONObject(abb);
                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");
                            if (jsonArray != null) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject youValue = jsonArray.getJSONObject(i);
                                    String idModule = youValue.getString("DistrictName");
                                    String id = youValue.getString("DistrictID");
                                    Distts.add(new spinerobj(id, idModule));
                                }
                            }
                            Spinner spDistt = (Spinner) findViewById(R.id.spin_Distt);
                            ArrayAdapter<spinerobj> dataAdapter = new ArrayAdapter<spinerobj>(Reservation.this,
                                    android.R.layout.simple_spinner_item, Distts);
                            // Drop down layout style - list view with radio button
                            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spDistt.setAdapter(dataAdapter);

                        } catch (JSONException e) {
                            Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }
            }
        }}
    ////////////End Async task////////////

     @Override
     public boolean onOptionsItemSelected(MenuItem item) {
         // Handle action bar item clicks here. The action bar will
         // automatically handle clicks on the Home/Up button, so long
         // as you specify a parent activity in AndroidManifest.xml.
         Restid = String.valueOf(item.getItemId());
         //call Web service for spinner resort names
         SoapAccessGetUNitType taskUnittype = new SoapAccessGetUNitType();
         taskUnittype.execute();
         //End Web service resort name
         //call Web service for spinner resort names
         if (id == R.id.action_settings) {
             return true;
         }
         return super.onOptionsItemSelected(item);
     }

    private static int monthStringToInt(String month) {
     int monthInt=0;
        int January = Integer.valueOf (Calendar.JANUARY);

        if (month.equals("Jan"))
                  {
                    monthInt = 1;
                   }
        if (month.equals("Feb"))
        {
            monthInt = 2;
        }
        if (month.equals("Mar"))
        {
            monthInt = 3;
        }
        if (month.equals("Apr"))
        {
            monthInt = 4;
        }
        if (month.equals("May"))
        {
            monthInt = 5;
        }
        if (month.equals("Jun"))
        {
            monthInt = 6;
        }
        if (month.equals("Jul"))
        {
            monthInt = 7;
        }
        if (month.equals("Aug"))
        {
            monthInt = 8;
        }
        if (month.equals("Sep"))
        {
            monthInt = 9;
        }
        if (month.equals("Oct"))
        {
            monthInt = 10;
        }
        if (month.equals("Nov"))
        {
            monthInt = 11;
        }
        if (month.equals("Dec"))
        {
            monthInt = 12;
        }

        return monthInt;

    }


    @Override
    public void onBackPressed()
    {
       super.finish();
        Intent intent = new Intent(Reservation.this, NavigationScreen.class);
        startActivity(intent);
//        finish();
    }

    /////////////Async task  of method 1////////////
    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("DDistrict", Restid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                abb = result.toString();
                        ArrayList<spinerobj> Resorts = new ArrayList<spinerobj>();
                        try {
                            JSONObject jsonResponse = new JSONObject(abb);
                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");

                            final String[] items = new String[jsonArray.length()];
                            if (jsonArray != null) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject youValue = jsonArray.getJSONObject(i);
                                    String idModule = youValue.getString("dest_name");
                                    String id = youValue.getString("dest_code");
                                    Resorts.add(new spinerobj(id, idModule));
                                    // Use the same for remaining values
                                }
                            }
                            Spinner sp = (Spinner) findViewById(R.id.spin_Resort);

                            ArrayAdapter<spinerobj> dataAdapter = new ArrayAdapter<spinerobj>(Reservation.this,
                                    android.R.layout.simple_spinner_item, Resorts);
                            // Drop down layout style - list view with radio button
                            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            sp.setAdapter(dataAdapter);

                        } catch (JSONException e) {
                            Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }
            }
        }}
    ////////////End Async task////////////

    /////////////Async task  of method 2 ////////////
    private class SoapAccessGetUNitType extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
                request.addProperty("Ddl_Resort", Restid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION2, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();

                        ArrayList<String> Resorts = new ArrayList<String>();
                        try {
                            JSONObject jsonResponse = new JSONObject(abb);
                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");

                            final String[] items = new String[jsonArray.length()];
                            if (jsonArray != null) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject youValue = jsonArray.getJSONObject(i);
                                    String idModule = youValue.getString("unittype1");
                                    String id = youValue.getString("unit_type");
                                    Resorts.add(idModule);
                                    // Use the same for remaining values
                                }
                            }
                            Spinner sp = (Spinner) findViewById(R.id.spin_RoomCat);
                            sp.setAdapter(new ArrayAdapter<String>(Reservation.this, R.layout.support_simple_spinner_dropdown_item, Resorts));
                        } catch (JSONException e) {
                            Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }
            }        }}
    ////////////End Async task////////////



    /////////////Async task  of method 3  ////////////
    private class SoapGetNoRooms extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME3);
                request.addProperty("Ddl_Resort", RsortName);
                request.addProperty("UnitName", CatyName);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION3, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();
                if(ProgressD != null){
                    ProgressD.dismiss();
                }
                        ArrayList<String> UnitsNo = new ArrayList<String>();
                        try {
                            JSONObject jsonResponse = new JSONObject(abb);
                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");
//                            final String[] items = new String[jsonArray.length()];
                            if (jsonArray != null) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject youValue = jsonArray.getJSONObject(i);
                                    String idModule = youValue.getString("unit_no");
                                    int NoRooms = Integer.parseInt(youValue.getString("unit_no"));
                                    // String id = youValue.getString("unit_type");
                                    for (int j = 1; j <= NoRooms; j++) {
                                        UnitsNo.add(String.valueOf(j));
                                    }
                                }
                            }
                            Spinner sp = (Spinner) findViewById(R.id.spin_NoOfRooms);
                            sp.setAdapter(new ArrayAdapter<String>(Reservation.this, R.layout.support_simple_spinner_dropdown_item, UnitsNo));
                        } catch (JSONException e) {
                            Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }
            }
        }}
    ////////////End Async task////////////


    /////////////Async task  of method 4 ////////////
    private class SoapSubmitPayment extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME4);
                request.addProperty("Login", CustLoginId);
                request.addProperty("NoUnits", NoOfRooms);
                request.addProperty("CustName", CusName);
                request.addProperty("CustAdd", "ABC");
                request.addProperty("EmailId", CusEId);
                request.addProperty("PhoneNo", CusPhNO);
                request.addProperty("DestName", RName);
                request.addProperty("UnitName", CtName);
                request.addProperty("CheckIn", GetCheckInDate);
                request.addProperty("CheckOut", getChkOutDate);
                request.addProperty("PaymentMode",  radioButton.getText());
                request.addProperty("Discount", "0");
                request.addProperty("IdProof", CusIdentityProf);
                request.addProperty("Nationality", CusNationality);
                request.addProperty("PPno", "TEST");
                request.addProperty("PAmount", CustTax);
                request.addProperty("ServiceTax", GetServiceTax);
                request.addProperty("LuxuryTax", GetLuxuryTax);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION4, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                abb = result.toString();
                //Get the first property and change the label text
                        if (radioButton.getText().equals("AXIS")) {
                            if (abb.toString().contains("http://")) {
                                //if (SubmitRes.equals("http")) {
                                Intent inte = new Intent(getApplicationContext(), WebViewActivity.class);
                                inte.putExtra("URL", abb);
                                startActivity(inte);

                            } else if (abb.equals("9")) {
                                Toast.makeText(Reservation.this,
                                        "No Rooms Available!!", Toast.LENGTH_LONG)
                                        .show();
                            } else {
                                Toast.makeText(Reservation.this,
                                        "Some Error Occured!!", Toast.LENGTH_LONG)
                                        .show();
                            }
                        }
                        else if (radioButton.getText().equals("HDFC")) {

                            if (abb.toString().contains("http://")) {
                                //if (SubmitRes.equals("http")) {
                                Intent inte = new Intent(getApplicationContext(), WebViewHDFC.class);
                                inte.putExtra("URL", abb);
                                inte.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(inte);

                            } else if (abb.equals("9")) {
                                Toast.makeText(Reservation.this,
                                        "No Rooms Available!!", Toast.LENGTH_LONG)
                                        .show();

                            }
                            else {
                                Toast.makeText(Reservation.this,
                                        "Some Error Occured!!", Toast.LENGTH_LONG)
                                        .show();

                            }
                        }
                    }
    }}
    ////////////End Async task////////////

    /////////////Async task  of method 5 ////////////
    private class AmountCalculateAsynctask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME5);
                request.addProperty("Checkin", GetCheckInDate);
                request.addProperty("CheckOut", getChkOutDate);
                request.addProperty("NoOfUnits", NoOfRooms);
                request.addProperty("DestCode", RName);
                request.addProperty("UnitType", CtName);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION5, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();

                        if (abb.toString().contains("Booking")) {
                            Toast.makeText(Reservation.this,
                                    abb, Toast.LENGTH_LONG)
                                    .show();
                        } else {
                            GetTotalAmt=abb.substring( 0, abb.indexOf("/"));
                            GetServiceTax=abb.substring(abb.indexOf("/") + 1, abb.lastIndexOf("/"));
                            GetLuxuryTax=abb.substring(abb.lastIndexOf("/") + 1, abb.length());
                            calAmt.setText(GetTotalAmt);
                            button.setFocusable(true);
                            button.setFocusableInTouchMode(true);
                            button.requestFocus();

                        }
            }
        }}
    ////////////End Async task////////////

    /////////////Async task  of method 7////////////
    private class CheckAvailbilityAsynctask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME7);
                request.addProperty("DestName",RsrtName);
                request.addProperty("unitType",CatName);
                request.addProperty("DateFrm", GetCheckIn);
                request.addProperty("DateTo",GetCheckOut);

                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION7, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(Reservation.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(Reservation.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();
                        ArrayList<String> list = new ArrayList<String>();
                        try {
                            JSONArray jsonArray = new JSONArray(abb);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject youValue = jsonArray.getJSONObject(i);
                                textRsrtValue.setText(youValue.getString("Category"));
                                textTariffValue.setText(youValue.getString("Tariff"));
                                textFirstDtValue.setText(youValue.getString(GetCheckIn));
                                textSecDtValue.setText(youValue.getString(GetSecserchDt));
                                textThrdDtValue.setText(youValue.getString(GetThrdserchDt));
                                textForthDtValue.setText(youValue.getString(GetForthserchDt));
                                textFiveDtValue.setText(youValue.getString(GetFiveserchDt));
                            }
                        }
                        catch (JSONException e)
                        {
                            Toast.makeText(Reservation.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                        }

            }
        }}
    ////////////End Async task////////////

    //////////////Check internet connectivity
    public static boolean isNetworkAvailable(final Context context) {
        boolean isNetAvailable = false;
        if (context != null) {
            final ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (mConnectivityManager != null) {
                final NetworkInfo activeNetwork = mConnectivityManager.getActiveNetworkInfo();
                if(activeNetwork != null) isNetAvailable = true;
            }
        }
        return isNetAvailable;
    }
    //////////////////End internet connectivity

 }
