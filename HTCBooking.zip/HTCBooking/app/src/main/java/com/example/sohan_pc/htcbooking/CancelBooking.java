package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.NullSoapObject;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpResponseException;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;

public class CancelBooking extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/GetAmtToRefund";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetAmtToRefund";
    private static String SOAP_ACTION2 = "http://tempuri.org/CancelBooking";
    private static String METHOD_NAME2 = "CancelBooking";
    private static String METHOD_NAME3 = "AlreadyCancelled";
    private static String SOAP_ACTION3 = "http://tempuri.org/AlreadyCancelled";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    ProgressDialog pDialog;
    private SoapObject result = null;
    String MesgToShw="Successful";


    private GridView gridView;
    String messagecustid,destname,Roomcat,RomsBooked,BookingFrm,BookingTo,CancelFrm,AmtPaid,SrialNo,NoRows,RoomNos,useerLogin,EmailAd,MobNo,CustomerName,EntryDt,Paymode,Paymodeno,PayRcdBy;
    String GetRoomsCancelled,GetCheckIn,GetCheckOut,refundAmt,ip;
    //    private EditText fromDateEtxt;
//    private EditText toDateEtxt;
    EditText CnclFrom,CanclDateTo;


    private DatePickerDialog fromDatePickerDialog;
    private DatePickerDialog toDatePickerDialog;

    private SimpleDateFormat dateFormatter;
    // Session Manager Class
    SessionManagement session;

    TextView CalRefndAmt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_cancel_booking);
        final EditText CusId = (EditText) findViewById(R.id.edt_loginid);
//        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
//        txtProgress=(TextView)findViewById(R.id.txtProgress) ;
        // Session class instance
        session = new SessionManagement(getApplicationContext());

        if (getIntent().hasExtra("CustId")) {
            messagecustid = getIntent().getStringExtra("CustId").toString();
            CusId.setText(messagecustid);
        }
        final TextView Resort = (TextView) findViewById(R.id.TouristRest);
        if (getIntent().hasExtra("destname")) {
            destname = getIntent().getStringExtra("destname").toString();
            Resort.setText(destname);
        }
        final TextView Cat = (TextView) findViewById(R.id.Categry);
        if (getIntent().hasExtra("Roomcat")) {
            Roomcat = getIntent().getStringExtra("Roomcat").toString();
            Cat.setText(Roomcat);
        }
        final TextView roomsBk = (TextView) findViewById(R.id.Noofrooms);
        final EditText Roomscl = (EditText) findViewById(R.id.edt_RoomsTocncl);
        if (getIntent().hasExtra("RomsBooked")) {
            RomsBooked = getIntent().getStringExtra("RomsBooked").toString();
            roomsBk.setText(RomsBooked);
            Roomscl.setText(RomsBooked);
        }
        final TextView BookFrm = (TextView) findViewById(R.id.Bookingfrm);
        if (getIntent().hasExtra("BookingFrm")) {
            BookingFrm = getIntent().getStringExtra("BookingFrm").toString();
            BookFrm.setText(BookingFrm);
        }
        final TextView BookTo = (TextView) findViewById(R.id.BookingTo);
        if (getIntent().hasExtra("BookingTo")) {
            BookingTo = getIntent().getStringExtra("BookingTo").toString();
            BookTo.setText(BookingTo);
        }
        CnclFrom = (EditText) findViewById(R.id.edt_cancelfrm);
        if (getIntent().hasExtra("CancelFrm")) {
            CancelFrm = getIntent().getStringExtra("CancelFrm").toString();
            CnclFrom.setText(CancelFrm);
            Log.e("CancelFrm =", CancelFrm);
        }
        final TextView Amtpd = (TextView) findViewById(R.id.AmtPaid);
        if (getIntent().hasExtra("AmtPaid")) {
            AmtPaid = getIntent().getStringExtra("AmtPaid").toString();
            Amtpd.setText(AmtPaid);
        }
        if (getIntent().hasExtra("SerialNo")) {
            SrialNo = getIntent().getStringExtra("SerialNo").toString();
        }
        if (getIntent().hasExtra("NoOfRws")) {
            NoRows = getIntent().getStringExtra("NoOfRws").toString();
        }
        if (getIntent().hasExtra("arrival_date")) {
            RoomNos = getIntent().getStringExtra("arrival_date").toString();
        }
        if (getIntent().hasExtra("UserLogin")) {
            useerLogin = getIntent().getStringExtra("UserLogin").toString();
        }
        if (getIntent().hasExtra("EmailAdd")) {
            EmailAd = getIntent().getStringExtra("EmailAdd").toString();
        }
        if (getIntent().hasExtra("MolieNo")) {
            MobNo = getIntent().getStringExtra("MolieNo").toString();
        }
        if (getIntent().hasExtra("CustName")) {
            CustomerName = getIntent().getStringExtra("CustName").toString();
        }
        if (getIntent().hasExtra("Entrydate")) {
            EntryDt = getIntent().getStringExtra("Entrydate").toString();
        }
        if (getIntent().hasExtra("PayMode")) {
            Paymode = getIntent().getStringExtra("PayMode").toString();
        }
        if (getIntent().hasExtra("PaymodeNo")) {
            Paymodeno = getIntent().getStringExtra("PaymodeNo").toString();
        }
        if (getIntent().hasExtra("PayRecdby")) {
            PayRcdBy = getIntent().getStringExtra("PayRecdby").toString();
        }

        //   Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        String name = user.get(SessionManagement.KEY_NAME);
        Log.e("name =", name);

        // email
        String email = user.get(SessionManagement.KEY_EMAIL);
        Log.e("email =", email);
        // mobile
        String mobile = user.get(SessionManagement.KEY_MOBILE);
        Log.e("mobile =", mobile);

        final ImageView Btn_Logout = (ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    session.logoutUser();
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(CancelBooking.this, "Please try again !!s", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final ImageView Btn_Home = (ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), cancellationActivity.class);
                    inte.putExtra("MobileNo", useerLogin);
                    inte.putExtra("MailId", EmailAd);
                    inte.putExtra("Contactno", MobNo);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(CancelBooking.this, "Please try again !!", Toast.LENGTH_SHORT).show();
                }
            }
        });

       dateFormatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.US);
//        dateFormatter = new SimpleDateFormat("M-d-yyyy", Locale.US);

        findViewsById();

        setDateTimeField();

        CalRefndAmt = (TextView) findViewById(R.id.edt_TaxAmount);


        //Button Click/////////////////
        Button buttonCal = (Button) findViewById(R.id.Btn_CalAmtRefund);
        buttonCal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ///Validation////////////////////
                CnclFrom = (EditText) findViewById(R.id.edt_cancelfrm);
                GetCheckIn = CnclFrom.getText().toString();
                CanclDateTo = (EditText) findViewById(R.id.edt_cancelTo);
                GetCheckOut = CanclDateTo.getText().toString();
                if (GetCheckIn.equals("") || GetCheckIn.equals("0")) {
                    CnclFrom.setFocusable(true);
                    Toast.makeText(CancelBooking.this, "Select Cancel Date From", Toast.LENGTH_LONG).show();
                    return;
                }
                if (GetCheckOut.equals("") || GetCheckOut.equals("0")) {
                    CanclDateTo.setFocusable(true);
                    Toast.makeText(CancelBooking.this, "Select Cancel Date To", Toast.LENGTH_LONG).show();
                    return;
                }

                final EditText Cancelrooms = (EditText) findViewById(R.id.edt_RoomsTocncl);
                GetRoomsCancelled = Cancelrooms.getText().toString();

                if (GetRoomsCancelled.equals("") || GetRoomsCancelled.equals("0")) {
                    Cancelrooms.setFocusable(true);
                    Toast.makeText(CancelBooking.this, "Select Rooms To Cancel", Toast.LENGTH_LONG).show();
                    return;
                }
                SoapAccessTask task = new SoapAccessTask();
                task.execute();
                //CalculateAmount();

            }
        });
        //=======================================
        ///////////////Button Exit

        //Button Cancel Booking
        Button but = (Button) findViewById(R.id.BtnCancelbooking);

        but.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                cancelbookingSubmit_Button();

            }
        });

        AlreadyCancelledTask alreadycancelTask = new AlreadyCancelledTask();
        alreadycancelTask.execute();
    }

    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("NoofUnits", RomsBooked);
                request.addProperty("CancelRooms", GetRoomsCancelled);
                request.addProperty("Srno", SrialNo);
                request.addProperty("Noofrows", NoRows);
                request.addProperty("Cancelfrom", GetCheckIn);
                request.addProperty("CancelTo", GetCheckOut);
                request.addProperty("custid", messagecustid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(CancelBooking.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(CancelBooking.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
           pDialog.dismiss();
            if (result != null) {
                SubmitRes = result.toString();
                        if (SubmitRes.toString().contains("date") || SubmitRes.toString().contains("rooms")) {
                            Toast.makeText(CancelBooking.this,SubmitRes, Toast.LENGTH_LONG).show();
                        }
                        else if (SubmitRes.equals("A")) {
                             Toast.makeText(CancelBooking.this,"Some Error Occured", Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            CalRefndAmt.setText(SubmitRes);
                        }
                    }
        }
    }



//    public void CalculateAmount()
//    {
//        ///Validation////////////////////
//        CnclFrom = (EditText) findViewById(R.id.edt_cancelfrm);
//        GetCheckIn = CnclFrom.getText().toString();
//        CanclDateTo = (EditText) findViewById(R.id.edt_cancelTo);
//        GetCheckOut = CanclDateTo.getText().toString();
//        if (GetCheckIn.equals("") || GetCheckIn.equals("0")) {
//            CnclFrom.setFocusable(true);
//            Toast.makeText(CancelBooking.this, "Select Cancel Date From", Toast.LENGTH_LONG).show();
//            return;
//        }
//        if (GetCheckOut.equals("") || GetCheckOut.equals("0")) {
//            CanclDateTo.setFocusable(true);
//            Toast.makeText(CancelBooking.this, "Select Cancel Date To", Toast.LENGTH_LONG).show();
//            return;
//        }
//
//        final EditText Cancelrooms = (EditText) findViewById(R.id.edt_RoomsTocncl);
//        GetRoomsCancelled = Cancelrooms.getText().toString();
//
//        if (GetRoomsCancelled.equals("") || GetRoomsCancelled.equals("0")) {
//            Cancelrooms.setFocusable(true);
//            Toast.makeText(CancelBooking.this, "Select Rooms To Cancel", Toast.LENGTH_LONG).show();
//            return;
//        }
//        // SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//        // String Ndate = formatter.format(GetCheckIn);
//        //end validation
//        // Call web service
//        //=================== ====================
//        new Thread() {
//            @Override
//            public void run() {
////                Log.e("RoomNos =", RoomNos);
//                RoomNos="";
//                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                request.addProperty("NoofUnits", RomsBooked);
//                request.addProperty("CancelRooms", GetRoomsCancelled);
//                request.addProperty("Srno", SrialNo);
//                request.addProperty("Noofrows", NoRows);
//                request.addProperty("Cancelfrom", GetCheckIn);
//                request.addProperty("CancelTo", GetCheckOut);
//                request.addProperty("custid", messagecustid);
////                request.addProperty("RoomNo", RoomNos);       //RoomNos
//
//
//
//
//
//
//                //Declare the version of the SOAP request
//                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                envelope.setOutputSoapObject(request);
//                envelope.dotNet = true;
//
//                try {
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                    //this is the actual part that will call the webservice
//                    androidHttpTransport.call(SOAP_ACTION1, envelope);
//
//
//                    // Get the SoapResult from the envelope body.
//                    result = (SoapObject) envelope.bodyIn;
//                    Log.e("result of calculation", String.valueOf(result));
//                    ;
//                    if (result != null) {
//                        SubmitRes = result.getProperty(0).toString();
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//
//                                if (SubmitRes.toString().contains("date") || SubmitRes.toString().contains("rooms")) {
//
//
//                                    Toast.makeText(CancelBooking.this,
//                                            SubmitRes, Toast.LENGTH_LONG)
//                                            .show();
//                                    Log.e(SubmitRes,"contains date & room");
//                                } else if (SubmitRes.equals("A")) {
//
//
//                                    Toast.makeText(CancelBooking.this,
//                                            "Some Error Occured", Toast.LENGTH_LONG)
//                                            .show();
//                                }
//                                else {
//
//                                    CalRefndAmt.setText(SubmitRes);
//                                }
//
//                            }
//                        });
//
//                    } else {
//
//                        //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                    }
//                } catch (Exception e) {
//
//                    e.printStackTrace();
//
//                }
//            }
//        }.start();
//
//    }

    public void cancelbookingSubmit_Button() {
        {
            ///Validation////////////////////
//            CnclFrom = (EditText) findViewById(R.id.edt_cancelfrm);
            GetCheckIn = CnclFrom.getText().toString();
//           CanclDateTo = (EditText) findViewById(R.id.edt_cancelTo);
            GetCheckOut = CanclDateTo.getText().toString();


//                if (GetCheckIn.equals("") || GetCheckIn.equals("0")) {
//                    CanclDateFrm.setFocusable(true);
//                    Toast.makeText(CancelBooking.this, "Select Cancel Date From", Toast.LENGTH_LONG).show();
//                    return;
//                }
//                if (GetCheckOut.equals("") || GetCheckOut.equals("0")) {
//                    CanclDateTo.setFocusable(true);
//                    Toast.makeText(CancelBooking.this, "Select Cancel Date To", Toast.LENGTH_LONG).show();
//                    return;
//                }


            final EditText Cancelrooms = (EditText) findViewById(R.id.edt_RoomsTocncl);
            GetRoomsCancelled = Cancelrooms.getText().toString();

            refundAmt = CalRefndAmt.getText().toString();
            SoapCancelbookingSubmit_Button task = new SoapCancelbookingSubmit_Button();
            task.execute();

//                if (GetRoomsCancelled.equals("") || GetRoomsCancelled.equals("0")) {
//                    Cancelrooms.setFocusable(true);
//                    Toast.makeText(CancelBooking.this, "Select Rooms To Cancel", Toast.LENGTH_LONG).show();
//                    return;
//                }

            // Call web service
            //==================== ====================
//            new Thread() {
//                @Override
//                public void run() {
////                    TextView CalRefndAmt = (TextView) findViewById(R.id.edt_TaxAmount);
//                    refundAmt = CalRefndAmt.getText().toString();
//                    ip = getLocalIpAddress();
//                    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
//                    request.addProperty("TotalRooms", RomsBooked);
//                    request.addProperty("RoomsToCnl", GetRoomsCancelled);
//                    request.addProperty("CncalDatrfrom", GetCheckIn);
//                    request.addProperty("cncldateTo", GetCheckOut);
//                    request.addProperty("Bookingfrom", BookingFrm);
//                    request.addProperty("BookingTo", BookingTo);
//                    request.addProperty("custid", messagecustid);
//                    request.addProperty("Custsrno", SrialNo);
//                    request.addProperty("Custname", CustomerName);
//                    request.addProperty("Custadd", messagecustid);
//                    request.addProperty("Email", EmailAd);
//                    request.addProperty("Phone", MobNo);
//                    request.addProperty("RefundAmt", refundAmt);
//                    request.addProperty("Entrydate", EntryDt);
//                    request.addProperty("UserLogin", useerLogin);
//                    request.addProperty("Paymode", Paymode);
//                    request.addProperty("Paymodeno", Paymodeno);
//                    request.addProperty("PayRecdBy", PayRcdBy);
////                    request.addProperty("roomNo", RoomNos);
//                    request.addProperty("Noofrows", NoRows);
//                    request.addProperty("IPaddress", ip);
//
//                    //Declare the version of the SOAP request
//                    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                    envelope.setOutputSoapObject(request);
//                    envelope.dotNet = true;
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL,60000);
//
//                    try {
//                        //this is the actual part that will call the webservice
//                        androidHttpTransport.debug = true;
//                        androidHttpTransport.call(SOAP_ACTION2, envelope);
////                        result = null;
//                        // Get the SoapResult from the envelope body.
//                        result = (SoapObject) envelope.bodyIn;
//                        Log.e(String.valueOf(result), "result of cancel booking button");
//                        for (int i = 0; i < result.getPropertyCount(); i++) {
//
//                            SubmitRes = result.getProperty(i).toString();
//
//
//                        }
//
////                        if (result != null) {
////                            //Get the first property and change the label text
////
////                            //changes by Himani
////
////
////                            SubmitRes = result.getProperty(0).toString();
//
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                if (SubmitRes.toString().contains("Recalculate Amount")) {
//                                    Toast.makeText(CancelBooking.this, SubmitRes, Toast.LENGTH_SHORT).show();
//
//                                } else if (SubmitRes.toString().contains("You cannot do the Cancellation for the" + "&  and previous date")) {
//                                    Toast.makeText(CancelBooking.this, SubmitRes, Toast.LENGTH_SHORT).show();
//                                } else if (SubmitRes.toString().contains("You have already checked in. Cannot cancelled for same date.")) {
//                                    Toast.makeText(CancelBooking.this, SubmitRes, Toast.LENGTH_LONG).show();
//                                } else if (!SubmitRes.toString().contains("/")) {
////                                         if (SubmitRes.toString().contains("1")) {
//                                    Log.e(SubmitRes, "Amount to refund");
//                                    Toast.makeText(CancelBooking.this, MesgToShw, Toast.LENGTH_SHORT).show();
//                                    Intent inte = new Intent(getApplicationContext(), ShowCancellationResult.class);
//                                    inte.putExtra("CustId", messagecustid);
//                                    inte.putExtra("msg", MesgToShw);
//                                    inte.putExtra("MobileNo", useerLogin);
//                                    inte.putExtra("MailId", EmailAd);
//                                    inte.putExtra("Contactno", MobNo);
//                                    startActivity(inte);
//
//                                }
//
//
////
////                                    else
////                                    if (SubmitRes.equals("You cannot do the Cancellation for the Same date"))
////                                    {
////                                        Toast.makeText(CancelBooking.this, "You cannot do the Cancellation for the Same date", Toast.LENGTH_SHORT).show();
////                                    }
//
//
//                                //End by Himani
//
//
//                                else if (SubmitRes.toString().contains("Cancellation") || SubmitRes.toString().contains("Amount") || SubmitRes.toString().contains("date") || SubmitRes.toString().contains("booking")) {
//                                    Toast.makeText(CancelBooking.this,
//                                            SubmitRes, Toast.LENGTH_LONG)
//                                            .show();
//                                    Log.e(SubmitRes, "Cancellation cannot done");
////                                    Log.e("Cancellation cannot done", SubmitRes);
//
//
//                                } else {
////                                        Toast.makeText(CancelBooking.this,
////                                                "Cancellation Not Done.Try Later!!", Toast.LENGTH_LONG)
////                                                .show();
//                                }
//                            }
//                        });
//
//                    } catch (HttpResponseException e1) {
//                        e1.printStackTrace();
//                    } catch (XmlPullParserException e1) {
//                        e1.printStackTrace();
//                    } catch (IOException e1) {
//                        e1.printStackTrace();
//                    }
//
//
//                }
////                catch (Exception e) {
////
////                        e.printStackTrace();
////
////
////                    }
////Toast.makeText(CancelBooking.this, "CAncellatiion not done!!", Toast.LENGTH_SHORT).show();
//
//  //          }
//            }
//
//                    .
//
//                            start();
        }
    }

    ////////////Start Async task
    private class SoapCancelbookingSubmit_Button extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {

                ip = getLocalIpAddress();
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
                request.addProperty("TotalRooms", RomsBooked);
                request.addProperty("RoomsToCnl", GetRoomsCancelled);
                request.addProperty("CncalDatrfrom", GetCheckIn);
                request.addProperty("cncldateTo", GetCheckOut);
                request.addProperty("Bookingfrom", BookingFrm);
                request.addProperty("BookingTo", BookingTo);
                request.addProperty("custid", messagecustid);
                request.addProperty("Custsrno", SrialNo);
                request.addProperty("Custname", CustomerName);
                request.addProperty("Custadd", messagecustid);
                request.addProperty("Email", EmailAd);
                request.addProperty("Phone", MobNo);
                request.addProperty("RefundAmt", refundAmt);
                request.addProperty("Entrydate", EntryDt);
                request.addProperty("UserLogin", useerLogin);
                request.addProperty("Paymode", Paymode);
                request.addProperty("Paymodeno", Paymodeno);
                request.addProperty("PayRecdBy", PayRcdBy);
                request.addProperty("Noofrows", NoRows);
                request.addProperty("IPaddress", ip);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                    androidHttpTransport.call(SOAP_ACTION2, envelope);
                    SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                    webResponse = response.toString();
                }
                catch(Exception e)
                {
                    Toast.makeText(CancelBooking.this, "Please try again !!", Toast.LENGTH_SHORT).show();
                }


            }
            catch (Exception e)
            {
                Toast.makeText(CancelBooking.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(CancelBooking.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
           pDialog.dismiss();
//            for (int i = 0; i < result.length(); i++) {
            if (result != null) {
                SubmitRes = result.toString();
                Log.e(SubmitRes,"result==");

                    if (SubmitRes.toString().contains("Recalculate Amount")) {
                        Toast.makeText(CancelBooking.this, SubmitRes, Toast.LENGTH_SHORT).show();

                    } else if (SubmitRes.toString().contains("You cannot do the Cancellation for the" + "&  and previous date")) {
                        Toast.makeText(CancelBooking.this, SubmitRes, Toast.LENGTH_SHORT).show();
                    } else if (SubmitRes.toString().contains("You have already checked in. Cannot cancelled for same date.")) {
                        Toast.makeText(CancelBooking.this, SubmitRes, Toast.LENGTH_LONG).show();
                    } else if (!SubmitRes.toString().contains("/")) {
//                                         if (SubmitRes.toString().contains("1")) {
                        Toast.makeText(CancelBooking.this, MesgToShw, Toast.LENGTH_SHORT).show();
                        Intent inte = new Intent(getApplicationContext(), ShowCancellationResult.class);
                        inte.putExtra("CustId", messagecustid);
                        inte.putExtra("msg", MesgToShw);
                        inte.putExtra("MobileNo", useerLogin);
                        inte.putExtra("MailId", EmailAd);
                        inte.putExtra("Contactno", MobNo);
                        startActivity(inte);

                    }

                    //End by Himani

                    else if (SubmitRes.toString().contains("Cancellation") || SubmitRes.toString().contains("Amount") || SubmitRes.toString().contains("date") || SubmitRes.toString().contains("booking")) {
                        Toast.makeText(CancelBooking.this,
                                SubmitRes, Toast.LENGTH_LONG)
                                .show();


                    } else {
//                                        Toast.makeText(CancelBooking.this,
//                                                "Cancellation Not Done.Try Later!!", Toast.LENGTH_LONG)
//                                                .show();
                    }

        }}
    }


    ///////End Async task////////

    //////////Already cancelled Method 3
    private class AlreadyCancelledTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME3);
                request.addProperty("custid", messagecustid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION3, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(CancelBooking.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(CancelBooking.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
           pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                SubmitRes = result.toString();
                Log.e("Already Cancel Result",SubmitRes);
                        if (SubmitRes.equals("0")) {

                        } else if(SubmitRes.equals("1")) {
                            Toast.makeText(CancelBooking.this,
                                    "Already Cancelled", Toast.LENGTH_LONG)
                                    .show();
                            Intent inte = new Intent(getApplicationContext(),cancellationActivity.class);
                            inte.putExtra("MobileNo", useerLogin);
                            inte.putExtra("MailId", EmailAd);
                            inte.putExtra("Contactno", MobNo);
                            startActivity(inte);
                        }
                        else if(SubmitRes.equals("4")) {
                            Toast.makeText(CancelBooking.this,
                                    "Some Error Occured", Toast.LENGTH_LONG)
                                    .show();
                        }


                        else

                        {
                            Toast.makeText(CancelBooking.this,
                                    SubmitRes, Toast.LENGTH_LONG)
                                    .show();

                        }

            }}
    }


    public void onStart() {
        super.onStart();

        // Call web service
        //=================== ====================
        new Thread() {
            @Override
            public void run() {


                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME3);
                request.addProperty("custid", messagecustid);

                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;

                try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                    //this is the actual part that will call the webservice
                    androidHttpTransport.call(SOAP_ACTION3, envelope);
                    // Get the SoapResult from the envelope body.
                    SoapObject result = (SoapObject) envelope.bodyIn;
                    Log.e(String.valueOf(result),"result of already cancel")
                    ;
                    if (result != null) {
                        //Get the first property and change the label text

                        SubmitRes = result.getProperty(0).toString();
                        Log.e("Already Cancel Result",SubmitRes);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                if (SubmitRes.equals("0")) {

                                } else if(SubmitRes.equals("1")) {
                                    Toast.makeText(CancelBooking.this,
                                            "Already Cancelled", Toast.LENGTH_LONG)
                                            .show();
                                    Intent inte = new Intent(getApplicationContext(),cancellationActivity.class);
                                    inte.putExtra("MobileNo", useerLogin);
                                    inte.putExtra("MailId", EmailAd);
                                    inte.putExtra("Contactno", MobNo);
                                    startActivity(inte);
                                }
                                else if(SubmitRes.equals("4")) {
                                    Toast.makeText(CancelBooking.this,
                                            "Some Error Occured", Toast.LENGTH_LONG)
                                            .show();
                                }


                                else

                                {
                                    Toast.makeText(CancelBooking.this,
                                            SubmitRes, Toast.LENGTH_LONG)
                                            .show();

                                }

                            }
                        });

                    } else {

                        //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {

                    Toast.makeText(CancelBooking.this, "Please try again !!", Toast.LENGTH_SHORT).show();

                }
            }
        }.start();
    }

    private void findViewsById() {
        CnclFrom = (EditText) findViewById(R.id.edt_cancelfrm);
        CnclFrom.setInputType(InputType.TYPE_NULL);
        CnclFrom.requestFocus();

        CanclDateTo = (EditText) findViewById(R.id.edt_cancelTo);
        CanclDateTo.setInputType(InputType.TYPE_NULL);
    }
    private void setDateTimeField() {
        CnclFrom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == CnclFrom) {
                    fromDatePickerDialog.show();
                } else if (v == CanclDateTo) {
                    toDatePickerDialog.show();
                }
            }

        });
        CanclDateTo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == CnclFrom) {
                    fromDatePickerDialog.show();
                } else if (v == CanclDateTo) {
                    toDatePickerDialog.show();
                }
            }

        });

        //////modify on 22/05/17
        Log.e("CancelFrm =", CancelFrm);
        final   Integer GetCncldt=Integer.parseInt(BookingFrm.substring( 0, BookingFrm.indexOf("/"))) ;
        Log.e("GetCncldt =", GetCncldt.toString());
        final   Integer GetCnclMon=Integer.parseInt(BookingFrm.substring(BookingFrm.indexOf("/") + 1, BookingFrm.lastIndexOf("/")));
        Log.e("GetCnclMon =", GetCnclMon.toString());
        final   Integer  GetCnclYr=Integer.parseInt(BookingFrm.substring(BookingFrm.lastIndexOf("/") + 1, BookingFrm.length()));
        Log.e("GetCnclYr =", GetCnclYr.toString());

        Calendar newCalendar = Calendar.getInstance();
        newCalendar.set(GetCnclYr, GetCnclMon - 1, GetCncldt);
        fromDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(Calendar.YEAR, year);
                newDate.set(Calendar.MONTH, monthOfYear);
                newDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                CnclFrom.setText(dateFormatter.format(newDate.getTime()));

            }
            ///////end modify

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        String myFormat = "dd-MMM-yyyy";; //In which you need put here

        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        CnclFrom.setText(sdf.format(newCalendar.getTime()));
////////////disable previuos cancel date////////
        Date newDate2 = newCalendar.getTime();
        fromDatePickerDialog.getDatePicker().setMinDate(newDate2.getTime());
////////////end////////////////////////

        Log.e("BookingTo =", BookingTo);
        final   Integer GetCncldtTo=Integer.parseInt(BookingTo.substring( 0, BookingTo.indexOf("/"))) ;
        Log.e("GetCncldtto =", GetCncldtTo.toString());
        final   Integer GetCnclMonTo=Integer.parseInt(BookingTo.substring(BookingTo.indexOf("/") + 1, BookingTo.lastIndexOf("/")));
        Log.e("GetCnclMonto =", GetCnclMonTo.toString());
        final   Integer  GetCnclYrTo=Integer.parseInt(BookingTo.substring(BookingTo.lastIndexOf("/") + 1, BookingTo.length()));
        Log.e("GetCnclYrto =", GetCnclYrTo.toString());

        // Calendar newCalendar = Calendar.getInstance();
        newCalendar.set(GetCnclYrTo, GetCnclMonTo - 1, GetCncldtTo);

        toDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                CanclDateTo.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        String myFormatTo = "dd-MMM-yyyy";; //In which you need put here
//        String myFormatTo = "M-d-yyyy";; //In which you need put here
        SimpleDateFormat sdfTo = new SimpleDateFormat(myFormatTo, Locale.US);
        CanclDateTo.setText(sdfTo.format(newCalendar.getTime()));

        ////////////disable upcoming cancel date////////
        newDate2 = newCalendar.getTime();
        fromDatePickerDialog.getDatePicker().setMaxDate(newDate2.getTime());
////////////end////////////////////////
        ////////////disable upcoming cancel date////////
        newDate2 = newCalendar.getTime();
        toDatePickerDialog.getDatePicker().setMaxDate(newDate2.getTime());
////////////end////////////////////////


    }

    public void onClick(View view) {
        if (view == CnclFrom) {
            fromDatePickerDialog.show();
        } else if (view == CanclDateTo) {
            toDatePickerDialog.show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cancel_booking, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        String ip = Formatter.formatIpAddress(inetAddress.hashCode());
                        Log.e( "***** IP=", ip);
                        return ip;
                    }
                }
            }
        } catch (SocketException ex) {
            Toast.makeText(this, "Please try again !!", Toast.LENGTH_SHORT).show();
        }
        return null;
    }
    public void onBackPressed()
    {
        finish();
        Intent intent = new Intent(CancelBooking.this, cancellationActivity.class);
        intent.putExtra("MobileNo", useerLogin);
        intent.putExtra("MailId", EmailAd);
        intent.putExtra("Contactno", MobNo);
        startActivity(intent);


    }
}
