package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class BaseCodeToImage extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/ImageToBase64";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "ImageToBase64";
    //private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
    // private static String URL = "http://10.89.179.45/htcbooking/WS_Payment.asmx";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb="aaa";
    ImageView imagesh;
    ProgressDialog pDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_code_to_image);
        imagesh = (ImageView)this.findViewById(R.id.Bitimg);
        // Call web service
        //=================== ====================
        getRecieptAsyctask task = new getRecieptAsyctask();
        task.execute();
        //=======================================
        ///////////////Button Exit


    }


    private class getRecieptAsyctask extends AsyncTask<String, Void, String> {
        protected void onPreExecute() {
            pDialog = new ProgressDialog(BaseCodeToImage.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
//
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e)
            {
                Toast.makeText(BaseCodeToImage.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if (!abb.toString().equals("")) {

                            byte[] decodedString = Base64.decode(abb, Base64.DEFAULT);
                            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                            imagesh.setImageBitmap(decodedByte);
                        } else {
                            Toast.makeText(BaseCodeToImage.this,
                                    "Some Error Occured!", Toast.LENGTH_LONG)
                                    .show();
                        }

                    }
                });

            }        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_base_code_to_image, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
