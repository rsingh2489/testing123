package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.Toast;

public class WebViewTermsConditions extends Activity {
    private WebView webViewTermsCnditions;
    String GetUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_web_view_terms_conditions);

        webViewTermsCnditions = (WebView) findViewById(R.id.webview_termsCnditn);
        webViewTermsCnditions.getSettings().setJavaScriptEnabled(true);
        webViewTermsCnditions.setWebViewClient(new InsideWebViewClient());
        GetUrl = (getIntent().getExtras().getString("URL"));
        webViewTermsCnditions.loadUrl(getIntent().getExtras().getString("URL"));

        final ImageButton Btn_Logout=(ImageButton) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), Reservation.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(WebViewTermsConditions.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    private class InsideWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
           // findViewById(R.id.progress1).setVisibility(View.VISIBLE);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_web_view_terms_conditions, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
