package com.example.sohan_pc.htcbooking;

/**
 * Created by Deepak on 2/19/2016.
 */
public class Modal {

    private String CustName, name, Email,dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,
    noOfRows,RoomNos,UserLgin,MobileNo,Entrydate,Paymode,Paymodeno,PayRecdBy,pp,
            Cust_id,PreBookDateFrm,PreBookDateTo,PreDatefrm,PredateTo,DateFrom,DateT,TransactionDate,NoofRoom,UnittypeCategory,ratePerUnit,refundedAmount,AmountPaid,Paymod ;
   // private String Cust_id,DateFrom ,DateT,TransactionDate,NoofRoom,UnittypeCategory,ratePerUnit,refundedAmount,AmountPaid,Paymod;


    public Modal(String title, String name, String year,String dest_name,String pay_amount,String noofunits,String Srno,String Cat,String UnitNo,String Datefrom, String DateTo,String cnlFrm,
                 String SerialNo,String noOfRows,String RoomNos,String UserLgin,String MobileNo,String Entrydate,String Paymode,String Paymodeno,String PayRecdBy,String pp,
         String cust_id,String PreBookDateFrm,String PreBookDateTo,String PreDatefrm,String PredateTo,String datefrom,String datetoo,String Transactiondate,String noOfRoom,String unittye,String rateperUnit,String refundAmount,String Amountpaid,String paymod)
    {

        this.CustName = title;
        this.name = name;
        this.Email = year;
        this.dest_name=dest_name;
        this.pay_amount=pay_amount;
        this.noofunits=noofunits;
        this.Srno=Srno;
        this.Cat=Cat;
        this.UnitNo=UnitNo;
        this.Datefrom=Datefrom;
        this.DateTo=DateTo;
        this.cnlFrm=cnlFrm;
        this.name=name;
        this.SerialNo=SerialNo;
        this.noOfRows=noOfRows;
        this.RoomNos=RoomNos;
        this.UserLgin=UserLgin;
        this.MobileNo=MobileNo;
        this.Entrydate=Entrydate;
        this.Paymode=Paymode;
        this.Paymodeno=Paymodeno;
        this.PayRecdBy=PayRecdBy;
        this.pp=pp;


        ////////already cancelled////////////
        this.Cust_id=cust_id;
        this.PreBookDateFrm=PreBookDateFrm;
        this.PreBookDateTo=PreBookDateTo;
        this.PreDatefrm=PreDatefrm;
        this.PredateTo=PredateTo;
//        this.Bookdate=Bookdate;
//        this.BookTo=Bookto;
        this.DateFrom=datefrom;
        this.DateT=datetoo;
        this.TransactionDate=Transactiondate;
        this.NoofRoom=noOfRoom;
        this.UnittypeCategory=unittye;
        this.ratePerUnit=rateperUnit;
        this.refundedAmount=refundAmount;
        this.AmountPaid=Amountpaid;
        this.Paymod=paymod;
        ////////////end///////////////////
    }


    public String getTitle() {
        return CustName;
    }

    public void setTitle(String name) {
        this.CustName = name;
    }

   /* public String getYear() {
        return CustAdd;
    }

    public void setYear(String year) {
        this.CustAdd = year;
    }*/

    public String getGenre() {
        return Email;
    }

    public void setGenre(String dest_name) {
        this.Email = dest_name;
    }
    public String getDest_name() {
        return dest_name;
    }

    public void setdest_name(String dest_name) {
        this.dest_name = dest_name;
    }
    public String getpay_amount() {
        return pay_amount;
    }

    public void setpay_amount(String pay_amount) {
        this.pay_amount = pay_amount;
    }
    public String getnoofunits() {
        return noofunits;
    }

    public void setnoofunits(String noofunits) {
        this.noofunits = noofunits;
    }

    public  String getSrno(){
        return  Srno;
    }
    public  void setSrno(String Srno){
        this.Srno=Srno;
    }
    public  String getCat(){
        return  Cat;
    }
    public  void setCat(String Cat){
        this.Cat=Cat;
    }
    public  String getUnitNo(){
        return  UnitNo;
    }
    public  void setUnitNo(String UnitNo){
        this.UnitNo=UnitNo;
    }
    public  String getDatefrom(){
        return  Datefrom;
    }
    public  void setDatefrom(String Datefrom){
        this.Datefrom=Datefrom;
    }
    public  String getDateTo(){
        return  DateTo;
    }
    public  void setDateTo(String DateTo){
        this.DateTo=DateTo;
    }
    public  String getcnlFrm(){
        return  cnlFrm;
    }
    public  void setcnlFrm(String cnlFrm){
        this.cnlFrm=cnlFrm;
    }
    public  String getname(){
        return  name;
    }
    public  void setname(String cnlFrm){
        this.name=name;
    }
    public  String getSerialNo(){
        return  SerialNo;
    }
    public  void setSerialNo(String SerialNo){
        this.SerialNo=SerialNo;
    }
    public  String getnoOfRows(){
        return  noOfRows;
    }
    public  void setnoOfRows(String noOfRows){
        this.noOfRows=noOfRows;
    }
    public  String getRoomNos(){
        return  RoomNos;
    }
    public  void setRoomNos(String RoomNos){
        this.RoomNos=RoomNos;
    }
    public  String getUserLgin(){
        return  UserLgin;
    }
    public  void setUserLgin(String UserLgin){
        this.UserLgin=UserLgin;
    }
    public  String getMobileNo(){
        return  MobileNo;
    }
    public  void setMobileNo(String MobileNo){
        this.MobileNo=MobileNo;
    }
    public  String getEntrydate(){
        return  Entrydate;
    }
    public  void setEntrydate(String Entrydate){
        this.Entrydate=Entrydate;
    }
    public  String getPaymode(){
        return  Paymode;
    }
    public  void setPaymode(String Paymode){
        this.Paymode=Paymode;
    }
    public  String getPaymodeno(){
        return  Paymodeno;
    }
    public  void setPaymodeno(String Paymodeno){
        this.Paymodeno=Paymodeno;
    }
    public  String getPayRecdBy(){
        return  PayRecdBy;
    }
    public  void setPayRecdBy(String PayRecdBy){
        this.PayRecdBy=PayRecdBy;
    }
    public  String getpp(){
        return  pp;
    }
    public  void setpp(String pp){
        this.pp=pp;
    }

    //////////////already cancelled////////

    public String getCust_id() {
        return Cust_id;
    }
    public void setCust_id(String custid) {
        this.Cust_id = custid;
    }

    public String getPreBookDateFrm() {
        return PreBookDateFrm;
    }
    public void setPreBookDateFrm(String preBookDateFrm) {
        this.PreBookDateFrm = preBookDateFrm;
    }

    public String getPreBookDateTo() {
        return PreBookDateTo;
    }
    public void setPreBookDateTo(String preBookDateTo) {
        this.PreBookDateTo = preBookDateTo;
    }
    public String getPreDatefrm() {
        return PreDatefrm;
    }
    public void setPreDatefrm(String preDatefrm) {
        this.PreDatefrm = preDatefrm ;
    }
    public String getPredateTo() {
        return PredateTo;
    }
    public void setPredateTo(String predateTo) {
        this.PredateTo = predateTo;
    }


    public String getDateFrom() {
        return DateFrom;
    }
    public void setDateFrom(String datefrom) {
        this.Datefrom = datefrom;
    }

    public String getDateT() {
        return DateT;
    }
    public void setDateT(String dateto) {
        this.DateT = dateto;
    }

    public String getTransactionDate() {
        return TransactionDate;
    }
    public void setTransactionDate(String transactionDate) {
        this.DateT = transactionDate;
    }

    public String getNoofRoom() {
        return NoofRoom;
    }
    public void setNoofRoom(String noofRoom) {
        this.NoofRoom = noofRoom;
    }

    public String getUnittypeCategory() {
        return UnittypeCategory;
    }
    public void setUnittypeCategory(String unittypeCategory) {
        this.UnittypeCategory = unittypeCategory;
    }

    public String getRatePerUnit() {
        return ratePerUnit;
    }
    public void setRatePerUnit(String ratePerUnit) {
        this.ratePerUnit = ratePerUnit;
    }

    public String getRefundedAmount() {
        return refundedAmount;
    }
    public void setRefundedAmount(String refundedAmount) {
        this.refundedAmount = refundedAmount;
    }

    public String getAmountPaid() {
        return AmountPaid;
    }
    public void setAmountPaid(String amountPaid) {
        this.AmountPaid = amountPaid;
    }

    public String getPaymod() {
        return Paymod;
    }
    public void setPaymod(String paymod) {
        this.Paymod = paymod;
    }


    /////////////////////////


}
