package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.HashMap;

public class EditProfile extends Activity {

    private static String SOAP_ACTION1 = "http://tempuri.org/UpdateProfile";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "UpdateProfile";
       //  private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    private  Boolean IsUserLogIn=true;
    String EmailID,IsMob,PhoneNo;
   String EmailIDUpd,IsMobUpd;
    ProgressDialog pDialog;
    ProgressBar progressBar;
    String getChkMobUpd,chkEmailupd;
    // Session Manager Class
    SessionManagement session;

    EditText emailupdate,passupdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_edit_profile);

        // Session class instance
        session = new SessionManagement(getApplicationContext());

//         EditText Txtmail = (EditText) findViewById(R.id.edt_EmailIdUpd);
        emailupdate=(EditText)findViewById(R.id.edt_EmailIdUpd) ;
        passupdate = (EditText) findViewById(R.id.edt_MobnoUpd);
        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            if (messageMail.contains("/")) {
                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
                emailupdate.setText(EmailID);
                passupdate.setText(IsMob);
            }
            else
                emailupdate.setText(messageMail);
            EmailID=messageMail;
        }

        final EditText LoginEditText = (EditText) findViewById(R.id.edt_loginid);

        if (getIntent().hasExtra("MobileNo")) {
            String messageMbno = getIntent().getStringExtra("MobileNo").toString();
            LoginEditText.setText(messageMbno);
            PhoneNo=messageMbno;
        }
        if (getIntent().hasExtra("Contactno")) {

            String messageConctno = getIntent().getStringExtra("Contactno").toString();
            if (messageConctno.equals("1")){

            }
            else
            {
                IsMob=messageConctno;
                passupdate.setText(IsMob);
            }
            // LoginEditText.setText(messageMbno);
        }

     //   Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        String name = user.get(SessionManagement.KEY_NAME);
        // email
        String email = user.get(SessionManagement.KEY_EMAIL);
        // mobile
        String mobile = user.get(SessionManagement.KEY_MOBILE);
        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    session.logoutUser();
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(EditProfile.this, "Try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
//        final EditText Txtmailupd = (EditText) findViewById(R.id.edt_EmailIdUpd);
//        final EditText PhoneEditTexupdt = (EditText) findViewById(R.id.edt_MobnoUpd);
        EmailIDUpd=emailupdate.getText().toString();
        IsMobUpd=passupdate.getText().toString();
        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
                    inte.putExtra("MobileNo", PhoneNo);
                    inte.putExtra("MailId", EmailIDUpd);
                    inte.putExtra("Contactno", IsMobUpd);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(EditProfile.this, "Try again", Toast.LENGTH_SHORT).show();

                }
            }
        });

        Button button = (Button) findViewById(R.id.Btn_Submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ///Validation////////////////////
//                final EditText chkEmail = (EditText) findViewById(R.id.edt_EmailIdUpd);
                chkEmailupd = emailupdate.getText().toString();
                if (chkEmailupd.equals("") || chkEmailupd.equals("0")) {
                    //  ChkInDAte.setError("Enter Valid CheckInDate");
                    emailupdate.requestFocus();
                    Toast.makeText(EditProfile.this, "Enter Email Id.", Toast.LENGTH_LONG).show();
                    return;

                }
                final String GetEmailNew = emailupdate.getText().toString();
                String Expn =
                        "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                                +"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                                +"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                                +"([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

                if (GetEmailNew.matches(Expn) && GetEmailNew.length() > 0)
                {
                   emailupdate.setText(GetEmailNew);
                }
                else
                {
                    emailupdate.setError("invalid email");
                    return;
                }
//                final EditText ChkMob = (EditText) findViewById(R.id.edt_MobnoUpd);
                getChkMobUpd = passupdate.getText().toString();
                if (getChkMobUpd.equals("") || getChkMobUpd.equals("0")) {
                    // ChkOutDate.setError("Enter Valid CheckOutDate");
                    Toast.makeText(EditProfile.this, "Enter Valid Mobile No", Toast.LENGTH_LONG).show();
                    passupdate.requestFocus();
                    return;
                }
                // Call web service
                //=================== ====================
                SoapAccessTask task = new SoapAccessTask();
                task.execute();                //=======================================
                ///////////////Button Exit
            }
        });
    }

    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("MobNo", getChkMobUpd);
                request.addProperty("Email", chkEmailupd);
                request.addProperty("UserId", PhoneNo);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(EditProfile.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(EditProfile.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();
                if (abb.equals("1")) {

                    session.createLoginSession(PhoneNo, chkEmailupd, getChkMobUpd);
                    IsUserLogIn = true;
                    util.writeString(EditProfile.this, "MobileNo", PhoneNo);
                    util.writeString(EditProfile.this, "MailId", chkEmailupd);
                    util.writeString(EditProfile.this, "Contactno", getChkMobUpd);
                    Toast.makeText(EditProfile.this,
                            "Updated Successfully..!!", Toast.LENGTH_SHORT)
                            .show();
                    Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);

                    inte.putExtra("MobileNo", PhoneNo);
                    inte.putExtra("MailId", chkEmailupd);
                    inte.putExtra("Contactno", getChkMobUpd);
                    inte.putExtra("IsUserLogIn", IsUserLogIn);
                    startActivity(inte);
                } else {
                    Toast.makeText(EditProfile.this,
                            "Updation Unsuccessfull!!", Toast.LENGTH_LONG)
                            .show();
                }
            }
        }}


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit_profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
        inte.putExtra("MobileNo", PhoneNo);
        inte.putExtra("MailId", EmailIDUpd);
        inte.putExtra("Contactno", IsMobUpd);
        startActivity(inte);
    }
}
