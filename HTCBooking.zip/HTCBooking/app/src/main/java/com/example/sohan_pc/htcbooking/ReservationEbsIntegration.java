//package com.example.sohan_pc.htcbooking;
//
//import android.app.Activity;
//import android.app.AlertDialog;
//import android.app.DatePickerDialog;
//import android.app.Dialog;
//import android.app.ProgressDialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.graphics.Bitmap;
//import android.net.ConnectivityManager;
//import android.net.NetworkInfo;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.text.InputType;
//import android.util.Log;
//import android.view.ContextThemeWrapper;
//import android.view.MenuItem;
//import android.view.View;
//import android.view.Window;
//import android.webkit.WebView;
//import android.webkit.WebViewClient;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.CheckBox;
//import android.widget.DatePicker;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.RadioButton;
//import android.widget.RadioGroup;
//import android.widget.Spinner;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//import org.ksoap2.SoapEnvelope;
//import org.ksoap2.serialization.SoapObject;
//import org.ksoap2.serialization.SoapPrimitive;
//import org.ksoap2.serialization.SoapSerializationEnvelope;
//import org.ksoap2.transport.HttpTransportSE;
//
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Locale;
//import com.ebs.android.sdk.PaymentRequest;
//import com.ebs.android.sdk.EBSPayment;
//import com.ebs.android.sdk.Config.Encryption;
//import com.ebs.android.sdk.Config.Mode;
//
//public class ReservationEbsIntegration extends Activity implements View.OnClickListener {
//    private static String SOAP_ACTION6 = "http://tempuri.org/GetDisttName";
//    private static String SOAP_ACTION1 = "http://tempuri.org/GetResortName";
//    private static String SOAP_ACTION2 = "http://tempuri.org/GetUnitType";
//    private static String SOAP_ACTION3 = "http://tempuri.org/GetNoOfRooms";
//    private static String SOAP_ACTION4 = "http://tempuri.org/Submit_Payment";
//    private static String SOAP_ACTION5 = "http://tempuri.org/amtcal";
//    private static String SOAP_ACTION7 = "http://tempuri.org/CheckAvailability";
//
//    private static String NAMESPACE = "http://tempuri.org/";
//    private  static  String METHOD_NAME6="GetDisttName";
//    private static String METHOD_NAME1 = "GetResortName";
//    private static String METHOD_NAME2 = "GetUnitType";
//    private  static  String METHOD_NAME3="GetNoOfRooms";
//    private  static  String METHOD_NAME4="Submit_Payment";
//    private  static  String METHOD_NAME5="amtcal";
//    private  static  String METHOD_NAME7="CheckAvailability";
//
//    //UI Referebnce
//    private EditText fromDateEtxt;
//    private EditText toDateEtxt;
//    ImageView imgFirst,resortSpin,spinRoomCategory,roomNo,idSpinner,imgNationality;
//    private DatePickerDialog fromDatePickerDialog;
//    private DatePickerDialog toDatePickerDialog;
//
//    private SimpleDateFormat dateFormatter;
//    private   Boolean getUserStatus;
//    // Session Manager Class
//    SessionManagement session;
//    Spinner sp1, sp2, sp3, sp4, sp5, sp6;
//    //   private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
//    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
//    private static String abb = "aaa";
//    private static String SubmitRes = "pp";
//    private String[] arraySpinner;
//    private String[] arraySpinnerNationality;
//    String EmailID,IsMob,PhoneNo;
//    TextView textRsrtValue,textTariffValue,textFirstDtValue,textSecDtValue,textThrdDtValue,textForthDtValue,textFiveDtValue;
//    WebView web;
//
//    ProgressDialog ProgressD;
//    EditText ChkInDate;
////    private ProgressBar spinner;
//
//    /////////////////////////////initialize EBS Gateway
//    private static String HOST_NAME = "EBS";
//    ArrayList<HashMap<String, String>> custom_post_parameters;
//    private static final int ACC_ID = 24605;// Provided by EBS
//    private static final String SECRET_KEY = "18fda9de78e58c59c605471fb8a6bac4";// Provided by EBS
//
//    //////////////////////////////End GAteway
//
//    String GetServiceTax,GetLuxuryTax,GetTotalAmt,GetTotAmtFinal;
//    String CustLoginId,CusEId,CusName,NoOfRooms,CusPhNO,RName,CtName,GetCheckInDate,getChkOutDate,CusIdentityProf,CusNationality,CustTax;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        // getSupportActionBar().hide();
//        setContentView(R.layout.activity_reservation_ebs_integration);
//
//        HOST_NAME = getResources().getString(R.string.hostname);
//        // Session class instance
//        session = new SessionManagement(getApplicationContext());
//        // Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
////        session.checkLogin();
//
//        // get user data from session
//        HashMap<String, String> user = session.getUserDetails();
//
//        // name
//        String name = user.get(SessionManagement.KEY_NAME);
//        Log.e("name =", name);
//
//        // email
//        String email = user.get(SessionManagement.KEY_EMAIL);
//        Log.e("email =", email);
//        // mobile
//        String mobile = user.get(SessionManagement.KEY_MOBILE);
//        Log.e("mobile =",mobile);
//
//        final EditText Txtmail = (EditText) findViewById(R.id.edt_EmailId);
//        final EditText PhoneEditText = (EditText) findViewById(R.id.edt_PhoneNum);
//        imgFirst = (ImageView) findViewById(R.id.imgFirst);
//        imgFirst.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                sp6.showContextMenu();
//                sp6.performClick();
//            }
//        });
//        resortSpin= (ImageView)findViewById(R.id.resortspin_img);
//        resortSpin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sp1.showContextMenu();
//                sp1.performClick();
//            }
//        });
//        spinRoomCategory=(ImageView)findViewById(R.id.roomCat_Spinimg);
//        spinRoomCategory.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sp2.showContextMenu();
//                sp2.performClick();
//            }
//        });
//        roomNo=(ImageView)findViewById(R.id.room_no_spin);
//        roomNo.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sp3.showContextMenu();
//                sp3.performClick();
//            }
//        });
//        idSpinner=(ImageView)findViewById(R.id.idProof_Spinner);
//        idSpinner.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sp4.showContextMenu();
//                sp4.performClick();
//            }
//        });
//        imgNationality=(ImageView)findViewById(R.id.nationality_Spinner);
//        imgNationality.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sp5.showContextMenu();
//                sp5.performClick();
//            }
//        });
//
//
////        Resortspin_img=(ImageView)findViewsById();
//
//        if (getIntent().hasExtra("MailId")) {
//            String messageMail = getIntent().getStringExtra("MailId").toString();
//            if (messageMail.contains("/")) {
//                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
//                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
//                Txtmail.setText(EmailID);
//                PhoneEditText.setText(IsMob);
//            }
//            else
//                Txtmail.setText(messageMail);
//            EmailID=messageMail;
//        }
//
//        final EditText LoginEditText = (EditText) findViewById(R.id.edt_loginid);
//
//        if (getIntent().hasExtra("MobileNo")) {
//            String messageMbno = getIntent().getStringExtra("MobileNo").toString();
//            LoginEditText.setText(messageMbno);
//            PhoneNo=messageMbno;
//        }
//        if (getIntent().hasExtra("Contactno")) {
//
//            String messageConctno = getIntent().getStringExtra("Contactno").toString();
//            if (messageConctno.equals("1")){
//
//            }
//            else
//            {
//                IsMob=messageConctno;
//                PhoneEditText.setText(IsMob);
//            }
//            // LoginEditText.setText(messageMbno);
//        }
//
//        if (getIntent().hasExtra("IsUserLogIn")){
//            getUserStatus=getIntent().getExtras().getBoolean("IsUserLogIn");
//            if (getUserStatus=false){
//
//                Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
//                startActivity(inte);
//            }
//        }
//
//        EditText testEditText = (EditText) findViewById(R.id.edt_CustName);
//
//        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);
//
//        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
//            public void onClick(View v)  {
//                try {
//                    session.logoutUser();
//                    getUserStatus=false;
//                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
//                    startActivity(inte);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);
//
//        Btn_Home.setOnClickListener(new View.OnClickListener()   {
//            public void onClick(View v)  {
//                try {
//                    Intent inte = new Intent(getApplicationContext(),NavigationScreen .class);
//                    inte.putExtra("MobileNo", PhoneNo);
//                    inte.putExtra("MailId", EmailID);
//                    inte.putExtra("Contactno", IsMob);
//                    startActivity(inte);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        dateFormatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.US);
//
//        findViewsById();
//
//        setDateTimeField();
//
//        //Id Proofs dropdown
//        this.arraySpinner = new String[]{
//                "Voter Id", "Aadhar Card", "Pan Card", "Passport", "Driving License"
//        };
//        Spinner sIdentity = (Spinner) findViewById(R.id.spin_IdProofs);
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_spinner_item, arraySpinner);
//        sIdentity.setAdapter(adapter);
//        //end
//        //Date Selection
//        EditText txtEdit = (EditText) findViewById(R.id.edt_CustName);
//
//
//        //Nationality dropdown
//        this.arraySpinnerNationality = new String[]{
//                "Indian", "Foreign"
//        };
//        Spinner sNaionality = (Spinner) findViewById(R.id.spin_Nationality);
//        ArrayAdapter<String> adapterN = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arraySpinnerNationality);
//        sNaionality.setAdapter(adapterN);
//        TextView TermsLink= (TextView) findViewById(R.id.TextViewHp);
//        TermsLink.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
////                AlertDialog.Builder alert = new AlertDialog.Builder(new ContextThemeWrapper(ReservationEbsIntegration.this,R.style.Base_Theme_AppCompat_DialogWhenLarge));
//                AlertDialog.Builder alert = new AlertDialog.Builder(new ContextThemeWrapper(ReservationEbsIntegration.this,R.style.AppTheme));
//                alert.setTitle("Terms And Conditions");
//                WebView wv = new WebView(getApplicationContext());
//                wv.getSettings().setBuiltInZoomControls(true);
//                wv.setVerticalScrollBarEnabled(false);
//                wv.loadUrl("http://web1.hry.nic.in/HTCAndroidWS/frminformation.htm");
//                wv.setHorizontalScrollBarEnabled(false);
//                //  wv.loadDataWithBaseURL("http://web1.hry.nic.in/HTCAndroidWS/frminformation.htm", "http://web1.hry.nic.in/HTCAndroidWS/frminformation.htm","text/html", "utf-8", null);
//                //  wv.loadDataWithBaseURL(null, "HTML content here", "text/html", "utf-8", null);
//                alert.setView(wv);
//                alert.setNegativeButton("Close", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int id) {
//                        dialog.dismiss();
//                    }
//                });
//                alert.show();
//            }
//
//        });
//
//
//        //
//        int count;
//        sp1 = (Spinner) findViewById(R.id.spin_Resort);
//        sp2 = (Spinner) findViewById(R.id.spin_RoomCat);
//        sp3 = (Spinner) findViewById(R.id.spin_NoOfRooms);
//        sp4 = (Spinner) findViewById(R.id.spin_IdProofs);
//        sp5 = (Spinner) findViewById(R.id.spin_Nationality);
//        sp6 = (Spinner) findViewById(R.id.spin_Distt);
//
//
//        sp6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent,
//                                       View view, int pos, long id) {
//
//                EditText ChekOuate = (EditText) findViewById(R.id.edt_chkOutDate);
//                // ChekOuate.setText("aaaa");
//                //   cardStatusString = parent.getItemAtPosition(pos).toString();
//                final String Restid = parent.getItemAtPosition(pos).toString();
//
//                ////  ChekOuate.setText(String.valueOf(obj1.getValue()));
////                ProgressD = new ProgressDialog(Reservation.this);
////                ProgressD.setTitle("Please Wait....");
////                ProgressD.setCancelable(true);
////                ProgressD.setCanceledOnTouchOutside(false);
////                ProgressD.show();
//
//
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                        request.addProperty("DDistrict", Restid);
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION1, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
////                                if(ProgressD != null){
////                                    ProgressD.dismiss();
////                                }
//
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        // ArrayList tExp = new ArrayList();
//                                        ArrayList<spinerobj> Resorts = new ArrayList<spinerobj>();
//                                        //
//                                        try {
//                                            JSONObject jsonResponse = new JSONObject(abb);
//                                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");
//
//                                            final String[] items = new String[jsonArray.length()];
//                                            if (jsonArray != null) {
//                                                for (int i = 0; i < jsonArray.length(); i++) {
//                                                    JSONObject youValue = jsonArray.getJSONObject(i);
//                                                    String idModule = youValue.getString("dest_name");
//                                                    String id = youValue.getString("dest_code");
//                                                    Resorts.add(new spinerobj(id, idModule));
//                                                    // Use the same for remaining values
//                                                }
//                                            }
//                                            Spinner sp = (Spinner) findViewById(R.id.spin_Resort);
//
//                                            //  sp.setAdapter(new ArrayAdapter<String>(Reservation.this, R.layout.support_simple_spinner_dropdown_item, Resorts));
//
//                                            ArrayAdapter<spinerobj> dataAdapter = new ArrayAdapter<spinerobj>(ReservationEbsIntegration.this,
//                                                    android.R.layout.simple_spinner_item, Resorts);
//                                            // Drop down layout style - list view with radio button
//                                            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                                            sp.setAdapter(dataAdapter);
//
//                                        } catch (JSONException e) {
//                                            e.printStackTrace();
//                                        }
//
////
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//
//                    }
//                }.start();
//
//                //End Web service resort name
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> arg0) {
//                // TODO Auto-generated method stub
//
//            }
//
//        });
//        //End Distt Selection
//        //Resort Seletion
//        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent,
//                                       View view, int pos, long id) {
//                EditText ChekOuate = (EditText) findViewById(R.id.edt_chkOutDate);
//                // ChekOuate.setText("aaaa");
//                //   cardStatusString = parent.getItemAtPosition(pos).toString();
//                final String Restid = parent.getItemAtPosition(pos).toString();
//                //  int databaseioId = Integer.parseInt(((spinerobj) sp1.getSelectedItem()).getId());
//                //   String databaseioId=  getResources().getStringArray(R.array.values)[sp1.getSelectedItemPosition()];
//                //   ChekOuate.setText(databaseioId);
//                //spinerobj obj1 = (spinerobj)(parent.getItemAtPosition(pos));
//                ////  ChekOuate.setText(String.valueOf(obj1.getValue()));
////                ProgressD = new ProgressDialog(Reservation.this);
////                ProgressD.setTitle("Please Wait....");
////                ProgressD.setCancelable(true);
////                ProgressD.setCanceledOnTouchOutside(false);
////                ProgressD.show();
//
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
//                        request.addProperty("Ddl_Resort", Restid);
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION2, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
////                                if(ProgressD != null){
////                                    ProgressD.dismiss();
////                                }
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        // ArrayList tExp = new ArrayList();
//                                        ArrayList<String> Resorts = new ArrayList<String>();
//                                        //
//                                        try {
//                                            JSONObject jsonResponse = new JSONObject(abb);
//                                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");
//
//                                            final String[] items = new String[jsonArray.length()];
//                                            if (jsonArray != null) {
//                                                for (int i = 0; i < jsonArray.length(); i++) {
//                                                    JSONObject youValue = jsonArray.getJSONObject(i);
//                                                    String idModule = youValue.getString("unittype1");
//                                                    String id = youValue.getString("unit_type");
//                                                    Resorts.add(idModule);
//                                                    // Use the same for remaining values
//                                                }
//                                            }
//                                            Spinner sp = (Spinner) findViewById(R.id.spin_RoomCat);
//                                            sp.setAdapter(new ArrayAdapter<String>(ReservationEbsIntegration.this, R.layout.support_simple_spinner_dropdown_item, Resorts));
//                                        } catch (JSONException e) {
//                                            e.printStackTrace();
//                                        }
////
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//
//                //End Web service resort name
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> arg0) {
//                // TODO Auto-generated method stub
//
//            }
//        });
//        //On Roomm Selection
//        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent,
//                                       View view, int pos, long id) {
//                final String RsortName = sp1.getSelectedItem().toString();
//                final String CatgriName = parent.getItemAtPosition(pos).toString();
//                final String CatyName = CatgriName.substring(CatgriName.indexOf(",") + 1, CatgriName.indexOf("("));
//
////                ProgressD = new ProgressDialog(Reservation.this);
////                ProgressD.setTitle("Please Wait....");
////                ProgressD.setCancelable(true);
////                ProgressD.setCanceledOnTouchOutside(false);
////                ProgressD.show();
//                // Call web service
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME3);
//                        request.addProperty("Ddl_Resort", RsortName);
//                        request.addProperty("UnitName", CatyName);
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION3, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//                                if(ProgressD != null){
//                                    ProgressD.dismiss();
//                                }
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        ArrayList<String> UnitsNo = new ArrayList<String>();
//                                        try {
//                                            JSONObject jsonResponse = new JSONObject(abb);
//                                            JSONArray jsonArray = jsonResponse.optJSONArray("Table");
//
//                                            final String[] items = new String[jsonArray.length()];
//                                            if (jsonArray != null) {
//                                                for (int i = 0; i < jsonArray.length(); i++) {
//                                                    JSONObject youValue = jsonArray.getJSONObject(i);
//                                                    String idModule = youValue.getString("unit_no");
//                                                    int NoRooms = Integer.parseInt(youValue.getString("unit_no"));
//                                                    // String id = youValue.getString("unit_type");
//                                                    for (int j = 1; j <= NoRooms; j++) {
//                                                        UnitsNo.add(String.valueOf(j));
//                                                    }
//                                                    // UnitsNo.add(idModule);
//                                                    // Use the same for remaining values
//                                                }
//                                            }
//                                            Spinner sp = (Spinner) findViewById(R.id.spin_NoOfRooms);
//                                            sp.setAdapter(new ArrayAdapter<String>(ReservationEbsIntegration.this, R.layout.support_simple_spinner_dropdown_item, UnitsNo));
//                                        } catch (JSONException e) {
//                                            e.printStackTrace();
//                                        }
//
//                                                                     /* int NoOfRooms = Integer.parseInt(abb.toString());
//                                                                      if (abb.equals("4")) {
//                                                                          for (int j = 1; j <= NoOfRooms; j++) {
//                                                                              Resorts.add(String.valueOf(j));
//                                                                          }
//                                                                          Spinner sp = (Spinner) findViewById(R.id.spin_RoomCat);
//                                                                          sp.setAdapter(new ArrayAdapter<String>(Reservation.this, R.layout.support_simple_spinner_dropdown_item, Resorts));
//
//                                                                      } else if (abb.equals("2")) {
//                                                                          Toast.makeText(Reservation.this,
//                                                                                  "Incorrect Password!!", Toast.LENGTH_LONG)
//                                                                                  .show();
//                                                                      }*/
//
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> arg0) {
//                // TODO Auto-generated method stub
//
//            }
//        });
////Bank Selection
//        RadioGroup radGrp = (RadioGroup) findViewById(R.id.radiogrpPayType);
//
//        int checkedRadioButtonID = radGrp.getCheckedRadioButtonId();
//
//        radGrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            public void onCheckedChanged(RadioGroup arg0, int id) {
//                RadioButton rbu2 = (RadioButton) findViewById(R.id.radioButtonHdfc);
//                RadioButton rbu3 = (RadioButton) findViewById(R.id.radioButtonAxis);
//                switch (id) {
//                    case -1:
//                        Toast.makeText(ReservationEbsIntegration.this,
//                                "Incorrect Selction!!", Toast.LENGTH_LONG)
//                                .show();
//                        break;
//                    case R.id.Rd_tsest1:
//                        rbu2.setChecked(true);
//                        rbu3.setEnabled(false);
//                        break;
//                    case R.id.test2t:
//                        rbu3.setEnabled(true);
//                        rbu3.setChecked(true);
//                        break;
//                    default:
//
//
//                        break;
//                }
//            }
//        });
//
//        //On button check availability
//
//        Button buttonChkavail = (Button) findViewById(R.id.Btn_ChkAvailbility);
//        buttonChkavail.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                ChkInDate = (EditText) findViewById(R.id.edt_ChkInDate);
//                final String GetCheckIn = ChkInDate.getText().toString();
//
//                // String GetSecond=messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
//                // Create custom dialog object
//                final Dialog dialog = new Dialog(ReservationEbsIntegration.this);
//                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//                // Include dialog.xml file
//                dialog.setContentView(R.layout.activity_show_availability);
//                //    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.green(1)));
//
//                // Set dialog title
//                dialog.setTitle("Haryana Tourism Room Available");
//                //   dialog.getWindow().setTitleColor(8);
////dialog.getWindow().setTitleColor(getResources().getColor(R.color.background_material_dark));
//                // set values for custom dialog components - text, image and button
//                TextView text = (TextView) dialog.findViewById(R.id.CheckdateOne);
//                text.setText(GetCheckIn);
//
//                Integer  GetSelDate= Integer.parseInt( GetCheckIn.substring( 0, GetCheckIn.indexOf("-")));
//                String  GetSelMon=  GetCheckIn.substring(GetCheckIn.indexOf("-") + 1, GetCheckIn.lastIndexOf("-"));
//                Integer  GetSelYear=Integer.parseInt(GetCheckIn.substring(GetCheckIn.lastIndexOf("-") + 1, GetCheckIn.length()));
//                Integer MonthOfSel=  monthStringToInt(GetSelMon);
//
//                Calendar cal = Calendar.getInstance();
//                cal.set(Calendar.DATE, GetSelDate+1);
//                cal.set(Calendar.MONTH, MonthOfSel-1);
//                cal.set(Calendar.YEAR, GetSelYear);
//                Date GetdAtetwo=cal.getTime();
//
//                String myFormat = "dd-MMM-yyyy"; //In which you need put here
//                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
//                //  fromDateEtxt.setText(sdf.format(newCalendar.getTime()));
//
//
//                TextView textSec = (TextView) dialog.findViewById(R.id.CheckdateTwo);
//                textSec.setText(sdf.format(GetdAtetwo.getTime()));
//                cal.add(Calendar.DATE, 1);
//
//                TextView textThree = (TextView) dialog.findViewById(R.id.CheckdateThree);
//                textThree.setText(sdf.format(cal.getTime()));
//                cal.add(Calendar.DATE, 1);
//
//                TextView textFour = (TextView) dialog.findViewById(R.id.Checkdatefour);
//                textFour.setText(sdf.format(cal.getTime()));
//                cal.add(Calendar.DATE, 1);
//
//                TextView textFive = (TextView) dialog.findViewById(R.id.Checkdatefive);
//                textFive.setText(sdf.format(cal.getTime()));
//                cal.add(Calendar.DATE, 1);
//
//                textRsrtValue = (TextView) dialog.findViewById(R.id.GetResortName);
//                textTariffValue = (TextView) dialog.findViewById(R.id.GetTariff);
//                textFirstDtValue = (TextView) dialog.findViewById(R.id.GetdateOne);
//                textSecDtValue = (TextView) dialog.findViewById(R.id.GetdateTwo);
//                textThrdDtValue = (TextView) dialog.findViewById(R.id.GetdateThree);
//                textForthDtValue = (TextView) dialog.findViewById(R.id.Getdatefour);
//                textFiveDtValue = (TextView) dialog.findViewById(R.id.Getdatefive);
//
//                dialog.show();
//
//                //   DialogeShowHide();
//
//                ///Validation////////////////////
//               /* final EditText ChkInDate = (EditText) findViewById(R.id.edt_ChkInDate);
//                final String GetCheckIn = ChkInDate.getText().toString();*/
//                final EditText ChkOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
//                final String GetCheckOut = ChkOutDate.getText().toString();
//                final String RsrtName = sp1.getSelectedItem().toString();
//                final String CatgryName = sp2.getSelectedItem().toString();
//                final String UnitNo = sp3.getSelectedItem().toString();
//                final String CatName = CatgryName.substring(CatgryName.indexOf(",") + 1, CatgryName.indexOf("("));
//                final TextView calAmt = (TextView) findViewById(R.id.edt_TaxAmount);
//
//                final String GetSecserchDt = textSec.getText().toString();
//                final String GetThrdserchDt = textThree.getText().toString();
//                final String GetForthserchDt = textFour.getText().toString();
//                final String GetFiveserchDt = textFive.getText().toString();
//
//                ProgressD = new ProgressDialog(ReservationEbsIntegration.this);
//                ProgressD.setTitle("Please Wait....");
//                ProgressD.setCancelable(true);
//                ProgressD.setCanceledOnTouchOutside(false);
//                ProgressD.show();
//                // SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//                // String Ndate = formatter.format(GetCheckIn);
//                //end validation
//                // Call web service
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME7);
//                        request.addProperty("DestName",RsrtName);
//                        request.addProperty("unitType",CatName);
//                        request.addProperty("DateFrm", GetCheckIn);
//                        request.addProperty("DateTo",GetCheckOut);
//
//
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION7, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//                                if(ProgressD != null){
//                                    ProgressD.dismiss();
//                                }
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//
//                                        ArrayList<String> list = new ArrayList<String>();
//
//                                        try {
//                                            JSONArray jsonArray = new JSONArray(abb);
//
//                                            for (int i = 0; i < jsonArray.length(); i++) {
//                                                JSONObject youValue = jsonArray.getJSONObject(i);
//
//                                                textRsrtValue.setText(youValue.getString("Category"));
//                                                textTariffValue.setText(youValue.getString("Tariff"));
//                                                textFirstDtValue.setText(youValue.getString(GetCheckIn));
//                                                textSecDtValue.setText(youValue.getString(GetSecserchDt));
//                                                textThrdDtValue.setText(youValue.getString(GetThrdserchDt));
//                                                textForthDtValue.setText(youValue.getString(GetForthserchDt));
//                                                textFiveDtValue.setText(youValue.getString(GetFiveserchDt));
//                                                // String idModule = youValue.getString("cust_name");
//                                                //  String name = youValue.getString("cust_id");
//                                                //  list.add(jsonArray.get(i).toString());
//
//                                            }//end for
//                                        } catch (JSONException e) {
//                                            //   Log.e(TAG, "onPostExecute > Try > JSONException => " + e);
//                                            e.printStackTrace();
//                                        }
//
//
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//                //=======================================
//                ///////////////Button Exit
//            }
//        });
//
//
//
//        //calculate amount
//
//
//        //Button Click/////////////////
//        Button buttonCal = (Button) findViewById(R.id.Btn_CalAmt);
//        buttonCal.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//
//                ///Validation////////////////////
//                ChkInDate = (EditText) findViewById(R.id.edt_ChkInDate);
//                final String GetCheckIn = ChkInDate.getText().toString();
//                final EditText ChkOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
//                final String GetCheckOut = ChkOutDate.getText().toString();
//                final String RsrtName = sp1.getSelectedItem().toString();
//                final String CatgryName = sp2.getSelectedItem().toString();
//                final String UnitNo = sp3.getSelectedItem().toString();
//                final String CatName = CatgryName.substring(CatgryName.indexOf(",") + 1, CatgryName.indexOf("("));
//                final TextView calAmt = (TextView) findViewById(R.id.edt_TaxAmount);
//                // SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//                // String Ndate = formatter.format(GetCheckIn);
//                //end validation
//                ProgressD = new ProgressDialog(ReservationEbsIntegration.this);
//                ProgressD.setTitle("Please Wait....");
//                ProgressD.setCancelable(true);
//                ProgressD.setCanceledOnTouchOutside(false);
//                ProgressD.show();
//
//                // Call web service
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME5);
//                        request.addProperty("Checkin", GetCheckIn);
//                        request.addProperty("CheckOut", GetCheckOut);
//                        request.addProperty("NoOfUnits", UnitNo);
//                        request.addProperty("DestCode", RsrtName);
//                        request.addProperty("UnitType", CatName);
//
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION5, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//                                Log.e(abb,"calculate amount result");
//                                if(ProgressD != null){
//                                    ProgressD.dismiss();
//                                }
//
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//
//                                        if (abb.toString().contains("Booking")) {
//                                            Toast.makeText(ReservationEbsIntegration.this,
//                                                    abb, Toast.LENGTH_LONG)
//                                                    .show();
//                                        } else {
//                                            GetTotalAmt=abb.substring( 0, abb.indexOf("/"));
//                                            GetServiceTax=abb.substring(abb.indexOf("/") + 1, abb.lastIndexOf("/"));
//                                            GetLuxuryTax=abb.substring(abb.lastIndexOf("/") + 1, abb.length());
//                                            Log.e("GetTotalAmt =", GetTotalAmt);
//                                            Log.e("GetServiceTax =", GetServiceTax);
//                                            Log.e("GetLuxuryTax =", GetLuxuryTax);
//                                            calAmt.setText(GetTotalAmt);
//                                            Button btnfocus = (Button) findViewById(R.id.Btn_Submit);
//                                            btnfocus.setFocusable(true);
//                                            btnfocus.setFocusableInTouchMode(true);
//                                            btnfocus.requestFocus();
//                                           /* TableRow _tableRow =(TableRow)findViewById(R.id.tableRowMainBody);
//                                            _tableRow.requestFocus();*/
//                                        }
//
//
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//                //=======================================
//                ///////////////Button Exit
//            }
//        });
//
//
//        Button button = (Button) findViewById(R.id.Btn_Submit);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                ///Validation////////////////////
//                ChkInDate=(EditText)findViewById(R.id.edt_ChkInDate);
//                 GetCheckInDate = ChkInDate.getText().toString();
////                if (GetCheckInDate.equals("") || GetCheckInDate.equals("0")) {
////                    //  ChkInDAte.setError("Enter Valid CheckInDate");
////                    ChkInDate.requestFocus();
////                    Toast.makeText(Reservation.this, "Enter Check In Date.", Toast.LENGTH_LONG).show();
////                    return;
////                }
//
//                final EditText ChkOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
//                 getChkOutDate = ChkOutDate.getText().toString();
//                if (getChkOutDate.equals("") || getChkOutDate.equals("0")) {
//                    // ChkOutDate.setError("Enter Valid CheckOutDate");
//                    Toast.makeText(ReservationEbsIntegration.this, "Enter Valid CheckOutDate", Toast.LENGTH_LONG).show();
//                    ChkOutDate.requestFocus();
//                    return;
//                }
//                //end validation
//                RName = sp1.getSelectedItem().toString();
//                final String CatName = sp2.getSelectedItem().toString();
//                 CtName = CatName.substring(CatName.indexOf(",") + 1, CatName.indexOf("("));
//                 NoOfRooms = sp3.getSelectedItem().toString();
//                final EditText CName = (EditText) findViewById(R.id.edt_CustName);
//                CusName = CName.getText().toString();
//                if (CusName.equals("") || CusName.equals("0")) {
//                    CName.setError("Enter Customer Name");
//                    CName.requestFocus();
//                    return;
//                }
//                //   final EditText CAdd = (EditText) findViewById(R.id.edt_);
//                //    final String CusAdd=CName.getText().toString();
//                final EditText CEmailId = (EditText) findViewById(R.id.edt_EmailId);
//                  CusEId = CEmailId.getText().toString();
//                if (CusEId.equals("") || CusEId.equals("0")) {
//                    CEmailId.setError("Enter Email Id");
//                    return;
//                }
//
//
//                final EditText CPhoneNo = (EditText) findViewById(R.id.edt_PhoneNum);
//                CusPhNO = CPhoneNo.getText().toString();
//                if (CusPhNO.equals("") || CusPhNO.equals("0")) {
//                    CPhoneNo.setError("Enter Phone Number");
//                    return;
//                }
//                 CusIdentityProf = sp4.getSelectedItem().toString();
//                 CusNationality = sp5.getSelectedItem().toString();
//
//                final EditText LoginId = (EditText) findViewById(R.id.edt_loginid);
//                 CustLoginId = LoginId.getText().toString();
//
//                final TextView TaxAmt = (TextView) findViewById(R.id.edt_TaxAmount);
//                 CustTax = TaxAmt.getText().toString();
//                Button buttonCalAmt = (Button) findViewById(R.id.Btn_CalAmt);
//                if (CustTax.equals("") || CustTax.equals("0")) {
//                    //  TaxAmt.setError("Enter Tax Amount");
//                    buttonCalAmt.requestFocus();
//                    Toast.makeText(ReservationEbsIntegration.this, "Calculate  Amount..", Toast.LENGTH_LONG).show();
//                    return;
//                }
//                Log.e("CustTax =", CustTax);
//                final TextView RCalAmt = (TextView) findViewById(R.id.edt_TaxAmt);
//
//                final     RadioGroup    radioGroup = (RadioGroup) findViewById(R.id.radiogrp);
//                // get selected radio button from radioGroup
//                int selectedId = radioGroup.getCheckedRadioButtonId();
//
//                // find the radiobutton by returned id
//                final    RadioButton      radioButton = (RadioButton) findViewById(selectedId);
//
////                ProgressD = new ProgressDialog(Reservation.this);
////                ProgressD.setTitle("Please Wait....");
////                ProgressD.setCancelable(true);
////                ProgressD.setCanceledOnTouchOutside(false);
////                ProgressD.show();
//
//                //Recalculate AmountTo be paid
//                // Call web service
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME5);
//                        request.addProperty("Checkin", GetCheckInDate);
//                        request.addProperty("CheckOut", getChkOutDate);
//                        request.addProperty("NoOfUnits", NoOfRooms);
//                        request.addProperty("DestCode", RName);
//                        request.addProperty("UnitType", CtName);
//
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION5, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                SubmitRes = result.getProperty(0).toString();
////                                if(ProgressD != null){
////                                    ProgressD.dismiss();
////                                }
//                                Log.e("SubmitRes =", SubmitRes);
//                                GetTotAmtFinal=SubmitRes.substring( 0, abb.indexOf("/"));
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        if (GetTotAmtFinal.equals(CustTax)) {
//                                            CheckBox cb1 = (CheckBox) findViewById(R.id.Chk_Box);
//                                            if (cb1.isChecked() == true) {
//                                                new Thread() {
//                                                    @Override
//                                                    public void run() {
//
//                                                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME4);
//                                                        request.addProperty("Login", CustLoginId);
//                                                        request.addProperty("NoUnits", NoOfRooms);
//                                                        request.addProperty("CustName", CusName);
//                                                        request.addProperty("CustAdd", "ABC");
//                                                        request.addProperty("EmailId", CusEId);
//                                                        request.addProperty("PhoneNo", CusPhNO);
//                                                        request.addProperty("DestName", RName);
//                                                        request.addProperty("UnitName", CtName);
//                                                        request.addProperty("CheckIn", GetCheckInDate);
//                                                        request.addProperty("CheckOut", getChkOutDate);
//                                                        request.addProperty("PaymentMode",  radioButton.getText());
//                                                        request.addProperty("Discount", "0");
//                                                        request.addProperty("IdProof", CusIdentityProf);
//                                                        request.addProperty("Nationality", CusNationality);
//                                                        request.addProperty("PPno", "TEST");
//                                                        request.addProperty("PAmount", CustTax);
//                                                        request.addProperty("ServiceTax", GetServiceTax);
//                                                        request.addProperty("LuxuryTax", GetLuxuryTax);
//                                                        //Declare the version of the SOAP request
//                                                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                                                        envelope.setOutputSoapObject(request);
//                                                        envelope.dotNet = true;
//
//                                                        try {
//                                                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                                                            //this is the actual part that will call the webservice
//                                                            androidHttpTransport.call(SOAP_ACTION4, envelope);
//                                                            // Get the SoapResult from the envelope body.
//                                                            // SoapObject result = (SoapObject) envelope.bodyIn;
//                                                            SoapPrimitive result = (SoapPrimitive)envelope.getResponse();
//                                                            //  resultRequestSOAP = (SoapObject) envelope.getResponse();
//                                                            if (result != null) {
//                                                                abb = result.toString();
//
////
//                                                                Log.e("abb =", abb);
//                                                                //Get the first property and change the label text
//
//                                                                runOnUiThread(new Runnable() {
//                                                                    @Override
//                                                                    public void run() {
//                                                                        if (radioButton.getText().equals("AXIS")) {
//                                                                            if (abb.toString().contains("http://")) {
//                                                                                //if (SubmitRes.equals("http")) {
//                                                                                Intent inte = new Intent(getApplicationContext(), WebViewActivity.class);
//                                                                                inte.putExtra("URL", abb);
//                                                                                startActivity(inte);
//
//
//                                                                            } else if (abb.equals("9")) {
//                                                                                Toast.makeText(ReservationEbsIntegration.this,
//                                                                                        "No Rooms Available!!", Toast.LENGTH_LONG)
//                                                                                        .show();
//                                                                            } else {
//                                                                                Toast.makeText(ReservationEbsIntegration.this,
//                                                                                        "Some Error Occured!!", Toast.LENGTH_LONG)
//                                                                                        .show();
//                                                                            }
//                                                                        }
//                                                                        else if (radioButton.getText().equals("HDFC")) {
//
//                                                                            if (abb.toString().contains("http://")) {
//                                                                                callEbsKit(ReservationEbsIntegration.this);
//                                                                                //if (SubmitRes.equals("http")) {
////                                                                                Intent inte = new Intent(getApplicationContext(), WebViewHDFC.class);
////                                                                                inte.putExtra("URL", abb);
////                                                                                inte.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
////                                                                                startActivity(inte);
//
//                                                                            } else if (abb.equals("9")) {
//                                                                                Toast.makeText(ReservationEbsIntegration.this,
//                                                                                        "No Rooms Available!!", Toast.LENGTH_LONG)
//                                                                                        .show();
//                                                                                Log.e(abb,"result**");
//                                                                            }
//                                                                            else {
//                                                                                Toast.makeText(ReservationEbsIntegration.this,
//                                                                                        "Some Error Occured!!", Toast.LENGTH_LONG)
//                                                                                        .show();
//
//                                                                            }
//                                                                        }
//                                                                    }
//                                                                });
//                                                            } else {
//                                                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                                                            }
//                                                        } catch (Exception e) {
//                                                            e.printStackTrace();
//                                                        }
//                                                    }
//                                                }.start();
//                                                //=======================================
//                                            } else {
//                                                Toast.makeText(ReservationEbsIntegration.this, "Please Accept the terms and conditions.", Toast.LENGTH_LONG).show();
//                                            }
//
//                                        } else {
//                                            Toast.makeText(ReservationEbsIntegration.this, "Recalculate Amount..", Toast.LENGTH_LONG).show();
//                                        }
//                                        /* if (SubmitRes.toString().contains("Booking")) {
//                                             Toast.makeText(Reservation.this,
//                                                     SubmitRes, Toast.LENGTH_LONG)
//                                                     .show();
//                                         } else  {
//                                             RCalAmt.setText(SubmitRes);
//                                         }*/
//                                    }
//                                });
//
//                            } else {
//
//                                Toast.makeText(getApplicationContext(), "No Response", Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//                //=======================================
//                ///////////////Button Exit
//            }
//        });
//        //=======================================
//    }     ///////////////Button Exit
//
//////////////////////Create EBS kit///////////////////////////
//private void callEbsKit(ReservationEbsIntegration buyProduct) {
//    /**
//     * Set Parameters Before Initializing the EBS Gateway, All mandatory
//     * values must be provided
//     */
//
//    /** Payment Amount Details */
//    // Total Amount
//
//    PaymentRequest.getInstance().setTransactionAmount(
//            String.format(GetTotalAmt));
//
//    /** Mandatory */
//
//    PaymentRequest.getInstance().setAccountId(ACC_ID);
//    PaymentRequest.getInstance().setSecureKey(SECRET_KEY);
//
//    // Reference No
//    PaymentRequest.getInstance().setReferenceNo("223");
//    /** Mandatory */
//
//    // Email Id
//    //PaymentRequest.getInstance().setBillingEmail("test_tag@testmail.com");
//
//    PaymentRequest.getInstance().setBillingEmail(CusEId);
//    /** Mandatory */
//
//    PaymentRequest.getInstance().setFailureid("1");
//
//    // PaymentRequest.getInstance().setFailuremessage(getResources().getString(R.string.payment_failure_message));
//    // System.out.println("FAILURE MESSAGE"+getResources().getString(R.string.payment_failure_message));
//
//    /** Mandatory */
//
//    // Currency
//    PaymentRequest.getInstance().setCurrency("INR");
//    /** Mandatory */
//
//    /** Optional */
//    // Your Reference No or Order Id for this transaction
////    PaymentRequest.getInstance().setTransactionDescription(
////            "Test Transaction");
//
//    /** Billing Details */
//    PaymentRequest.getInstance().setBillingName(CusName);
//    /** Optional */
//
//    PaymentRequest.getInstance().setBillingAddress("ABC");
//    /** Optional */
//    PaymentRequest.getInstance().setBillingCity("Chennai");
//    /** Optional */
//    PaymentRequest.getInstance().setBillingPostalCode("600019");
//    /** Optional */
//    PaymentRequest.getInstance().setBillingState("Tamilnadu");
//    /** Optional */
//    PaymentRequest.getInstance().setBillingCountry("IND");
//    /** Optional */
//    PaymentRequest.getInstance().setBillingPhone(CusPhNO);
//    /** Optional */
//
//    /** Shipping Details */
//    PaymentRequest.getInstance().setShippingName("Test_Name");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingAddress("North Mada Street");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingCity("Chennai");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingPostalCode("600019");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingState("Tamilnadu");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingCountry("IND");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingEmail("test@testmail.com");
//    /** Optional */
//    PaymentRequest.getInstance().setShippingPhone("01234567890");
//    /** Optional */
//
//    PaymentRequest.getInstance().setLogEnabled("1");
//
//
//    /**
//     * Payment option configuration
//     */
//
//    /** Optional */
//    PaymentRequest.getInstance().setHidePaymentOption(false);
//
//    /** Optional */
//    PaymentRequest.getInstance().setHideCashCardOption(false);
//
//    /** Optional */
//    PaymentRequest.getInstance().setHideCreditCardOption(false);
//
//    /** Optional */
//    PaymentRequest.getInstance().setHideDebitCardOption(false);
//
//    /** Optional */
//    PaymentRequest.getInstance().setHideNetBankingOption(false);
//
//    /** Optional */
//    PaymentRequest.getInstance().setHideStoredCardOption(false);
//
//    /**
//     * Initialise parameters for dyanmic values sending from merchant
//     */
//
//    custom_post_parameters = new ArrayList<HashMap<String, String>>();
//    HashMap<String, String> hashpostvalues = new HashMap<String, String>();
//    hashpostvalues.put("account_details", "saving");
//    hashpostvalues.put("merchant_type", "gold");
//    custom_post_parameters.add(hashpostvalues);
//
//    PaymentRequest.getInstance()
//            .setCustomPostValues(custom_post_parameters);
//    /** Optional-Set dyanamic values */
//
//    // PaymentRequest.getInstance().setFailuremessage(getResources().getString(R.string.payment_failure_message));
//
////        EBSPayment.getInstance().init(buyProduct, ACC_ID, SECRET_KEY,
//    ////Add account id, Secret Key
//    EBSPayment.getInstance().init( ReservationEbsIntegration.this,ACC_ID, SECRET_KEY,
////                Mode.ENV_LIVE, Encryption.ALGORITHM_MD5, HOST_NAME);
//            Mode.ENV_TEST, Encryption.ALGORITHM_MD5, HOST_NAME);
//
//}
//
//    //////////////////End of EBS kIt////////////////////////
//
//    public class myWebClient extends WebViewClient
//    {
//        @Override
//        public void onPageStarted(WebView view, String url, Bitmap favicon) {
//            // TODO Auto-generated method stub
//            super.onPageStarted(view, url, favicon);
//        }
//
//        @Override
//        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            // TODO Auto-generated method stub
//
//            view.loadUrl(url);
//            return true;
//
//        }
//    }
//
//
//
//    private void findViewsById() {
//        fromDateEtxt = (EditText) findViewById(R.id.edt_ChkInDate);
//        fromDateEtxt.setInputType(InputType.TYPE_NULL);
//        fromDateEtxt.requestFocus();
//
//        toDateEtxt = (EditText) findViewById(R.id.edt_chkOutDate);
//        toDateEtxt.setInputType(InputType.TYPE_NULL);
//    }
//    private void setDateTimeField() {
//        fromDateEtxt.setOnClickListener(this);
//        toDateEtxt.setOnClickListener(this);
//
//        Calendar newCalendar = Calendar.getInstance();
//        fromDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
//
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                Calendar newDate = Calendar.getInstance();
//                newDate.set(year, monthOfYear, dayOfMonth);
//                fromDateEtxt.setText(dateFormatter.format(newDate.getTime()));
//            }
//
//        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
//        String myFormat = "dd-MMM-yyyy"; //In which you need put here
//        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
//        fromDateEtxt.setText(sdf.format(newCalendar.getTime()));
//        Date newDate2 = newCalendar.getTime();
//        fromDatePickerDialog.getDatePicker().setMinDate(newDate2.getTime());
//
//
//
//
//
//        newCalendar.add(Calendar.DATE, 1);
//        toDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
//
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                Calendar newDate = Calendar.getInstance();
//                newDate.set(year, monthOfYear, dayOfMonth);
//                toDateEtxt.setText(dateFormatter.format(newDate.getTime()));
//            }
//
//        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
//        String myFormatTo = "dd-MMM-yyyy"; //In which you need put here
//        SimpleDateFormat sdfTo = new SimpleDateFormat(myFormatTo, Locale.US);
//        toDateEtxt.setText(sdfTo.format(newCalendar.getTime()));
//        Date newDate23 = newCalendar.getTime();
//        toDatePickerDialog.getDatePicker().setMinDate(newDate23.getTime());
//    }
//
//
//    @Override
//    public void onClick(View view) {
//        if(view == fromDateEtxt) {
//            fromDatePickerDialog.show();
//        } else if(view == toDateEtxt) {
//            toDatePickerDialog.show();
//        }
//    }
//    public void onStart() {
//        super.onStart();
//        EditText TxtDate = (EditText) findViewById(R.id.edt_ChkInDate);
//
//         /*SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/YYYY");
//             TxtDate.setText(dateFormat.format(new Date()));*/
//
//       /*  TxtDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//             @Override
//             public void onFocusChange(View v, boolean hasFocus) {
//                 if (hasFocus) {
//
//                     DateDialog Dialog = new DateDialog(v);
//                     FragmentTransaction ft = getFragmentManager().beginTransaction();
//                     Dialog.show(ft, "DatePicker");
//
//                 }
//             }
//         });*/
//        EditText ChekOutDate = (EditText) findViewById(R.id.edt_chkOutDate);
//
//        /* ChekOutDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//             @Override
//             public void onFocusChange(View v, boolean hasFocus) {
//                 if (hasFocus) {
//
//                     DateDialog Dialog = new DateDialog(v);
//                     FragmentTransaction ft = getFragmentManager().beginTransaction();
//                     Dialog.show(ft, "DatePicker");
//                 }
//             }
//         });*/
//
//        ProgressD = new ProgressDialog(ReservationEbsIntegration.this);
//        ProgressD.setTitle("Please Wait....");
//        ProgressD.setCancelable(true);
//        ProgressD.setCanceledOnTouchOutside(false);
//        ProgressD.show();
//        //call Web service for spinner District names
//
//        new Thread() {
//            @Override
//            public void run() {
//
//
//                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME6);
//                //Declare the version of the SOAP request
//                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                envelope.setOutputSoapObject(request);
//                envelope.dotNet = true;
//
//                try {
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                    //this is the actual part that will call the webservice
//                    androidHttpTransport.call(SOAP_ACTION6, envelope);
//                    // Get the SoapResult from the envelope body.
//                    SoapObject result = (SoapObject) envelope.bodyIn;
//                    ;
//                    if (result != null) {
//                        //Get the first property and change the label text
//
//                        abb = result.getProperty(0).toString();
////                         if(ProgressD != null){
////                             ProgressD.dismiss();
////                         }
//
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                // ArrayList tExp = new ArrayList();
//                                ArrayList<spinerobj> Distts = new ArrayList<spinerobj>();
//                                //
//                                try {
//                                    JSONObject jsonResponse = new JSONObject(abb);
//                                    JSONArray jsonArray = jsonResponse.optJSONArray("Table");
//
//                                    final String[] items = new String[jsonArray.length()];
//                                    if (jsonArray != null) {
//                                        for (int i = 0; i < jsonArray.length(); i++) {
//                                            JSONObject youValue = jsonArray.getJSONObject(i);
//                                            String idModule = youValue.getString("DistrictName");
//                                            String id = youValue.getString("DistrictID");
//                                            Distts.add(new spinerobj(id, idModule));
//                                            // Use the same for remaining values
//                                        }
//                                    }
//                                    Spinner spDistt = (Spinner) findViewById(R.id.spin_Distt);
//                                    //  sp.setAdapter(new ArrayAdapter<String>(Reservation.this, R.layout.support_simple_spinner_dropdown_item, Resorts));
//
//                                    ArrayAdapter<spinerobj> dataAdapter = new ArrayAdapter<spinerobj>(ReservationEbsIntegration.this,
//                                            android.R.layout.simple_spinner_item, Distts);
//                                    // Drop down layout style - list view with radio button
//                                    dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                                    spDistt.setAdapter(dataAdapter);
//
//
//
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
////
//                            }
//                        });
//
//
//                    } else {
//
//                        //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                    }
//
//                } catch (Exception e) {
//
//                    e.printStackTrace();
//
//                }
//            }
//        }.start();
//
//        //End Web service District name
//
//
//    }
//
//
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        final int id = item.getItemId();
//        //call Web service for spinner resort names
//
//        new Thread() {
//            @Override
//            public void run() {
//
//
//                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
//                request.addProperty("Ddl_Resort", id);
//                //Declare the version of the SOAP request
//                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                envelope.setOutputSoapObject(request);
//                envelope.dotNet = true;
//
//                try {
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                    //this is the actual part that will call the webservice
//                    androidHttpTransport.call(SOAP_ACTION2, envelope);
//                    // Get the SoapResult from the envelope body.
//                    SoapObject result = (SoapObject) envelope.bodyIn;
//                    ;
//                    if (result != null) {
//                        //Get the first property and change the label text
//
//                        abb = result.getProperty(0).toString();
//
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                // ArrayList tExp = new ArrayList();
//                                ArrayList<String> Resorts = new ArrayList<String>();
//                                //
//                                try {
//                                    JSONObject jsonResponse = new JSONObject(abb);
//                                    JSONArray jsonArray = jsonResponse.optJSONArray("Table");
//
//                                    final String[] items = new String[jsonArray.length()];
//                                    if (jsonArray != null) {
//                                        for (int i = 0; i < jsonArray.length(); i++) {
//                                            JSONObject youValue = jsonArray.getJSONObject(i);
//                                            String idModule = youValue.getString("unittype1");
//                                            String id = youValue.getString("unit_type");
//                                            Resorts.add(idModule);
//                                            // Use the same for remaining values
//                                        }
//                                    }
//                                    Spinner sp = (Spinner) findViewById(R.id.spin_RoomCat);
//                                    sp.setAdapter(new ArrayAdapter<String>(ReservationEbsIntegration.this, R.layout.support_simple_spinner_dropdown_item, Resorts));
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
////
//                            }
//                        });
//
//                    } else {
//
//                        //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                    }
//                } catch (Exception e) {
//
//                    e.printStackTrace();
//
//                }
//            }
//        }.start();
//
//        //End Web service resort name
//
//        //call Web service for spinner resort names
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//    private static int monthStringToInt(String month) {
//        int monthInt=0;
//        int January = Integer.valueOf (Calendar.JANUARY);
//
//        if (month.equals("Jan"))
//        {
//            monthInt = 1;
//        }
//        if (month.equals("Feb"))
//        {
//            monthInt = 2;
//        }
//        if (month.equals("Mar"))
//        {
//            monthInt = 3;
//        }
//        if (month.equals("Apr"))
//        {
//            monthInt = 4;
//        }
//        if (month.equals("May"))
//        {
//            monthInt = 5;
//        }
//        if (month.equals("Jun"))
//        {
//            monthInt = 6;
//        }
//        if (month.equals("Jul"))
//        {
//            monthInt = 7;
//        }
//        if (month.equals("Aug"))
//        {
//            monthInt = 8;
//        }
//        if (month.equals("Sep"))
//        {
//            monthInt = 9;
//        }
//        if (month.equals("Oct"))
//        {
//            monthInt = 10;
//        }
//        if (month.equals("Nov"))
//        {
//            monthInt = 11;
//        }
//        if (month.equals("Dec"))
//        {
//            monthInt = 12;
//        }
//
//        return monthInt;
//
//    }
//
//
//    @Override
//    public void onBackPressed()
//    {
//        super.finish();
//        Intent intent = new Intent(ReservationEbsIntegration.this, NavigationScreen.class);
//        startActivity(intent);
//
////        finish();
//
//
//    }
//
//    //////////////Check internet connectivity
//    public static boolean isNetworkAvailable(final Context context) {
//        boolean isNetAvailable = false;
//        if (context != null) {
//            final ConnectivityManager mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//            if (mConnectivityManager != null) {
//                final NetworkInfo activeNetwork = mConnectivityManager.getActiveNetworkInfo();
//                if(activeNetwork != null) isNetAvailable = true;
//            }
//        }
//        return isNetAvailable;
//    }
//
//    //////////////////End internet connectivity
//
//}
