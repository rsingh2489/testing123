package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class NewRegistration extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/CreateUserNEW";
    private static String SOAP_ACTION2 = "http://tempuri.org/IsUserExist";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "CreateUserNEW";
    //  private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    String GetPwd;
    String GetMobNo=null;
    String SavedMobile;
    ProgressDialog pDialog;
    private SoapObject result = null;
    String Getuid,UIdStr,Finluser;
    EditText uid,MobNo_edt,myTextBoxUid,Pswrd,cnfrmPasswrd;
    TextView TxtMobNo;

//    String GetMobileNO;
    String GetEmail, GetUName, UserPho, UserName;

    SessionManagement session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_new_registration);
////////////////////////////////////////////////////////////////////////
        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);
        uid = (EditText) findViewById(R.id.Edt_uid);
        MobNo_edt = (EditText) findViewById(R.id.Edt_MobileNo);
        TxtMobNo=(TextView)findViewById(R.id.txt_MobNo);
        if(getIntent().hasExtra("UserName")) {
            String messageUname = getIntent().getStringExtra("UserName").toString();
            TxtMobNo.setText(messageUname);
            UserName=messageUname.toString();
        }
        if(getIntent().hasExtra("MobileNo")) {
            UserPho = getIntent().getStringExtra("MobileNo");
            uid.setText(UserPho);
//            String messagePh = getIntent().getStringExtra("MobileNo").toString();
//            UserPho = messagePh.toString();
        }
        if(getIntent().hasExtra("PhoneNo")){
            SavedMobile=getIntent().getStringExtra("PhoneNo");
            MobNo_edt.setText(SavedMobile);
        }

        Btn_Home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(NewRegistration.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });

        //Button Click/////////////////
        Button button = (Button) findViewById(R.id.BtnRegister);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                ///Validation////////////////////
                final EditText UName = (EditText) findViewById(R.id.Edt_UserName);
                UName.setMaxLines(1);
                 GetUName = UName.getText().toString();
                if (GetUName.equals("") || GetUName.equals("0")) {
                    UName.setError("Enter User Name");
                    return;
                }

                SavedMobile = MobNo_edt.getText().toString();

                Getuid = uid.getText().toString();
                if (Getuid.equals("") || Getuid.equals("0")) {
                    uid.setError("Enter UserId ");
                    return;
                }
                final EditText Email = (EditText) findViewById(R.id.Edt_EmailId);
                Email.setMaxLines(1);
                 GetEmail = Email.getText().toString();
                if (GetEmail.equals("") || GetEmail.equals("0")) {
                    Email.setError("Enter Email Id");
                    return;
                }
                final EditText Pwd = (EditText) findViewById(R.id.Edt_Passwrd);
                Pwd.setMaxLines(1);
                GetPwd = Pwd.getText().toString();
                if (GetPwd.equals("") || GetPwd.equals("0")) {
                    Pwd.setError("Enter Password");
                    return;
                }
                final EditText EmailId = (EditText) findViewById(R.id.Edt_EmailId);

                final String GetEmailNew = EmailId.getText().toString();
                String Expn =
                        "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";

                if (GetEmailNew.matches(Expn) && GetEmailNew.length() > 0) {
                   /* EmailId.setText("valid email");*/
                } else {
                    EmailId.setError("invalid email");
                    return;
                }


                Pswrd = (EditText) findViewById(R.id.Edt_Passwrd);


                final String GetPasswrd = Pswrd.getText().toString();
                String Exppressionn = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
                if(!GetPasswrd.matches(Exppressionn))
                {
                    Pswrd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");
                    return;
                }
                /////////////confirm password
                ///Todo check if confrim password is working or not
                cnfrmPasswrd=(EditText)findViewById(R.id.edt_ConfrmPass);
                final String GetConfirmPasswrd = cnfrmPasswrd.getText().toString();
                String Exppression1 = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
                if(GetConfirmPasswrd.equals(""))
                {
                    cnfrmPasswrd.setError("Confirm password cannot be blank");
                    return;

                }

                if(!GetConfirmPasswrd.matches(Exppression1))
                {
                    cnfrmPasswrd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");

                    return;
                }
                 if (GetPasswrd.equals(GetConfirmPasswrd))
                {

                }
                else
                {
                    cnfrmPasswrd.setError("Password does not match");
                    return;
                }
                /////////end confrim password
                SoapAccessTask task = new SoapAccessTask();
                task.execute();


            }
        });

        //Redirect Login
        TextView LogIn= (TextView) findViewById(R.id.LogInLink);
        LogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(getApplicationContext(), LoginActivity .class);
                startActivity(inte);
            }
        });

    }

    private class SoapAccessTask extends AsyncTask<String,Void,String>
    {
        protected void onPreExecute() {
            pDialog = new ProgressDialog(NewRegistration.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }


        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("UserName", GetUName);
                request.addProperty("PhoneNo", SavedMobile);
                request.addProperty("EmailId", GetEmail);
                request.addProperty("Password", GetPwd);
//                        request.addProperty("UserId",UIdStr);
                request.addProperty("UserId", Getuid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;

                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(NewRegistration.this, "Please...Try after sometime", Toast.LENGTH_SHORT).show();
            }

            return webResponse;
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                abb = result.toString();

                        if (abb.equals("1")) {
                            Toast.makeText(NewRegistration.this, "Registration Successful. ", Toast.LENGTH_SHORT).show();
                            Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                            inte.putExtra("MobileNo", SavedMobile);
                            inte.putExtra("UserName", GetUName);
                            inte.putExtra("UserId", Finluser);
                            startActivity(inte);
                        } else if (abb.equals("2")) {
                            uid.setError("User already exist");
                            Toast.makeText(NewRegistration.this,
                                    "User already Exists!!", Toast.LENGTH_LONG)
                                    .show();
                        } else if (abb.equals("3")) {
//                                            Toast.makeText(Register.this,
//                                                    "OTP is not verified!!", Toast.LENGTH_LONG)
//                                                    .show();
                            Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                            inte.putExtra("MobileNo", GetMobNo);
                            inte.putExtra("UserName", GetUName);
                            inte.putExtra("UserId", Finluser);
                            startActivity(inte);
                        } else {
                            Toast.makeText(NewRegistration.this,
                                    "Registration Unsuccessfull!!", Toast.LENGTH_LONG)
                                    .show();
                        }
            }
            }
    }

    private void sessionManage()
    {
        session = new SessionManagement(getApplicationContext());
    }

}

