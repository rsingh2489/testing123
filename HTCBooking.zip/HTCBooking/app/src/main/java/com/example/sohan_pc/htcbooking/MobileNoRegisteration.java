package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class MobileNoRegisteration extends Activity {

    // TODO Call Method of mobile no
    private static String SOAP_ACTION1 = "http://tempuri.org/CreateMobileDetails";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "CreateMobileDetails";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb="mobile";
    private SoapObject result = null;
    String name2;
    String getMobNo,getotp;
    //TODO Otp Auto Detect
    //Declare dialog box
    ProgressDialog pDialog;

    //=============Initialise button & EditText=============
    EditText MobNo,otp;
    Button SubmitMobNo;
    ImageView BackImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_mobile_no_registeration);
        MobNo=(EditText)findViewById(R.id.Edt_MobileNo);
        SubmitMobNo=(Button)findViewById(R.id.MobSubmit_Button);
        BackImg=(ImageView)findViewById(R.id.butHome);
        otp=(EditText)findViewById(R.id.OtpEdittxt);

        ///////////////Back image on click Event//////////////////////
        BackImg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(MobileNoRegisteration.this, "Try after sometime", Toast.LENGTH_SHORT).show();
                }
            }
        });
        ///////////// End of back image onclick event/////////////////////

        ////////////Submit Mobile no. Click Event////////////////////////
        SubmitMobNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ///////////Validations
                getMobNo = MobNo.getText().toString();
                if (getMobNo.length() < 10) {
                    MobNo.setError("Enter correct Mobile No");
                    return;
                }
                getotp = otp.getText().toString();

                if (getMobNo.equals("") || getMobNo.equals("0")) {
                    MobNo.setError("Enter Mobile No");
                    return;
                }
                ////////End Validation/////////
                // ToDO call method
                //MobileNo();
                SoapAccessTask task = new SoapAccessTask();
                task.execute();

            }
        });


        ////////////End Mobile no.click////////////////////////////////

    }

    /////Start async task///////
    private class  SoapAccessTask extends AsyncTask<String, Void, String> {
        protected void onPreExecute() {
            pDialog = new ProgressDialog(MobileNoRegisteration.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
//
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("PhoneNo", getMobNo);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e)
            {
                Toast.makeText(MobileNoRegisteration.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                abb = result.toString();
                String[] namesList = abb.split(",");
                getotp = namesList[1];

                if (abb.contains(",")) {

                    Intent inte = new Intent(getApplicationContext(), NewOtpVerification.class);
                    inte.putExtra("MobileNo", getMobNo);
                    inte.putExtra("OTP", getotp);
                    startActivity(inte);
//
                } else if (abb.equals("2")) {
                    Toast.makeText(MobileNoRegisteration.this, "Enter correct mobile no.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MobileNoRegisteration.this, abb, Toast.LENGTH_SHORT).show();
                }
            }
        }

        ///////////////end of async task class/////////////


//        public void MobileNo() {
//            ///////////Validations
//            getMobNo = MobNo.getText().toString();
//            if (getMobNo.length() < 10) {
//                MobNo.setError("Enter correct Mobile No");
//
//            }
//            getotp = otp.getText().toString();
//
//            if (getMobNo.equals("") || getMobNo.equals("0")) {
//                MobNo.setError("Enter Mobile No");
//                return;
//            }
//            ////////End Validation/////////
//
//            pd = new ProgressDialog(MobileNoRegisteration.this);
//            pd.setTitle("Please Wait....");
//            pd.setCancelable(false);
//            pd.setCanceledOnTouchOutside(false);
//            pd.show();
//            /////////ToDO CAll Webservice////////
//            ////////Call webservice////////
//            new Thread() {
//                public void run() {
//                    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                    request.addProperty("PhoneNo", getMobNo);
//                    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                    envelope.setOutputSoapObject(request);
//                    envelope.dotNet = true;
//                    try {
//                        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL, 1000 * 60 * 2);
//                        androidHttpTransport.debug = true;
//                        //this is the actual part that will call the webservice
//                        androidHttpTransport.call(SOAP_ACTION1, envelope);
//                        // Get the SoapResult from the envelope body.
//                        result = (SoapObject) envelope.bodyIn;
//                        Log.e(String.valueOf(result), "result=======================")
//                        ;
//                        if (result != null) {
//                            //Get the first property and change the label text
//
//                            abb = result.getProperty(0).toString();
//                            String[] namesList = abb.split(",");
//                            getotp = namesList[1];
//                            Log.e(abb, "result in abb is=======");
//                            Log.e(abb, "result in abb is=======");
//                            if (pd != null) {
//                                pd.dismiss();
//                            }
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    ///////////Todo get the result //////////
//                                    if (abb.contains(",")) {
//
//                                        Intent inte = new Intent(getApplicationContext(), NewOtpVerification.class);
//                                        inte.putExtra("MobileNo", getMobNo);
////                                   inte.putExtra("OtpValue", getotp);
//                                        inte.putExtra("OTP", getotp);
//                                        Log.e(getotp, "otp===");
//                                        Log.e(getMobNo, "Mobileno");
//                                        startActivity(inte);
////                                    sendBroadcast(inte);
////
//                                    } else if (abb.equals("2")) {
//                                        Toast.makeText(MobileNoRegisteration.this, "Enter correct mobile no.", Toast.LENGTH_SHORT).show();
//                                    } else {
//                                        Toast.makeText(MobileNoRegisteration.this, abb, Toast.LENGTH_SHORT).show();
//                                    }
//                                }
//                            });
//                            ////////////End///////////////////
//
//                        } else {
//                            Toast.makeText(getApplicationContext(), "No Response", Toast.LENGTH_LONG).show();
//                        }
//                    } catch (Exception e) {
//
//                        e.printStackTrace();
//
//                    }
//                }
//            }.start();
//        }
   }
}






