//package com.example.sohan_pc.htcbooking;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
//import android.util.Log;
//import android.view.View;
//import android.view.Window;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import org.ksoap2.SoapEnvelope;
//import org.ksoap2.serialization.SoapObject;
//import org.ksoap2.serialization.SoapSerializationEnvelope;
//import org.ksoap2.transport.HttpTransportSE;
//public class OTPVerification extends Activity {
//    private static String SOAP_ACTION1 = "http://tempuri.org/VerifyOTP";
//    private static String SOAP_ACTION2 = "http://tempuri.org/Update";
//    private static String NAMESPACE = "http://tempuri.org/";
//    private static String METHOD_NAME1 = "VerifyOTP";
//    private static String METHOD_NAME2 = "Update";
// //   private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
// private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
//    private static String abb = "aaa";
//    String UserPho,UserId,UserName;
//    String getPhone=null;
//    TextView TxtMobNo;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
////        getSupportActionBar().hide();
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        setContentView(R.layout.activity_otpverification);
//
//        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butHome);
//
//        Btn_Logout.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                try {
//                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
//                    startActivity(inte);
//                } catch (Exception e) {
//
//                }
//            }
//        });
//
//         TxtMobNo=(TextView)findViewById(R.id.txt_MobNo);
//        if(getIntent().hasExtra("UserName")) {
//            String messageUname = getIntent().getStringExtra("UserName").toString();
//              TxtMobNo.setText(messageUname);
//            UserName=messageUname.toString();
//        }
//
//        if(getIntent().hasExtra("MobileNo")) {
//            String messagePh = getIntent().getStringExtra("MobileNo").toString();
//            UserPho=messagePh.toString();
//        }
//
//        if(getIntent().hasExtra("UserId")) {
//            String messageUid = getIntent().getStringExtra("UserId").toString();
//            UserId=messageUid.toString();
//        }
////Button Click
//        Button BtnVerify=(Button)findViewById(R.id.btn_Verify);
//        BtnVerify.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//           Verifyotp();
//                //eeeee
//            }
//        });
//        //End Button Click
//        //Regenerate OTP
//        TextView RegenerateOTPLink= (TextView) findViewById(R.id.Txt_Regenerate);
//        RegenerateOTPLink.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Call web service
//
//
//                //=================== ====================
//                new Thread(){
//                    @Override
//                    public void run() {
//                   getPhone  = TxtMobNo.getText().toString();
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
//                        request.addProperty("Password",0 );
//                        request.addProperty("PhoneNo",UserId);
//                        request.addProperty("IsRegenerated",1);
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION2, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result =(SoapObject) envelope.bodyIn;;
//                            if(result != null)
//                            {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        final EditText OTPno=(EditText) findViewById(R.id.Edt_OTP);
//                                        if(abb.equals("1")) {
//
//                                            OTPno.setText("");
//                                             OTPno.setFocusable(true);
//                                        }
//                                        else if(abb.equals("2")){
//                                            OTPno.setText("");
//                                            OTPno.setFocusable(true);
//                                            Toast.makeText(OTPVerification.this,
//                                                    "User Not Found!!", Toast.LENGTH_LONG)
//                                                    .show();
//
//                                        }
//                                        else if(abb.equals("3")) {
//                                            Toast.makeText(OTPVerification.this,
//                                                    "You can regenerate after 5 minutes!!", Toast.LENGTH_LONG)
//                                                    .show();
//                                        }
//
//                                        else
//                                        {
//                                            Toast.makeText(OTPVerification.this,
//                                                    "Some Error Occured!!", Toast.LENGTH_LONG)
//                                                    .show();
//                                        }
//
//                                    }
//                                });
//
//                            } else
//                            {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//
//                        }
//                    }
//                }.start();
//            }
//        });
//        //End Regenerate Password
//    }
////////////====================Method to Verify OTP by Himani===============//////
//    public void Verifyotp()
//    {
//        ///Validation////////////////////
//        final EditText OTPNo=(EditText) findViewById(R.id.Edt_OTP);
//        final String getOTP  = OTPNo.getText().toString();
//        if (getOTP.equals("") || getOTP.equals("0")) {
//            OTPNo.setError("Enter Correct OTP Number");
//            return;
//        }
////          final  String GetMobNo=TxtMobNo.getText().toString();
//        getPhone=TxtMobNo.getText().toString();
//
//        //end validation
//        // Call web service
//
//
//        //=================== ====================
//        new Thread(){
//            @Override
//            public void run() {
//
//
//                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                request.addProperty("OTP", getOTP);
//                request.addProperty("PhoneNo",UserPho);
//                request.addProperty("Username", UserName);
//                request.addProperty("UserId",UserId);
//                //Declare the version of the SOAP request
//                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                envelope.setOutputSoapObject(request);
//                envelope.dotNet = true;
//
//                try {
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                    androidHttpTransport.debug=true;
//                    //this is the actual part that will call the webservice
//                    androidHttpTransport.call(SOAP_ACTION1, envelope);
//
//                    // Get the SoapResult from the envelope body.
//                    SoapObject result =(SoapObject) envelope.bodyIn;
//                    Log.e(String.valueOf(result),"result of otp");
//                    if(result != null)
//                    {
//                        //Get the first property and change the label text
//
//                        abb = result.getProperty(0).toString();
//                        Log.e(abb,"result-----------");
//
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//
//                                if(abb.equals("1")) {
//                                    Toast.makeText(OTPVerification.this,
//                                            "OTP verified!!", Toast.LENGTH_LONG)
//                                            .show();
//
//                                    Intent inte=new Intent(getApplicationContext(),LoginActivity.class);
//
//                                    startActivity(inte);
//                                }
//                                else if(abb.equals("2")){
//                                    Toast.makeText(OTPVerification.this,
//                                            "Incorrect OTP!!", Toast.LENGTH_LONG)
//                                            .show();
//
//                                }
//                                else
//                                {
//                                    Toast.makeText(OTPVerification.this,
//                                            "Some Error Occured!!", Toast.LENGTH_LONG)
//                                            .show();
//                                }
//
//                            }
//                        });
//
//                    } else
//                    {
//
//                        //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                    }
//                } catch (Exception e) {
//
//                    e.printStackTrace();
//
//                }
//            }
//        }.start();
//        //=======================================
//        ///////////////Button Exit===========End Method////////////////////////////////
//    }
//}
