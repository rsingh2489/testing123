package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class GetRsponse extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/GetReceipt";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetReceipt";
//    private static String URL = "http://web1.hry.nic.in/HTCAndroidWS/CUSTsw/BookingDetails_HTC.aspx?cust_id=";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    private static String abb = "http://web1.hry.nic.in/htcandroidws/RESsw/frmbookingdetails.aspx";
    String messagecustid;
    String BarCodenew;
    ProgressDialog pDialog;
    String EmailID,IsMob,PhoneNo,UserLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_get_rsponse);
     final TextView BarCode = (TextView) findViewById(R.id.edt_Barcode);
        final TextView TxtCustomer = (TextView) findViewById(R.id.edt_Custid);
        if (getIntent().hasExtra("Custid")) {
             messagecustid = getIntent().getStringExtra("Custid").toString();
            TxtCustomer.setText(messagecustid);
            PhoneNo=messagecustid;
        }
        if (getIntent().hasExtra("BarCode")) {
            BarCodenew = getIntent().getStringExtra("BarCode").toString();
            BarCode.setText(BarCodenew);
        }
        BarCode.setText("123");

        TextView BookFrmEditText = (TextView) findViewById(R.id.edt_BookingFrom);
        if(getIntent().hasExtra("BookingDateFROM")) {
            String message = getIntent().getStringExtra("BookingDateFROM").toString();
            BookFrmEditText.setText(message);
        }
        TextView BookToEditText = (TextView) findViewById(R.id.edt_BookingTO);
        if(getIntent().hasExtra("BookingDateTO")) {
            String message = getIntent().getStringExtra("BookingDateTO").toString();
            BookToEditText.setText(message);
        }
        TextView ResortNAmeEditText = (TextView) findViewById(R.id.edt_RsrtName);
        if(getIntent().hasExtra("ResortName")) {
            String message = getIntent().getStringExtra("ResortName").toString();
            ResortNAmeEditText.setText(message);
        }
        TextView UnitNameEditText = (TextView) findViewById(R.id.edt_UnittName);
        if(getIntent().hasExtra("UnitName")) {
            String message = getIntent().getStringExtra("UnitName").toString();
            UnitNameEditText.setText(message);
        }
        TextView FistNameEditText = (TextView) findViewById(R.id.edt_FirstName);
        if(getIntent().hasExtra("Firstname")) {
            String message = getIntent().getStringExtra("Firstname").toString();
            FistNameEditText.setText(message);
        }
        TextView MobilemEditText = (TextView) findViewById(R.id.edt_Mobile);
        if(getIntent().hasExtra("Mobile")) {
            String message = getIntent().getStringExtra("Mobile").toString();
            MobilemEditText.setText(message);
            IsMob=message;
        }
        TextView EmailIDEditText = (TextView) findViewById(R.id.edt_emailId);
        if(getIntent().hasExtra("Email")) {
            String message = getIntent().getStringExtra("Email").toString();
            EmailIDEditText.setText(message);
            EmailID=message;
        }
        TextView RecptNoEditText = (TextView) findViewById(R.id.edt_RecieptNo);
        if(getIntent().hasExtra("ReciptNo")) {
            String message = getIntent().getStringExtra("ReciptNo").toString();
            RecptNoEditText.setText(message);
        }
        TextView AmtEditText = (TextView) findViewById(R.id.edt_PayAmount);
        if(getIntent().hasExtra("TotalAmount")) {
            String message = getIntent().getStringExtra("TotalAmount").toString();
            AmtEditText.setText(message);
        }
        if(getIntent().hasExtra("UserLogin")) {
            String messageuser = getIntent().getStringExtra("UserLogin").toString();
            UserLogin=messageuser;

        }

        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(GetRsponse.this, "Please try again", Toast.LENGTH_SHORT).show();

                }
            }
        });

        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(),NavigationScreen .class);
                    inte.putExtra("MobileNo", UserLogin);
                    inte.putExtra("MailId", EmailID);
                    inte.putExtra("Contactno", IsMob);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(GetRsponse.this, "Please try again", Toast.LENGTH_SHORT).show();

                }
            }
        });


      Button but = (Button) findViewById(R.id.Btn_Print);
        but.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Call web service
                getReceiptAsync task = new getReceiptAsync();
                task.execute();
                //=================== ====================
            }
        });
        Button butback = (Button) findViewById(R.id.Btn_Back);
        butback.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent inte=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(inte);
            }
        });

    }

    //////////////Start async task /////////
    private class getReceiptAsync extends AsyncTask<String, Void, String>
    {
        protected void onPreExecute() {
            pDialog = new ProgressDialog(GetRsponse.this);
                            pDialog.setMessage("Please Wait ...");
                            pDialog.setIndeterminate(false);
                            pDialog.setCancelable(true);
                            pDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
//
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("Custid", messagecustid);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e)
            {
                Toast.makeText(GetRsponse.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                SubmitRes = result.toString();

                        if (SubmitRes.contains("http://")) {

                            Intent inte = new Intent(getApplicationContext(), webviewprint.class);
                            inte.putExtra("URL", SubmitRes);
                            inte.putExtra("Custid",messagecustid);
                            inte.putExtra("MobileNo", UserLogin);
                            inte.putExtra("MailId", EmailID);
                            inte.putExtra("Contactno", IsMob);
                            startActivity(inte);

                        } else if (SubmitRes.equals("9")) {
                            Toast.makeText(GetRsponse.this,
                                    "No Rooms Available1!!", Toast.LENGTH_LONG)
                                    .show();
                        } else {
                            Toast.makeText(GetRsponse.this,
                                    "Some Error Occured!!", Toast.LENGTH_LONG)
                                    .show();
                        }
            }
        }
    }

    ////////////End async task////////////////

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_get_rsponse, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
