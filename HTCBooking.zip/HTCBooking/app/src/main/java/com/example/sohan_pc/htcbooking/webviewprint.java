package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.graphics.drawable.PictureDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Environment;
import android.print.pdf.PrintedPdfDocument;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

//import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;

import android.app.ProgressDialog;
//This class is required to read image into Image object
import com.itextpdf.text.pdf.codec.BmpImage;

public class webviewprint extends Activity {
    private WebView webViewPrint;
    private ProgressDialog progressBar;
    //  private static final String googleDocsUrl = "http://docs.google.com/viewer?url=";
    String GetUrl;
    String Custid;
    String MobNo, EmailId, ContactNo;
    // Session Manager Class
    SessionManagement session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getSupportActionBar().hide();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_webviewprint);

        // Session class instance
        session = new SessionManagement(getApplicationContext());


        webViewPrint = (WebView) findViewById(R.id.webview_Print);
        webViewPrint.getSettings().setJavaScriptEnabled(true);
        webViewPrint.setWebViewClient(new InsideWebViewClient());
        GetUrl = (getIntent().getExtras().getString("URL"));
        webViewPrint.loadUrl(getIntent().getExtras().getString("URL"));
        Custid = (getIntent().getExtras().getString("Custid"));

        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            EmailId = messageMail;

        }


        if (getIntent().hasExtra("MobileNo")) {
            String message = getIntent().getStringExtra("MobileNo").toString();
            MobNo = message;
        }

        if (getIntent().hasExtra("Contactno")) {
            String messagecontct = getIntent().getStringExtra("Contactno").toString();
            ContactNo = messagecontct;
        }
        //  Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();

        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // name
        String name = user.get(SessionManagement.KEY_NAME);

        // email
        String email = user.get(SessionManagement.KEY_EMAIL);

        // mobile
        String mobile = user.get(SessionManagement.KEY_MOBILE);


        final ImageView Btn_Logout = (ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    session.logoutUser();
                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);
                } catch (Exception e) {

                }
            }
        });

        final ImageView Btn_Home = (ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
                    inte.putExtra("MobileNo", MobNo);
                    inte.putExtra("MailId", EmailId);
                    inte.putExtra("Contactno", ContactNo);
                    startActivity(inte);
                  /*  Intent inte = new Intent(getApplicationContext(), PrintBooking.class);
                    inte.putExtra("MobileNo", MobNo);
                    inte.putExtra("MailId", EmailId);
                    inte.putExtra("Contactno", ContactNo);
                    startActivity(inte);*/
                } catch (Exception e) {

                }
            }
        });

        // webViewPrint.setPictureListener(new WebView.PictureListener() {
        findViewById(R.id.progress1).setVisibility(View.VISIBLE);
        Button but = (Button) findViewById(R.id.BtnDownload);

        but.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://web1.hry.nic.in/HTCAndroidWS/WriteReadData/" + Custid + ".pdf"));
                Bundle b = new Bundle();
                b.putBoolean("new_window", true); //sets new window
                intent.putExtras(b);
                startActivity(intent);
            }
        });

    }

    private class InsideWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            findViewById(R.id.progress1).setVisibility(View.VISIBLE);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            // Log.i("OnPageLoadFinished", url);
            // img.setImageBitmap(bmp);
            // progressBar=(ProgressBar)findViewById(R.id.progress1);
            progressBar.dismiss();

            // findViewById(R.id.progress1).setVisibility(View.GONE);
        }

    }

    private static Bitmap pictureDrawable2Bitmap(PictureDrawable pictureDrawable) {
        Bitmap bitmap = Bitmap.createBitmap(
                pictureDrawable.getIntrinsicWidth(),
                pictureDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawPicture(pictureDrawable.getPicture());
        return bitmap;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_webviewprint, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_save) {

        }

        return super.onOptionsItemSelected(item);
    }

    public void onStart() {
        super.onStart();
        progressBar = new ProgressDialog(webViewPrint.getContext());
        progressBar.setCancelable(true);
        progressBar.setMessage("File loading ...");
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();

    }

}