//package com.example.sohan_pc.htcbooking;
//
//import android.app.Activity;
//import android.app.ProgressDialog;
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.v7.widget.DefaultItemAnimator;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//
//import com.kyo.expandablelayout.ExpandableLayout;
//
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//import org.ksoap2.SoapEnvelope;
//import org.ksoap2.serialization.SoapObject;
//import org.ksoap2.serialization.SoapSerializationEnvelope;
//import org.ksoap2.transport.HttpTransportSE;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//
///**
// * Created by Deepak on 6/16/2017.
// */
//public class testRecyclerAdapter extends Activity {
//
//
//    public TextView title, year, genre,dest_name,pay_amount1,noofunits1,Srno1,Cat1,UnitNo1,Datefrom1,DateTo1;
//    //public TextView cust_id2, dateFrom2,dateTo2,transactiondate2,noofrooms2,unittypeCategory2,ratePerUnit2,refundedAmount2,amountPaid2,Paymode2;
//    public Button CancelBooking;
//    private static final int TYPE_IMAGE_VIEW = 0;
//    private static final int TYPE_TEXT_VIEW = 1;
//    private List<Item> mItems;
//    private RecyclerView mRecyclerView;
//    /////////////////////////////////////
//    private MyAdapter mAdapter;
//    private static String SOAP_ACTION1 = "http://tempuri.org/GetDetails";
//    private static String NAMESPACE = "http://tempuri.org/";
//    private static String METHOD_NAME1 = "GetDetails";
//    //////////////Already cancel/////////////
//    private static String SOAP_ACTION2 = "http://tempuri.org/Show_Cancellation_Details";
//    private static String METHOD_NAME2 = "Show_Cancellation_Details";
//    ////////////////////////////////////////
//
//    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
//    private static String SubmitRes = "pp";
//    String messagecustid,noofunits,Email,MobileNo;
//    private List<Modal> movieList = new ArrayList<>();
//    private RecyclerView recyclerView;
////    private RecyclerViewAdapter mAdapter;
//    String EmailID,IsMob;
//    //////////////////////
//    String idModule,name1,Dest_name,pay_amount,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,UserLgin,PrePost,RoomNos,Entrydate,Paymode,Paymodeno,PayRecdBy,noOfRows;
//    ///////////////////////////
//    ProgressDialog progress;
//    // Session Manager Class
//    SessionManagement session;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        this.setContentView(R.layout.activity_cancellation);
//
//        //////////////////
//        session = new SessionManagement(getApplicationContext());
//        //  Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
//        session.checkLogin();
//        // get user data from session
//        HashMap<String, String> user = session.getUserDetails();
//        // name
//        final String name = user.get(SessionManagement.KEY_NAME);
//        Log.e("name =", name);
//        // email
//        String email = user.get(SessionManagement.KEY_EMAIL);
//        Log.e("email =", email);
//        // mobile
//        String mobile = user.get(SessionManagement.KEY_MOBILE);
//        Log.e("mobile =",mobile);
//
//        if (getIntent().hasExtra("MobileNo")) {
//            messagecustid = getIntent().getStringExtra("MobileNo").toString();
//        }
//        if (getIntent().hasExtra("MailId")) {
//            String messageMail = getIntent().getStringExtra("MailId").toString();
//            if (messageMail.contains("/")) {
//                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
//                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
//            }
//
//            else
//                EmailID=messageMail;
//        }
//        if (getIntent().hasExtra("Contactno")) {
//
//            String messageConctno = getIntent().getStringExtra("Contactno").toString();
//            if (messageConctno.equals("1")){
//
//            }
//            else
//            {
//                IsMob=messageConctno;
//            }
//            // LoginEditText.setText(messageMbno);
//        }
//        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);
//        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
//            public void onClick(View v)  {
//                try {
//                    session.logoutUser();
//                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
//                    startActivity(inte);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);
//
//        Btn_Home.setOnClickListener(new View.OnClickListener()   {
//            public void onClick(View v)  {
//                try {
//                    Intent inte = new Intent(getApplicationContext(),NavigationScreen .class);
//                    inte.putExtra("MobileNo", messagecustid);
//                    inte.putExtra("MailId", EmailID);
//                    inte.putExtra("Contactno", IsMob);
//                    startActivity(inte);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        new Thread() {
//            @Override
//            public void run() {
//                //  final Modal movie = new Modal(idModule,name1,Email,Dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,noOfRows,RoomNos,UserLgin,MobileNo,Entrydate,Paymode,Paymodeno,PayRecdBy,PrePost);
//                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                request.addProperty("UserID", messagecustid);
//
//                //Declare the version of the SOAP request
//                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                envelope.setOutputSoapObject(request);
//                envelope.dotNet = true;
//
//                try {
//                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                    //this is the actual part that will call the webservice
//                    androidHttpTransport.call(SOAP_ACTION1, envelope);
//                    // Get the SoapResult from the envelope body.
//                    SoapObject result = (SoapObject) envelope.bodyIn;
//
//                    if (result != null) {
//                        //Get the first property and change the label text
//                        SubmitRes = result.getProperty(0).toString();
//                        ////////to replace spaces
//                        String str1=SubmitRes.replace(" ","");
//                        Log.e(SubmitRes,"Result of grid=");
////                        String str1 = str2.replace(" ", "");
////                        if(progress != null){
////                            progress.dismiss();
////                        }
//                        // Log.e("result =", SubmitRes);
//                        runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                try {
//                                    JSONArray jsonArray = new JSONArray(SubmitRes);
////                                    final String[] items = new String[jsonArray.length()];
//                                    Integer Arraylen=jsonArray.length();
//                                    if (jsonArray != null) {
//                                        for (int i = 0; i < jsonArray.length(); i++) {
//                                            JSONObject youValue = jsonArray.getJSONObject(i);
//                                            ////////to replace spaces
//                                            String currentKey = youValue.toString();
//                                            currentKey.trim();
//                                            String str1=currentKey.replace(" ","");
//                                            /////////////////
//                                            idModule = youValue.getString("cust_name");
//                                            name1 = youValue.getString("cust_id");
//                                            Email=youValue.getString("cust_phone");
//                                            Dest_name=youValue.getString("dest_name");
//                                            pay_amount=youValue.getString("pay_amount");
//
//                                            Srno=youValue.getString("NewNo");
//                                            //Srno=youValue.getString(movie.getRoomNos());
//                                            Cat=youValue.getString("unit_name");
//                                            UnitNo=youValue.getString("unit_no");
////                                            String Datefrom=youValue.getString("current_date_from");
////                                            String DateTo=youValue.getString("current_date_to");
//                                            Datefrom=youValue.getString("date_from");
//                                            DateTo=youValue.getString("date_to");
//                                            cnlFrm=youValue.getString("gg");
//                                            SerialNo=youValue.getString("srno");
//                                            UserLgin=messagecustid;
//                                            PrePost=youValue.getString("pp");
//                                            Log.e("gg =", youValue.getString("gg"));
//                                            Log.e("pp =", youValue.getString("pp"));
//                                            RoomNos="";
//                                            if(!youValue.isNull("arrival_date"))
//                                            {
//                                                RoomNos=youValue.getString("arrival_date");
//                                            }
//                                            else
//                                            {
//                                                RoomNos="";
//                                            }
//                                            Log.e("RoomNos =",RoomNos);
//                                            MobileNo=youValue.getString("Phone");
//                                            Entrydate=youValue.getString("entry_date");
//                                            Paymode=youValue.getString("pay_mode");
//                                            Paymodeno=youValue.getString("pay_mode_no");
//                                            PayRecdBy=youValue.getString("pay_rcvd_by");
//                                            //  String IPaddress=youValue.getString("entry_date");
//                                            String noOfRows=Integer.toString(Arraylen);
//                                            //  Resorts.add(idModule);
//                                            Modal item = new Modal(idModule,name1,Email,Dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo,cnlFrm,SerialNo,noOfRows,RoomNos,UserLgin,MobileNo,Entrydate,Paymode,Paymodeno,PayRecdBy,PrePost);
//                                            mItems.add(item);
//                                        }
//                                    }
//                                    recyclerView = (RecyclerView) findViewById(R.id.myList);
//                                    mAdapter = new RecyclerViewAdapter(mItems);
//                                    recyclerView.setHasFixedSize(true);
//                                    RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
//                                    recyclerView.setLayoutManager(mLayoutManager);
//                                    recyclerView.addItemDecoration(new DividerItemDecoration(testRecyclerAdapter.this, LinearLayoutManager.HORIZONTAL));
//                                    recyclerView.setItemAnimator(new DefaultItemAnimator());
//                                    recyclerView.setAdapter(mAdapter);
//
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                        });
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }.start();
//    }
//
//
//    ///////////////////////////////
//
//
////        mItems = new ArrayList<>();
////        for (int i = 0; i < 10; i++) {
////            mItems.add(new Item());
////        }
////        mRecyclerView = (RecyclerView) this.findViewById(R.id.myList);
////        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
//////        mAdapter = new MyAdapter(mItems);
//////        mRecyclerView.setAdapter(mAdapter);
////    }
//    //////////////////////////////////////////////
//
//    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            if (v.getTag() instanceof MyViewHolder) {
//                MyViewHolder holder = (MyViewHolder) v.getTag();
//                boolean result = holder.expandableLayout.toggleExpansion();
//                Item item = mItems.get(holder.getAdapterPosition());
//                item.isExpand = result ? !item.isExpand : item.isExpand;
//            } else if (v.getTag() instanceof TextViewHolder) {
//                TextViewHolder holder = (TextViewHolder) v.getTag();
//                boolean result = holder.expandableLayout.toggleExpansion();
//                Item item = mItems.get(holder.getAdapterPosition());
//                item.isExpand = result ? !item.isExpand : item.isExpand;
//            }
//        }
//    };
//
//    private ExpandableLayout.OnExpandListener mOnExpandListener = new ExpandableLayout.OnExpandListener() {
//
//        private boolean isScrollingToBottom = false;
//
//        @Deprecated
//        @Override
//        public void onToggle(ExpandableLayout view, View child,
//                             boolean isExpanded) {
//        }
//
//        @Override
//        public void onExpandOffset(ExpandableLayout view, View child,
//                                   float offset, boolean isExpanding) {
//            if (view.getTag() instanceof MyViewHolder) {
//                final MyViewHolder holder = (MyViewHolder) view.getTag();
//                if (holder.getAdapterPosition() == mItems.size() - 1) {
//                    if (!isScrollingToBottom) {
//                        isScrollingToBottom = true;
//                        mRecyclerView.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                isScrollingToBottom = false;
//                                mRecyclerView.scrollToPosition(holder
//                                        .getAdapterPosition());
//                            }
//                        }, 100);
//                    }
//                }
//            }
//        }
//    };
//
//    private class MyAdapter extends
//            RecyclerView.Adapter<RecyclerView.ViewHolder> {
//        private List<Item> items;
//
//        public MyAdapter(List<Item> infos) {
//            this.items = infos;
//        }
//
//        @Override
//        public int getItemCount() {
//            return items.size();
//        }
//
//        @Override
//        public int getItemViewType(int position) {
//            if (position == 1) {
//                return TYPE_TEXT_VIEW;
//            } else {
//                return TYPE_IMAGE_VIEW;
//            }
//        }
//
//        @Override
//        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent,
//                                                          int viewType) {
//            if (viewType == TYPE_IMAGE_VIEW) {
//                LayoutInflater inflater = LayoutInflater.from(parent
//                        .getContext());
//            View itemView = LayoutInflater.from(parent.getContext())
//                    .inflate(R.layout.activity_listview, parent, false);
//
//            return new MyViewHolder(itemView);
//
//
//            } else {
//                LayoutInflater inflater = LayoutInflater.from(parent
//                        .getContext());
//                View itemView = inflater.inflate(
//                        R.layout.expandablecanceldetail, parent, false);
//                TextViewHolder holder = new TextViewHolder(itemView);
//                holder.textView.setOnClickListener(mOnClickListener);
//                holder.textView.setTag(holder);
//                holder.expandableLayout.setTag(holder);
//                holder.expandableLayout.setOnExpandListener(mOnExpandListener);
//                return holder;
//            }
//        }
//
//        @Override
//        public void onBindViewHolder(RecyclerView.ViewHolder holder,
//                                     int position) {
//            Modal movie = movieList.get(position);
//            if (holder instanceof MyViewHolder) {
//                MyViewHolder viewHolder = (MyViewHolder) holder;
//                Item item = items.get(position);
//                viewHolder.expandableLayout.setExpanded(item.isExpand, false);
//            } else {
//                TextViewHolder viewHolder = (TextViewHolder) holder;
//                Item item = items.get(position);
//                viewHolder.expandableLayout.setExpanded(item.isExpand, false);
//                viewHolder.textView
//                        .setText("TextView Example\nTextView Example\nTextView Example\nTextView Example");
//                viewHolder.expandableTextView
//                        .setText(movie.getCat());
//            }
//        }
//    }
//
//    class MyViewHolder extends RecyclerView.ViewHolder {
//        ExpandableLayout expandableLayout;
//        ImageView imageView;
//
//        public MyViewHolder(View view) {
//            super(view);
//            title = (TextView) view.findViewById(R.id.Custname);
//            genre = (TextView) view.findViewById(R.id.CustAdd);
//            year = (TextView) view.findViewById(R.id.Email);
//            dest_name=(TextView) view.findViewById(R.id.destname);
//            pay_amount1=(TextView) view.findViewById(R.id.pay_amount);
//            noofunits1=(TextView) view.findViewById(R.id.noofunits);
//            Srno1=(TextView) view.findViewById(R.id.Srno);
//            Cat1=(TextView) view.findViewById(R.id.Category);
//            UnitNo1=(TextView) view.findViewById(R.id.noofunits);
//            Datefrom1=(TextView) view.findViewById(R.id.checindate);
//            DateTo1=(TextView) view.findViewById(R.id.checkoutdate);
//            CancelBooking=(Button)view.findViewById(R.id.Btn_cancel);
//
//        }
//    }
//
//    static class TextViewHolder extends RecyclerView.ViewHolder {
//        ExpandableLayout expandableLayout;
//        TextView textView;
//        TextView expandableTextView;
//
//        public TextViewHolder(View view) {
//            super(view);
//
//            expandableLayout = (ExpandableLayout) itemView
//                    .findViewById(R.id.expandablelayout);
//           TextView cust_id2=(TextView)view.findViewById(R.id.Cust_idView);
//            TextView dateFrom2=(TextView)view.findViewById(R.id.datefrom);
//            TextView dateTo2=(TextView)view.findViewById(R.id.dateto);
//            TextView transactiondate2=(TextView)view.findViewById(R.id.TransactionDate);
//            TextView noofrooms2=(TextView)view.findViewById(R.id.noofroom);
//            TextView unittypeCategory2=(TextView)view.findViewById(R.id.roomCategory);
//            TextView ratePerUnit2=(TextView)view.findViewById(R.id.rateperUnit);
//            TextView refundedAmount2=(TextView)view.findViewById(R.id.refundAmount);
//            TextView  amountPaid2=(TextView)view.findViewById(R.id.totalAmountPaid);
//            TextView Paymode2=(TextView)view.findViewById(R.id.PaymentMode);
//            LinearLayout expandable=(LinearLayout) view.findViewById(R.id.LinearExpand) ;
////            textView = (TextView) itemView.findViewById(R.id.textview);
////            expandableTextView = (TextView) itemView
////                    .findViewById(R.id.expandable_textview);
//        }
//    }
//
//    static class Item {
//        boolean isExpand;
//    }
//}
