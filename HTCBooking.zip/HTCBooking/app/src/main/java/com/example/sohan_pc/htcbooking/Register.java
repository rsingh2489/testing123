//package com.example.sohan_pc.htcbooking;
//
//import android.app.Activity;
//import android.app.ProgressDialog;
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
//import android.text.Editable;
//import android.text.TextWatcher;
//import android.util.Log;
//import android.view.View;
//import android.view.Window;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import org.ksoap2.SoapEnvelope;
//import org.ksoap2.serialization.SoapObject;
//import org.ksoap2.serialization.SoapSerializationEnvelope;
//import org.ksoap2.transport.HttpTransportSE;
//
//import java.util.Timer;
//import java.util.TimerTask;
//
//public class Register extends Activity {
//    private static String SOAP_ACTION1 = "http://tempuri.org/CreateUser";
//    private static String SOAP_ACTION2 = "http://tempuri.org/IsUserExist";
//    private static String NAMESPACE = "http://tempuri.org/";
//    private static String METHOD_NAME1 = "CreateUser";
//    private static String METHOD_NAME2 = "IsUserExist";
//    //  private static String URL = "http://10.89.179.65/haryanatourism/ws_payment.asmx";
//    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
//    private static String abb = "aaa";
//    String GetPwd;
//    ProgressDialog pd;
//    private SoapObject result = null;
//    String GetMobNo,Getuid,UIdStr,Finluser;
//    EditText MobNo_edt,myTextBoxUid,Pswrd ;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
////        getSupportActionBar().hide();
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        setContentView(R.layout.activity_register);
//
//        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);
//
//        Btn_Home.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                try {
//                    Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
//                    startActivity(inte);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        MobNo_edt = (EditText) findViewById(R.id.Edt_MobileNo);
//        MobNo_edt.addTextChangedListener(
//                new TextWatcher() {
//                    @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
//                        EditText myOutputBox = (EditText) findViewById(R.id.Edt_uid);
//                        myOutputBox.setText(s);}
//                    @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
//
//                    private Timer timer=new Timer();
//                    private final long DELAY = 2000; // milliseconds
//
//                    @Override
//                    public void afterTextChanged(final Editable s) {
//                        if (s.length() >= 9) {
//
//                            timer = new Timer();
//                            timer.schedule(new TimerTask() {
//                                @Override
//                                public void run() {
//                                    // TODO: do what you need here (refresh list)
//                                    // you will probably need to use
//                                    // runOnUiThread(Runnable action) for some specific
//                                    // actions
//                                    runOnUiThread(new Runnable() {
//                                        @Override
//                                        public void run() {
//
//
//
//                                            // Call web service
////                                          MobNo_edt = (EditText) findViewById(R.id.Edt_MobileNo);
//                                            final   String Uid=MobNo_edt.getText().toString();
//                                            //=================== ====================
//                                            new Thread() {
//                                                @Override
//                                                public void run() {
//
//
//                                                    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
//                                                    request.addProperty("Userid", Uid);
//
//                                                    //Declare the version of the SOAP request
//                                                    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                                                    envelope.setOutputSoapObject(request);
//                                                    envelope.dotNet = true;
//
//                                                    try {
//                                                        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                                                        //this is the actual part that will call the webservice
//                                                        androidHttpTransport.call(SOAP_ACTION2, envelope);
//                                                        // Get the SoapResult from the envelope body.
//                                                        result = (SoapObject) envelope.bodyIn;
//                                                        ;
//                                                        if (result != null) {
//                                                            //Get the first property and change the label text
//
//                                                            abb = result.getProperty(0).toString();
//
//                                                            runOnUiThread(new Runnable() {
//                                                                @Override
//                                                                public void run() {
//
//                                                                    if (abb.equals("2")) {
//                                                                        myTextBoxUid = (EditText) findViewById(R.id.Edt_uid);
//                                                                        myTextBoxUid.setEnabled(true);
//                                                                        myTextBoxUid.setText("");
//                                                                        myTextBoxUid.setFocusable(true);
//                                                                        myTextBoxUid.setFocusableInTouchMode(true);
//                                                                        myTextBoxUid.requestFocus();
//                                                                        Toast.makeText(Register.this,
//                                                                                "User Already Exists!!Enter User Id Or Login, Or go to Forget password", Toast.LENGTH_LONG)
//                                                                                .show();
//                                                                    } else {
//                                                                        EditText myTextBoxUid = (EditText) findViewById(R.id.Edt_uid);
//                                                                        myTextBoxUid.setEnabled(false);
//                                                                    }
//
//                                                                }
//                                                            });
//
//                                                        } else {
//
//                                                            //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                                                        }
//                                                    } catch (Exception e) {
//
//                                                        e.printStackTrace();
//
//                                                    }
//                                                }
//                                            }.start();
//
//                                        }
//                                    });
//
//                                }
//
//                            }, DELAY);
//                        }
//                    }
//                }
//        );
//
//
//
//    /*    EditText myTextBox = (EditText) findViewById(R.id.Edt_MobileNo);
//        myTextBox.addTextChangedListener(new TextWatcher() {
//            private Timer timer=new Timer();
//            private final long DELAY = 500; // milliseconds
//            public void afterTextChanged(Editable s) {
//                timer.cancel();
//                timer = new Timer();
//                timer.schedule(
//                        new TimerTask() {
//                            @Override
//                            public void run() {
//                                Toast.makeText(Register.this,
//                                        "after text change!!", Toast.LENGTH_LONG)
//                                        .show();
//                                // you will probably need to use runOnUiThread(Runnable action) for some specific actions
//                            }
//                        },
//                        DELAY
//                );
//
//            }
//
//            public void beforeTextChanged(CharSequence s, int start,
//                                          int count, int after) {
//            }
//
//            public void onTextChanged(CharSequence s, int start,
//                                      int before, int count) {
//                EditText myOutputBox = (EditText) findViewById(R.id.Edt_uid);
//                myOutputBox.setText(s);
//          *//*  Toast.makeText(Register.this,
//                    "on text change!!", Toast.LENGTH_LONG)
//                        .show();*//*
//            }
//        });
//*/
//
//
//        //Button Click/////////////////
//        Button button = (Button) findViewById(R.id.BtnRegister);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//
//                ///Validation////////////////////
//                final EditText UName = (EditText) findViewById(R.id.Edt_UserName);
//                final String GetUName = UName.getText().toString();
//                if (GetUName.equals("") || GetUName.equals("0")) {
//                    UName.setError("Enter User Name");
//                    return;
//                }
//                MobNo_edt = (EditText) findViewById(R.id.Edt_MobileNo);
//                GetMobNo = MobNo_edt.getText().toString();
//                if (GetMobNo.length() < 10) {
//                    MobNo_edt.setError("Enter correct Mobile No");
//
//                }
//                if (GetMobNo.equals("") || GetMobNo.equals("0")) {
//                    MobNo_edt.setError("Enter Mobile No");
//                    return;
//                }
//
//                final EditText uid = (EditText) findViewById(R.id.Edt_uid);
//                Getuid = uid.getText().toString();
//                if (GetMobNo.equals("") || GetMobNo.equals("0")) {
//                    MobNo_edt.setError("Enter Mobile No");
//                    return;
//                }
//
//                final EditText Email = (EditText) findViewById(R.id.Edt_EmailId);
//                final String GetEmail = Email.getText().toString();
//                if (GetEmail.equals("") || GetEmail.equals("0")) {
//                    Email.setError("Enter Email Id");
//                    return;
//                }
//                final EditText Pwd = (EditText) findViewById(R.id.Edt_Passwrd);
//                GetPwd = Pwd.getText().toString();
//                if (GetPwd.equals("") || GetPwd.equals("0")) {
//                    Pwd.setError("Enter Password");
//                    return;
//                }
//
//                if (GetMobNo.equals(Getuid)) {
//                    UIdStr = GetMobNo.toString();
//                    Finluser = GetMobNo.toString();
//                } else {
//                    UIdStr = Getuid.toString();
//                    Finluser = Getuid.toString();
//                }
//
//                final EditText EmailId = (EditText) findViewById(R.id.Edt_EmailId);
//
//                final String GetEmailNew = EmailId.getText().toString();
//                String Expn =
//                        "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
//                                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
//                                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
//                                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
//                                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
//                                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";
//
//                if (GetEmailNew.matches(Expn) && GetEmailNew.length() > 0) {
//                   /* EmailId.setText("valid email");*/
//                } else {
//                    EmailId.setError("invalid email");
//                    return;
//                }
//
//
//                Pswrd = (EditText) findViewById(R.id.Edt_Passwrd);
//
//                final String GetPasswrd = Pswrd.getText().toString();
//                String Exppressionn = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
//                if(!GetPasswrd.matches(Exppressionn))
//                {
//                    Pswrd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");
//
//                }
//                pd = new ProgressDialog(Register.this);
//                pd.setTitle("Please Wait....");
//                pd.show();
//
////                         String Exppressionn =
////                        "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,10})";
////
//////                if (GetPwd.matches(Exppressionn) && GetPwd.length() > 0) {
////                 if (!GetPasswrd.matches(Exppressionn)) {
////                     Pswrd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");
////
////
////                   /* EmailId.setText("valid email");*/
////                        }
////                                          else {
////                                              Pswrd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");
////
////                                              return;
////                                          }
//
//
//
//
//
//
////end validation
//
//                // Call web service
//
//
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                        request.addProperty("UserName", GetUName);
//                        request.addProperty("PhoneNo", GetMobNo);
//                        request.addProperty("EmailId", GetEmail);
//                        request.addProperty("Password", GetPwd);
//                        request.addProperty("UserId",UIdStr);
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL,1000*60*2);
//                            androidHttpTransport.debug=true;
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION1, envelope);
//                            // Get the SoapResult from the envelope body.
//                            result = (SoapObject) envelope.bodyIn;
//                            Log.e(String.valueOf(result),"result=======================")
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//                                if(pd != null){
//                                    pd.dismiss();
//                                }
//                                Log.e(abb,"result of create user ");
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//
//                                        if (abb.equals("1")) {
//                                            Intent inte = new Intent(getApplicationContext(), OTPVerification.class);
//                                            inte.putExtra("MobileNo", GetMobNo);
//                                            inte.putExtra("UserName", GetUName);
//                                            inte.putExtra("UserId", Finluser);
//                                            //  inte.putExtra("Username", GetUName);
//                                            //   inte.putExtra("UserId", GetMobNo);
//                                            startActivity(inte);
//                                        } else if(abb.equals("2")){
//                                            Toast.makeText(Register.this,
//                                                    "User already Exists!!", Toast.LENGTH_LONG)
//                                                    .show();
//                                        }else if(abb.equals("3")){
////                                            Toast.makeText(Register.this,
////                                                    "OTP is not verified!!", Toast.LENGTH_LONG)
////                                                    .show();
//                                            Intent inte = new Intent(getApplicationContext(),OTPVerification.class);
//                                            inte.putExtra("MobileNo", GetMobNo);
//                                            inte.putExtra("UserName", GetUName);
//                                            inte.putExtra("UserId", Finluser);
//                                            startActivity(inte);
//                                        }
//
//                                        else {
//                                            Toast.makeText(Register.this,
//                                                    "Registration Unsuccessfull!!", Toast.LENGTH_LONG)
//                                                    .show();
//                                        }
//
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//                //=======================================
//                ///////////////Button Exit
//                //eeeee
//
//            }
//        });
//
//        //On Email AddRess  Change
//       /* final EditText EmailId = (EditText) findViewById(R.id.Edt_EmailId);
//         EmailId.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View v, boolean hasFocus) {
//                final String GetEmail = EmailId.getText().toString();
//                String Expn =
//                        "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
//                                +"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
//                                +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
//                                +"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
//                                +"[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
//                                +"([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";
//
//                if (GetEmail.matches(Expn) && GetEmail.length() > 0)
//                {
//                   *//* EmailId.setText("valid email");*//*
//                }
//                else
//                {
//                    EmailId.setError("invalid email");
//                }
//            }
//
//                    });*/
//    /*    //On Phone Text Change
//        final EditText PHONE = (EditText) findViewById(R.id.Edt_MobileNo);
//        final String GetpHONE = PHONE.getText().toString();
//        PHONE.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View v, boolean hasFocus) {
//
//              *//* gET fOCUS ID------  Toast.makeText(getBaseContext(),
//                        ((EditText) v).getId() + " has focus - " + hasFocus,
//                        Toast.LENGTH_LONG).show();*//*
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
//                      *//*  request.addProperty("UserName", GetUName);
//                        request.addProperty("PhoneNo", GetMobNo);
//                        request.addProperty("EmailId", GetEmail);
//                        request.addProperty("Password", GetPwd);*//*
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION2, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//
//                                        if (abb.equals("1")) {
//                                            Intent inte = new Intent(getApplicationContext(), OTPVerification.class);
//                                         *//*   inte.putExtra("MobileNo", GetMobNo);*//*
//                                            startActivity(inte);
//                                        } else {
//                                            Toast.makeText(Register.this,
//                                                    "Registration Unsuccessfull!!", Toast.LENGTH_LONG)
//                                                    .show();
//                                        }
//
//                                    }
//                                });
//
//                            } else {
//
//                                //Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
//                //=======================================
//            }
//        });*/
//
//        //Redirect Login
//        TextView LogIn= (TextView) findViewById(R.id.LogInLink);
//        LogIn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent inte = new Intent(getApplicationContext(), LoginActivity .class);
//                startActivity(inte);
//            }
//        });
//        //
//
//    }
//
//
//    //
//}
//
