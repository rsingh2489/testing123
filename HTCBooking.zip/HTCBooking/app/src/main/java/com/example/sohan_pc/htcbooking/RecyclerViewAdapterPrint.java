package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.List;

/**
 * Created by Deepak on 6/3/2016.
 */
public class RecyclerViewAdapterPrint extends RecyclerView.Adapter<RecyclerViewAdapterPrint.MyViewHolder>  {
    private List<ModalPrint> modalListP;
    private static String SOAP_ACTION1 = "http://tempuri.org/GetReceipt";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetReceipt";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    ModalPrint mod1;
    public Button PrintBooked;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, year, genre,dest_name,pay_amount,noofunits,Srno,Cat,UnitNo,Datefrom,DateTo;
        public MyViewHolder(final View view) {
            super(view);

            title = (TextView) view.findViewById(R.id.Custname);
            genre = (TextView) view.findViewById(R.id.CustAdd);
            year = (TextView) view.findViewById(R.id.Email);
            dest_name=(TextView) view.findViewById(R.id.destname);
            pay_amount=(TextView) view.findViewById(R.id.pay_amount);
            noofunits=(TextView) view.findViewById(R.id.noofunits);
            Srno=(TextView) view.findViewById(R.id.Srno);
            Cat=(TextView) view.findViewById(R.id.Category);
            UnitNo=(TextView) view.findViewById(R.id.noofunits);
            Datefrom=(TextView) view.findViewById(R.id.checindate);
            DateTo=(TextView) view.findViewById(R.id.checkoutdate);
            PrintBooked=(Button)view.findViewById(R.id.Btn_PrntBookings);


            PrintBooked.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    mod1 = modalListP.get(getAdapterPosition());
                    // Call web service
                    //=================== ====================
                    SoapAccessTask task = new SoapAccessTask();
                    task.execute();
                }
            });

        }
    }


    public RecyclerViewAdapterPrint(List<ModalPrint> modalListP) {
        this.modalListP = modalListP;


    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_list_view_print, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ModalPrint movieP = modalListP.get(position);

        holder.title.setText(movieP.getTitle());
        holder.genre.setText(movieP.getGenre());
        holder.year.setText(movieP.getname());
        holder.dest_name.setText(movieP.getDest_name());
        holder.pay_amount.setText(movieP.getpay_amount());
        holder.noofunits.setText(movieP.getUnitNo());
        holder.Cat.setText(movieP.getCat());
        holder.UnitNo.setText(movieP.getUnitNo());
        holder.Datefrom.setText(movieP.getDatefrom());
        holder.DateTo.setText(movieP.getDateTo());
        holder.Srno.setText(movieP.getSrno());

    }

    @Override
    public int getItemCount() {
        return modalListP.size();
    }


    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("Custid", mod1.getname());
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {

            }
            return webResponse;

        }

        protected void onPreExecute() {
//                            pDialog = new ProgressDialog(RecyclerViewAdapterPrePostPone.this);
//                            pDialog.setMessage("Please Wait ...");
//                            pDialog.setIndeterminate(false);
//                            pDialog.setCancelable(true);
//                            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
//                            pDialog.dismiss();

            if (result != null) {
                SubmitRes = result.toString();

                if (SubmitRes.contains("http://")) {

                    Intent inte = new Intent(PrintBooked.getContext(), webviewprint.class);
                    inte.putExtra("URL", SubmitRes);
                    inte.putExtra("Custid", mod1.getname());
                    inte.putExtra("MailId", mod1.getGenre());
                    inte.putExtra("MobileNo",mod1.getUserLgin());
                    inte.putExtra("Contactno",mod1.getMobileNo());
                    PrintBooked.getContext().startActivity(inte);
                }
            }
        }

    }



}
