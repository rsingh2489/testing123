package com.example.sohan_pc.htcbooking;

/**
 * Created by Deepak on 2/19/2016.
 */

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
public class RecyclerViewAdapter  extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {


    private List<Modal> modalList;
    ProgressDialog pd;


    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView title, year, genre, dest_name, pay_amount, noofunits, Srno, Cat, UnitNo, Datefrom, DateTo;
        public TextView cust_id, preBookfrm,preBookTo,preDatefrm,PreDateto, dateFrom, dateTo, transactiondate, noofrooms, unittypeCategory, ratePerUnit, refundedAmount, amountPaid, Paymode;
        RecyclerViewAdapter thisAdepter;
        public Button CancelBooking;
        LinearLayout linearLayCancelDetail,linearPreBookfrm,linearPrebookTo,linearpreDatefrm,LinearPreDateTo;

        public MyViewHolder(final View view) {
            super(view);

            title = (TextView) view.findViewById(R.id.Custname);
            genre = (TextView) view.findViewById(R.id.CustAdd);
            year = (TextView) view.findViewById(R.id.Email);
            dest_name = (TextView) view.findViewById(R.id.destname);
            pay_amount = (TextView) view.findViewById(R.id.pay_amount);
            noofunits = (TextView) view.findViewById(R.id.noofunits);
            Srno = (TextView) view.findViewById(R.id.Srno);
            Cat = (TextView) view.findViewById(R.id.Category);
            UnitNo = (TextView) view.findViewById(R.id.noofunits);
            Datefrom = (TextView) view.findViewById(R.id.checindate);
            DateTo = (TextView) view.findViewById(R.id.checkoutdate);
            CancelBooking = (Button) view.findViewById(R.id.Btn_cancel);

            ////////////////Already cancelled details////////////
            linearLayCancelDetail = (LinearLayout) view.findViewById(R.id.linearLayCancelDetail);
            linearPreBookfrm=(LinearLayout)view.findViewById(R.id.linearPrebookfrm);
            linearPrebookTo=(LinearLayout)view.findViewById(R.id.linearprebookTo);
            linearpreDatefrm=(LinearLayout)view.findViewById(R.id.linearPreDatefrm);
            LinearPreDateTo=(LinearLayout)view.findViewById(R.id.linearpredateTo);

            cust_id = (TextView) view.findViewById(R.id.Cust_idView);
//            Preponepostpon
            preBookfrm=(TextView) view.findViewById(R.id.prebookfrom);
            preBookTo=(TextView) view.findViewById(R.id.prebookTo);
            preDatefrm=(TextView) view.findViewById(R.id.Predatefrm);
            PreDateto=(TextView) view.findViewById(R.id.PredateTo);

            dateFrom = (TextView) view.findViewById(R.id.datefrom);
            dateTo = (TextView) view.findViewById(R.id.dateto);
            transactiondate = (TextView) view.findViewById(R.id.TransactionDate);
            noofrooms = (TextView) view.findViewById(R.id.noofroom);
            unittypeCategory = (TextView) view.findViewById(R.id.roomCategory);
            ratePerUnit = (TextView) view.findViewById(R.id.rateperUnit);
            refundedAmount = (TextView) view.findViewById(R.id.refundAmount);
            amountPaid = (TextView) view.findViewById(R.id.totalAmountPaid);
            Paymode = (TextView) view.findViewById(R.id.PaymentMode);
            ////////////////End/////////////////////////////////


            //   final Modal mod1 = modalList.get(getAdapterPosition());
            //  final Modal mod = modalList.get(getAdapterPosition());
            CancelBooking.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {

                    final Modal mod1 = modalList.get(getAdapterPosition());

                    // gets hour of day
                    Date date = Calendar.getInstance().getTime();
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    String Newdt = sdf.format(date);
                    String Dt = date.toString();

                    Date dateTody = new Date();   // given date
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(dateTody);   // assigns calendar to given date
                    calendar.get(Calendar.HOUR_OF_DAY); // gets hour in 24h format
                    calendar.get(Calendar.HOUR);        // gets hour in 12h format
                    int ht = calendar.get(Calendar.HOUR_OF_DAY);
                    Calendar rightNow = Calendar.getInstance();
                    int hour = rightNow.get(Calendar.HOUR_OF_DAY);

                    if (mod1.getpay_amount().equals("0")) {

                        //TODO expand on cancel booking to show the details

                        CancelBooking.setText("Already Cancelled");

                        if (linearLayCancelDetail.getVisibility() == View.VISIBLE) {
                            linearLayCancelDetail.setVisibility(View.GONE);
                            linearPreBookfrm.setVisibility(View.GONE);
                            linearPrebookTo.setVisibility(View.GONE);
                            linearpreDatefrm.setVisibility(View.GONE);
                            LinearPreDateTo.setVisibility(View.GONE);
                        } else {
                            linearLayCancelDetail.setVisibility(View.VISIBLE);
                            linearPreBookfrm.setVisibility(View.GONE);
                            linearPrebookTo.setVisibility(View.GONE);
                            linearpreDatefrm.setVisibility(View.GONE);
                            LinearPreDateTo.setVisibility(View.GONE);
                            cancellationActivity cancelDetails=new cancellationActivity();
                            cancelDetails.showcancelDetails(mod1.getname(), cust_id,preBookfrm,preBookTo,preDatefrm,PreDateto, dateFrom, dateTo,transactiondate, noofrooms, unittypeCategory, ratePerUnit, refundedAmount
                                    ,amountPaid, Paymode);
                        }
                        ////call class method to show the details

                        return;
                    }

                    if (mod1.getpp().equals("1")) {

                        CancelBooking.setText("Already Pre/Postponed");
                        linearLayCancelDetail.setVisibility(View.VISIBLE);
                        cancellationActivity cancelDetails=new cancellationActivity();
                        cancelDetails.showcancelDetails(mod1.getname(), cust_id,preBookfrm,preBookTo,preDatefrm,PreDateto, dateFrom, dateTo,transactiondate, noofrooms, unittypeCategory, ratePerUnit, refundedAmount
                                ,amountPaid, Paymode);
                        return;
                    }


                    else {
                        pd = new ProgressDialog(CancelBooking.getContext());
                        pd.setTitle("Please Wait....");
                        pd.setCancelable(false);
                        pd.setCanceledOnTouchOutside(false);
                        pd.show();
                        CancelBooking.setText("Cancel");
                        Intent inte = new Intent(CancelBooking.getContext(), CancelBooking.class);
                        inte.putExtra("CustId", mod1.getname());
                        inte.putExtra("destname", mod1.getDest_name());
                        inte.putExtra("SerialNo", mod1.getSerialNo());
                        inte.putExtra("Roomcat", mod1.getCat());
                        inte.putExtra("RomsBooked", mod1.getUnitNo());
                        inte.putExtra("BookingFrm", mod1.getDatefrom());
                        inte.putExtra("BookingTo", mod1.getDateTo());
                        inte.putExtra("CancelFrm", mod1.getcnlFrm());
                        inte.putExtra("AmtPaid", mod1.getpay_amount());
                        inte.putExtra("NoOfRws", mod1.getnoOfRows());
                        inte.putExtra("RoomNo", mod1.getRoomNos());
                        inte.putExtra("UserLogin", mod1.getUserLgin());
                        inte.putExtra("EmailAdd", mod1.getGenre());
                        inte.putExtra("MolieNo", mod1.getMobileNo());
                        inte.putExtra("CustName", mod1.getTitle());
                        inte.putExtra("Entrydate", mod1.getEntrydate());
                        inte.putExtra("PayMode", mod1.getPaymode());
                        inte.putExtra("PaymodeNo", mod1.getPaymodeno());
                        inte.putExtra("PayRecdby", mod1.getPayRecdBy());
                        CancelBooking.getContext().startActivity(inte);
                    }
                }
            });

        }
    }


    ///////////////////////2nd viewholder to fetch details of already cancel  booking
   //TODO Show already cancelled details Work In Progress
//    public class MyViewHolder1 extends RecyclerViewAdapter.MyViewHolder
//    {
//        public TextView cust_id, dateFrom,dateTo,transactiondate,noofrooms,unittypeCategory,ratePerUnit,refundedAmount,amountPaid,Paymode;
//
//        public MyViewHolder1(View view) {
//            super(view);
//
//            cust_id=(TextView)view.findViewById(R.id.Cust_idView);
//            dateFrom=(TextView)view.findViewById(R.id.datefrom);
//            dateTo=(TextView)view.findViewById(R.id.dateto);
//            transactiondate=(TextView)view.findViewById(R.id.TransactionDate);
//            noofrooms=(TextView)view.findViewById(R.id.noofroom);
//            unittypeCategory=(TextView)view.findViewById(R.id.roomCategory);
//            ratePerUnit=(TextView)view.findViewById(R.id.rateperUnit);
//            refundedAmount=(TextView)view.findViewById(R.id.refundAmount);
//            amountPaid=(TextView)view.findViewById(R.id.totalAmountPaid);
//            Paymode=(TextView)view.findViewById(R.id.PaymentMode);
//
//        }
//    }

    /////////////////////end //////////////////////


    public RecyclerViewAdapter(List<Modal> modalList) {
        this.modalList = modalList;


    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_listview, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Modal movie = modalList.get(position);

        holder.title.setText(movie.getTitle());
        holder.genre.setText(movie.getGenre());
        holder.year.setText(movie.getname());
        holder.dest_name.setText(movie.getDest_name());
        holder.pay_amount.setText(movie.getpay_amount());
        holder.noofunits.setText(movie.getUnitNo());
        holder.Cat.setText(movie.getCat());
        holder.UnitNo.setText(movie.getUnitNo());
        holder.Datefrom.setText(movie.getDatefrom());
        holder.DateTo.setText(movie.getDateTo());
        holder.Srno.setText(movie.getSrno());


        //////////bind already cancelled//////////
        holder.cust_id.setText(movie.getCust_id());
        holder.dateFrom.setText(movie.getDateFrom());
        holder.dateTo.setText(movie.getDateT());
        holder.transactiondate.setText(movie.getTransactionDate());
        holder.noofrooms.setText(movie.getNoofRoom());
        holder.unittypeCategory.setText(movie.getUnittypeCategory());
        holder.ratePerUnit.setText(movie.getRatePerUnit());
        holder.refundedAmount.setText(movie.getRefundedAmount());
        holder.amountPaid.setText(movie.getAmountPaid());
        holder.Paymode.setText(movie.getPaymod());
        /////////end//////////////////

    }

    @Override
    public int getItemCount() {
        return modalList.size();
    }


}
