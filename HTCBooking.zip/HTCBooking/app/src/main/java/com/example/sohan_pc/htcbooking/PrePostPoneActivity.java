package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.text.format.Formatter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;

public class PrePostPoneActivity extends Activity {
String messagecustid,destname,Roomcat,RomsBooked,BookingFrm,BookingTo,CustName,NwDtfrm,NwDtTo,ip,Sno,userLogin;
    String DatefrmBooked,DateToBooked,Emal,Mobile,OldBookingfrm,OldBookingTo;
    private EditText fromDateEtxt;
    private EditText toDateEtxt;

    private DatePickerDialog fromDatePickerDialog;
    private DatePickerDialog toDatePickerDialog;

    private SimpleDateFormat dateFormatter;
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "SubmitPrePostpone";
    private static String SOAP_ACTION1 = "http://tempuri.org/SubmitPrePostpone";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    ProgressDialog pDialog;
    // Session Manager Class
    SessionManagement session;
  //TextView PrePostTouristRest,PrePostCategry,PrePostNoofrooms,PrePostBookingfrm,PrePostBookingTo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_pre_post_pone);


        // Session class instance
        session = new SessionManagement(getApplicationContext());

        final TextView CusId = (TextView) findViewById(R.id.PrePostCustID);
        if (getIntent().hasExtra("CustId")) {
            messagecustid = getIntent().getStringExtra("CustId").toString();
            CusId.setText(messagecustid);
        }
        final TextView Resort = (TextView) findViewById(R.id.PrePostTouristRest);
        if (getIntent().hasExtra("DestName")) {
            destname = getIntent().getStringExtra("DestName").toString();
            Resort.setText(destname);
        }
        final TextView Cat = (TextView) findViewById(R.id.PrePostCategry);
        if (getIntent().hasExtra("Category")) {
            Roomcat = getIntent().getStringExtra("Category").toString();
            Cat.setText(Roomcat);
        }
        final TextView roomsBk = (TextView) findViewById(R.id.PrePostNoofrooms);
        if (getIntent().hasExtra("NoOfrooms")) {
            RomsBooked = getIntent().getStringExtra("NoOfrooms").toString();
            roomsBk.setText(RomsBooked);
        }
        final TextView BookFrm = (TextView) findViewById(R.id.PrePostBookingfrm);
        if (getIntent().hasExtra("BookingFrm")) {
            BookingFrm = getIntent().getStringExtra("BookingFrm").toString();
            BookFrm.setText(BookingFrm);

            String myFormat= "dd-MMM-yyyy";
            String finalString = "";
            try {
                DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                Date date = (Date) formatter .parse(BookingFrm);
                SimpleDateFormat newFormat = new SimpleDateFormat(myFormat);
                finalString= newFormat .format(date );
                BookFrm.setText(finalString);
                OldBookingfrm=finalString;
            } catch (Exception e) {
                Toast.makeText(PrePostPoneActivity.this, "Try again after some time", Toast.LENGTH_SHORT).show();

            }

        }
        final TextView BookTo = (TextView) findViewById(R.id.PrePostBookingTo);
        if (getIntent().hasExtra("BookingTo")) {
            BookingTo = getIntent().getStringExtra("BookingTo").toString();
            BookTo.setText(BookingTo);

            String myFormat= "dd-MMM-yyyy";
            String finalString = "";
            try {
                DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                Date date = (Date) formatter .parse(BookingTo);
                SimpleDateFormat newFormat = new SimpleDateFormat(myFormat);
                finalString= newFormat .format(date );
                BookTo.setText(finalString);
                OldBookingTo=finalString;
            } catch (Exception e) {
                Toast.makeText(PrePostPoneActivity.this, "Try again after some time", Toast.LENGTH_SHORT).show();

            }
        }
        final TextView custName = (TextView) findViewById(R.id.PrePostCustName);
        if (getIntent().hasExtra("CustName")) {
            CustName = getIntent().getStringExtra("CustName").toString();
            custName.setText(CustName);
        }
        final EditText NwDtBookFrm = (EditText) findViewById(R.id.edt_PrePostNewDtFrm);
        if (getIntent().hasExtra("BookingFrm")) {
            NwDtfrm = getIntent().getStringExtra("BookingFrm").toString();
            NwDtBookFrm.setText(NwDtfrm);
        }
        final EditText NwDtBookTo = (EditText) findViewById(R.id.edt_PrePostNewDtTo);
        if (getIntent().hasExtra("BookingTo")) {
            NwDtTo = getIntent().getStringExtra("BookingTo").toString();
            NwDtBookTo.setText(NwDtTo);
        }
        if (getIntent().hasExtra("Srno")) {
            Sno = getIntent().getStringExtra("Srno").toString();
                   }

        if (getIntent().hasExtra("UserId")) {
            userLogin = getIntent().getStringExtra("UserId").toString();
                 }
        if (getIntent().hasExtra("EmailId")) {
            Emal = getIntent().getStringExtra("EmailId").toString();
        }
        if (getIntent().hasExtra("MobileNo")) {
          Mobile = getIntent().getStringExtra("MobileNo").toString();
        }
      //  Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        session.checkLogin();
        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    session.logoutUser();
                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(PrePostPoneActivity.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });
        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(), PreponePostponeBooking.class);
                    inte.putExtra("MobileNo", userLogin);
                    inte.putExtra("MailId", Emal);
                    inte.putExtra("Contactno", Mobile);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(PrePostPoneActivity.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });
        dateFormatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.US);

        findViewsById();

        setDateTimeField();

        final Button BtnPrepOstPone = (Button) findViewById(R.id.BtnPrepostPone);
        BtnPrepOstPone.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Call web service

                //==================== ====================

                        //WifiManager wm = (WifiManager) getSystemService(WIFI_SERVICE);
                        ip = getLocalIpAddress();
                        final EditText NwDtFrmBooked = (EditText) findViewById(R.id.edt_PrePostNewDtFrm);
                        DatefrmBooked=NwDtFrmBooked.getText().toString();
                        final EditText NwDtToBooked = (EditText) findViewById(R.id.edt_PrePostNewDtTo);
                        DateToBooked=NwDtToBooked.getText().toString();
                SoapAccessTask task = new SoapAccessTask();
                task.execute();


            }
        });
    }

    ///////////Async task ///////////

    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("NewBookingFrm", DatefrmBooked);
                request.addProperty("NewBookingTo", DateToBooked);
                request.addProperty("BookingFrm", OldBookingfrm);
                request.addProperty("BookingTo", OldBookingTo);
                request.addProperty("CustId", messagecustid);
                request.addProperty("Srno", Sno);
                request.addProperty("userId", userLogin);
                request.addProperty("Ipaddress", ip);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(PrePostPoneActivity.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(PrePostPoneActivity.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                SubmitRes = result.toString();

                        if (SubmitRes.toString().contains("date")) {

                            Toast.makeText(PrePostPoneActivity.this,
                                    SubmitRes, Toast.LENGTH_LONG)
                                    .show();

                        }
                        else if (SubmitRes.equals("1")){
                            Toast.makeText(PrePostPoneActivity.this,
                                    "Booking Date Changed!!", Toast.LENGTH_LONG)
                                    .show();
                            Intent inte = new Intent(getApplicationContext(), PreponePostponeBooking.class);
                            inte.putExtra("MobileNo", userLogin);
                            inte.putExtra("MailId", Emal);
                            inte.putExtra("Contactno", Mobile);
                            startActivity(inte);
                        }
                        else if (SubmitRes.toString().contains("Cancellation")|| SubmitRes.toString().contains("days")){
                            Toast.makeText(PrePostPoneActivity.this,
                                    SubmitRes, Toast.LENGTH_LONG)
                                    .show();
                        }

                        else {
                            Toast.makeText(PrePostPoneActivity.this,
                                    "Some Error Occured.Try Later!!", Toast.LENGTH_LONG)
                                    .show();
                        }
            }
        }}

    /////////End async task//////////

    private void findViewsById() {
        fromDateEtxt = (EditText) findViewById(R.id.edt_PrePostNewDtFrm);
        fromDateEtxt.setInputType(InputType.TYPE_NULL);
        fromDateEtxt.requestFocus();

        toDateEtxt = (EditText) findViewById(R.id.edt_PrePostNewDtTo);
        toDateEtxt.setInputType(InputType.TYPE_NULL);
    }
    private void setDateTimeField() {
        fromDateEtxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == fromDateEtxt) {
                    fromDatePickerDialog.show();
                } else if (v == toDateEtxt) {
                    toDatePickerDialog.show();
                }
            }

        });
        toDateEtxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == fromDateEtxt) {
                    fromDatePickerDialog.show();
                } else if (v == toDateEtxt) {
                    toDatePickerDialog.show();
                }
            }

        });
        // toDateEtxt.setOnClickListener(this);

        final   Integer GetCncldt=Integer.parseInt(BookingFrm.substring( 0, BookingFrm.indexOf("/"))) ;

        final   Integer GetCnclMon=Integer.parseInt(BookingFrm.substring(BookingFrm.indexOf("/") + 1, BookingFrm.lastIndexOf("/")));

        final   Integer  GetCnclYr=Integer.parseInt(BookingFrm.substring(BookingFrm.lastIndexOf("/") + 1, BookingFrm.length()));

        Calendar newCalendar = Calendar.getInstance();
        newCalendar.set(GetCnclYr,GetCnclMon-1,GetCncldt);
        fromDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(Calendar.YEAR, year);
                newDate.set(Calendar.MONTH, monthOfYear);
                newDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                // Log.e("newDate =", newDate.toString());
                //  newDate.set(GetCnclYr, GetCnclMon, GetCncldt);
                //  Log.e("newDate =", newDate.toString());
                fromDateEtxt.setText(dateFormatter.format(newDate.getTime()));

            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        String myFormat = "dd-MMM-yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        fromDateEtxt.setText(sdf.format(newCalendar.getTime()));
        newCalendar.add(Calendar.DATE, 1);
        toDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                toDateEtxt.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
        String myFormatTo = "dd-MMM-yyyy"; //In which you need put here
        SimpleDateFormat sdfTo = new SimpleDateFormat(myFormatTo, Locale.US);
        toDateEtxt.setText(sdfTo.format(newCalendar.getTime()));
    }

    public void onClick(View view) {
        if (view == fromDateEtxt) {
            fromDatePickerDialog.show();
        } else if (view == toDateEtxt) {
            toDatePickerDialog.show();
        }
    }
    public String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        String ip = Formatter.formatIpAddress(inetAddress.hashCode());
                        return ip;
                    }
                }
            }
        } catch (SocketException ex) {
            Toast.makeText(PrePostPoneActivity.this, "Try again after some time", Toast.LENGTH_SHORT).show();

        }
        return null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_pre_post_pone, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
