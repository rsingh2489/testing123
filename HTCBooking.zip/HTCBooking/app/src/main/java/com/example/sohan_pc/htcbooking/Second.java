//package com.example.sohan_pc.htcbooking;
//
//import android.accounts.Account;
//import android.accounts.AccountManager;
//import android.app.ProgressDialog;
//import android.content.Intent;
//import android.os.Handler;
//import android.support.annotation.NonNull;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.Button;
//import android.widget.TextView;
//
//
//public class Second extends AppCompatActivity {
////    SmsVerifyCatcher smsVerifyCatcher;
//    TextView txtValue;
//    ProgressDialog pd;
//    String actype;
//    String phoneNumber, OtpValue;
//
//    private static int SPLASH_TIME_OUT = 10000;
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_second);
///
//        OtpValue = getIntent().getStringExtra("OtpValue");
//
//        txtValue=(TextView)findViewById(R.id.txtValue);
//
//        pd = new ProgressDialog(Second.this);
//        pd.setTitle("Retriving OTP. Please Wait....");
//        pd.setCancelable(false);
//        pd.setCanceledOnTouchOutside(false);
//        pd.show();
//
//        new Handler().postDelayed(new Runnable() {
//
//            /*
//             * Showing splash screen with a timer. This will be useful when you
//             * want to show case your app logo / company
//             */
//
//            @Override
//            public void run() {
//                if (pd != null) {
//                    pd.dismiss();
//                }
//
//                txtValue.setText(OtpValue);
//
//
//            }
//        }, SPLASH_TIME_OUT);
//
//        /*smsVerifyCatcher = new SmsVerifyCatcher(this, new OnSmsCatchListener<String>() {
//            @Override
//            public void onSmsCatch(String message) {
//                Log.e("87634521", message);
//                String code = parseCode(message);//Parse verification code
//                Log.e("12345678", code);
//                txtValue.setText(code);//set code in edit text
//                //then you can send verification code to server
//            }
//        });
//
//        smsVerifyCatcher.setPhoneNumberFilter("8699183781");*/
//    }
//
//   /* private String parseCode(String message) {
//        Pattern p = Pattern.compile("\\b\\d{4}\\b");
//        Matcher m = p.matcher(message);
//        String code = "";
//        while (m.find()) {
//            code = m.group(0);
//        }
//        return code;
//    }
//    @Override
//    protected void onStart() {
//        super.onStart();
//        smsVerifyCatcher.onStart();
//    }
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//        smsVerifyCatcher.onStop();
//    }
//
//    *//**
//     * need for Android 6 real time permissions
//     *//*
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        smsVerifyCatcher.onRequestPermissionsResult(requestCode, permissions, grantResults);
//    }*/
//}
