package com.example.sohan_pc.htcbooking;

/**
 * Created by shininghael27 on 21/05/2017.
 */

public interface SmsListner
{
    public void messageReceived(String messageText);
}