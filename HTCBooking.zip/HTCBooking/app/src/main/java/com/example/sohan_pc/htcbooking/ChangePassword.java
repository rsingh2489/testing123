package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChangePassword extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/CheckUserPasswd";
    private static String NAMESPACE = "http://tempuri.org/";
    private  static  String METHOD_NAME1="CheckUserPasswd";
    private static String SOAP_ACTION2 = "http://tempuri.org/UpdateForgetPassword";
    private  static  String METHOD_NAME2="UpdateForgetPassword";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String abb = "aaa";
    String EmailID,IsMob,PhoneNo;
    String GetPwd,GetMob;
    EditText Pwd;
    String GetPswrd;
    ProgressDialog pDialog;
    private Pattern pattern;
    private Matcher matcher;

    private static final String PASSWORD_PATTERN =
            "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";

    // Session Manager Class
    SessionManagement session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_change_password);

        // Session class instance
        session = new SessionManagement(getApplicationContext());
         Pwd = (EditText) findViewById(R.id.edt_OldPwdUpd);
        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            if (messageMail.contains("/")) {
                EmailID = messageMail.substring(messageMail.indexOf(",") + 1, messageMail.indexOf("/"));
                IsMob = messageMail.substring(messageMail.indexOf("/") + 1, messageMail.length());
                Pwd.setFocusable(true);
            }
            else
             //   Txtmail.setText(messageMail);
            EmailID=messageMail;
            Pwd.setFocusable(true);
        }

        final EditText LoginEditText = (EditText) findViewById(R.id.edt_loginid);
        final EditText Mob = (EditText) findViewById(R.id.edt_MobNochg);
        if (getIntent().hasExtra("MobileNo")) {
            String messageMbno = getIntent().getStringExtra("MobileNo").toString();
            LoginEditText.setText(messageMbno);
            Mob.setText(messageMbno);
            PhoneNo=messageMbno;
            Mob.setEnabled(false);
            Pwd.setFocusable(true);
        }
        if (getIntent().hasExtra("Contactno")) {

            String messageConctno = getIntent().getStringExtra("Contactno").toString();
            if (messageConctno.equals("1")){
                Pwd.setFocusable(true);
            }
            else
            {
                IsMob=messageConctno;
                Pwd.setFocusable(true);
            }

        }
        session.checkLogin();
        // get user data from session
        HashMap<String, String> user = session.getUserDetails();
        // name
        String name = user.get(SessionManagement.KEY_NAME);

        // email
        String email = user.get(SessionManagement.KEY_EMAIL);

        // mobile
        String mobile = user.get(SessionManagement.KEY_MOBILE);


        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    session.logoutUser();
                   /* Intent inte = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(inte);*/
                } catch (Exception e) {
                    Toast.makeText(ChangePassword.this, "Please try again !!", Toast.LENGTH_SHORT).show();

                }
            }
        });

        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
                    inte.putExtra("MobileNo", PhoneNo);
                    inte.putExtra("MailId", EmailID);
                    inte.putExtra("Contactno", IsMob);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(ChangePassword.this, "Please try again !!", Toast.LENGTH_SHORT).show();

                }
            }
        });




        EditText myTextBox = (EditText) findViewById(R.id.edt_NewPwdUpd);
        myTextBox.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {

            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

                GetPwd = Pwd.getText().toString();
                if (GetPwd.equals("") || GetPwd.equals("0")) {
                    Pwd.setError("Enter Old Password");
                    return;
                }

                // Call web service
                SoapAccessCheckUserPass task = new SoapAccessCheckUserPass();
                task.execute();
//                //=================== ====================
//                new Thread() {
//                    @Override
//                    public void run() {
//
//
//                        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
//                        request.addProperty("PhoneNo", PhoneNo);
//                        request.addProperty("Password", GetPwd);
//
//                        //Declare the version of the SOAP request
//                        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//                        envelope.setOutputSoapObject(request);
//                        envelope.dotNet = true;
//
//                        try {
//                            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//                            //this is the actual part that will call the webservice
//                            androidHttpTransport.call(SOAP_ACTION1, envelope);
//                            // Get the SoapResult from the envelope body.
//                            SoapObject result = (SoapObject) envelope.bodyIn;
//                            ;
//                            if (result != null) {
//                                //Get the first property and change the label text
//
//                                abb = result.getProperty(0).toString();
//
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//
//                                        if (abb.equals("1")) {
//                                            Pwd.setEnabled(false);
//                                           /* Toast.makeText(ChangePassword.this,
//                                                    "Password Matched!!", Toast.LENGTH_LONG)
//                                                    .show();*/
//                                        } else if (abb.equals("2")) {
//                                            Pwd.setFocusable(true);
//                                            Pwd.setError("Incorrect Old Password");
//                                            Toast.makeText(ChangePassword.this,
//                                                    " Old Password Not Matching!!", Toast.LENGTH_LONG)
//                                                    .show();
//
//                                        } else if (abb.equals("4")) {
//                                            Toast.makeText(ChangePassword.this,
//                                                    "Mobile No Not Found!!", Toast.LENGTH_LONG)
//                                                    .show();
//                                        }
//                                    }
//                                });
//
//                            } else {
//
//                                Toast.makeText(getApplicationContext(), "No Response", Toast.LENGTH_LONG).show();
//                            }
//                        } catch (Exception e) {
//
//                            e.printStackTrace();
//
//                        }
//                    }
//                }.start();
                //=======================================
                final EditText myPwd = (EditText) findViewById(R.id.edt_ConfrmMobnoUpd);
                myPwd.addTextChangedListener(new TextWatcher() {

                    public void afterTextChanged(Editable s) {
                       /* EditText myPwdAdd = (EditText) findViewById(R.id.edt_NewPwdUpd);
                        String Pwdnew=myPwdAdd.getText().toString();

                        validate(Pwdnew);*/
                    }

                    public void beforeTextChanged(CharSequence s, int start,
                                                  int count, int after) {
                        EditText myPwdAddd = (EditText) findViewById(R.id.edt_NewPwdUpd);
                        String Pwdnewd = myPwdAddd.getText().toString();
                        String ValidationExpression = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,10})";

                        if (Pwdnewd.matches(ValidationExpression) && Pwdnewd.length() > 0) {

                        } else {
                            myPwdAddd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character..!!");
                            //  myPwdAddd.setError("Password must contain at least one lower case letter, one upper case letter, one digit and one special character");
                            return;
                        }

                    }

                    public void onTextChanged(CharSequence s, int start,
                                              int before, int count) {
                    }
                });
            }
        });


        Button buttonSub = (Button) findViewById(R.id.Btn_SubmitPwd);
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                ///Validation////////////////////
                final EditText UName = (EditText) findViewById(R.id.edt_MobNochg);
                final String GetUName = UName.getText().toString();
                if (GetUName.equals("") || GetUName.equals("0")) {
                    UName.setError("Enter User Id");
                    return;
                }
                final EditText MbNo = (EditText) findViewById(R.id.edt_OldPwdUpd);
                final String GetMobNo = MbNo.getText().toString();
                if (GetMobNo.equals("") || GetMobNo.equals("0")) {
                    MbNo.setError("Enter Old Password");
                    return;
                }
                final EditText Email = (EditText) findViewById(R.id.edt_NewPwdUpd);
                final String GetEmail = Email.getText().toString();
                if (GetEmail.equals("") || GetEmail.equals("0")) {
                    Email.setError("Enter New Password");
                    return;
                }
                final EditText Pwd = (EditText) findViewById(R.id.edt_ConfrmMobnoUpd);
                final String GetPwd = Pwd.getText().toString();
                if (GetPwd.equals("") || GetPwd.equals("0")) {
                    Pwd.setError("Enter Confirm Password");
                    return;
                }

                final EditText Pswrd = (EditText) findViewById(R.id.edt_NewPwdUpd);
                GetPswrd = Pswrd.getText().toString();
                String Expn =
                        "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{8,10})";

                if (GetPswrd.matches(Expn) && GetPswrd.length() > 0) {
                   /* EmailId.setText("valid email");*/
                } else {
                    Pswrd.setError("invalid Password");
                    return;
                }
                EditText myPwdCon = (EditText) findViewById(R.id.edt_ConfrmMobnoUpd);
                String getNewPwdCon = myPwdCon.getText().toString();
             if(GetPswrd.equals(getNewPwdCon)){

             }else
             {
                myPwdCon.setError("Confirm Password Not Matching..!!");
                 return;
             }
/////////////end validation
                // Call web service
                SoapAccessUpdateForgetPass task = new SoapAccessUpdateForgetPass();
                task.execute();
                //=================== ====================

            }
        });
    }

    /////////////check userpass asyctask
    private class SoapAccessCheckUserPass extends AsyncTask<String,Void,String> {
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("PhoneNo", PhoneNo);
                request.addProperty("Password", GetPwd);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(ChangePassword.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }
        protected void onPreExecute() {
            pDialog = new ProgressDialog(ChangePassword.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text
                abb = result.toString();

                        if (abb.equals("1")) {
                            Pwd.setEnabled(false);
                                           /* Toast.makeText(ChangePassword.this,
                                                    "Password Matched!!", Toast.LENGTH_LONG)
                                                    .show();*/
                        } else if (abb.equals("2")) {
                            Pwd.setFocusable(true);
                            Pwd.setError("Incorrect Old Password");
                            Toast.makeText(ChangePassword.this,
                                    " Old Password Not Matching!!", Toast.LENGTH_LONG)
                                    .show();

                        } else if (abb.equals("4")) {
                            Toast.makeText(ChangePassword.this,
                                    "Mobile No Not Found!!", Toast.LENGTH_LONG)
                                    .show();
                        }

            }
    }}

    ///////////////End userpas asynctask


    private class SoapAccessUpdateForgetPass extends AsyncTask<String,Void,String> {
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME2);
                request.addProperty("Password", GetPswrd);
                request.addProperty("PhoneNo", IsMob);
                request.addProperty("Userid", PhoneNo);
                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION2, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(ChangePassword.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;
        }
        protected void onPreExecute() {
            pDialog = new ProgressDialog(ChangePassword.this);
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                abb = result.toString();

                if (abb.equals("1")) {
                    Toast.makeText(ChangePassword.this,
                            "Password Changed Successfully!!", Toast.LENGTH_LONG)
                            .show();
                    Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
                    inte.putExtra("MobileNo", PhoneNo);
                    inte.putExtra("MailId", EmailID);
                    inte.putExtra("Contactno", IsMob);
                    startActivity(inte);
                } else if (abb.equals("2")) {
                    Toast.makeText(ChangePassword.this,
                            "User Doesn't Exists!!", Toast.LENGTH_LONG)
                            .show();
                } else {
                    Toast.makeText(ChangePassword.this,
                            "Some Error occured!!", Toast.LENGTH_LONG)
                            .show();
                }
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_change_password, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
        Intent inte = new Intent(getApplicationContext(), NavigationScreen.class);
        inte.putExtra("MobileNo", PhoneNo);
        inte.putExtra("MailId", EmailID);
        inte.putExtra("Contactno", IsMob);
        startActivity(inte);
    }
}
