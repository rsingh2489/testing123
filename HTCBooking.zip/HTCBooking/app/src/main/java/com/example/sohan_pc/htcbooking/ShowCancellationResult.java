package com.example.sohan_pc.htcbooking;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class ShowCancellationResult extends Activity {
    private static String SOAP_ACTION1 = "http://tempuri.org/GetReceipt";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "GetReceipt";
    private static String URL = "http://web1.hry.nic.in/htcandroidws/ws_payment.asmx";
    private static String SubmitRes = "pp";
    ProgressDialog pDialog;
String CustId,Msg;
    String Mailid,User,Mobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getSupportActionBar().hide();
        setContentView(R.layout.activity_show_cancellation_result);

        if (getIntent().hasExtra("CustId")) {
            String messageCustId = getIntent().getStringExtra("CustId").toString();
            CustId=messageCustId;
                   }
        if (getIntent().hasExtra("msg")) {
            String messageRcd = getIntent().getStringExtra("msg").toString();
            Msg=messageRcd;
        }


        if (getIntent().hasExtra("MailId")) {
            String messageMail = getIntent().getStringExtra("MailId").toString();
            Mailid=messageMail;

        }


        if (getIntent().hasExtra("MobileNo")) {
            String message = getIntent().getStringExtra("MobileNo").toString();
            User=message;

        }

        if (getIntent().hasExtra("Contactno")) {
            String messagecontct = getIntent().getStringExtra("Contactno").toString();
            Mobile=messagecontct;

        }

        final ImageView Btn_Logout=(ImageView) findViewById(R.id.butexit);

        Btn_Logout.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(),LoginActivity .class);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(ShowCancellationResult.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });

        final ImageView Btn_Home=(ImageView) findViewById(R.id.butHome);

        Btn_Home.setOnClickListener(new View.OnClickListener()   {
            public void onClick(View v)  {
                try {
                    Intent inte = new Intent(getApplicationContext(),NavigationScreen .class);
                    inte.putExtra("MobileNo", User);
                    inte.putExtra("MailId", Mailid);
                    inte.putExtra("Contactno", Mobile);
                    startActivity(inte);
                } catch (Exception e) {
                    Toast.makeText(ShowCancellationResult.this, "Try again after some time", Toast.LENGTH_SHORT).show();

                }
            }
        });

        Button but = (Button) findViewById(R.id.Btn_Print_canel);
        but.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // Call web service
                //=================== ====================
                SoapAccessTask task = new SoapAccessTask();
                task.execute();

            }
        });

    }


    ///////////////Async task///
    private class SoapAccessTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String webResponse = "";
            try {
                SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);
                request.addProperty("Custid", CustId);

                //Declare the version of the SOAP request
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                envelope.dotNet = true;
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION1, envelope);
                SoapPrimitive response = (SoapPrimitive) envelope.getResponse();
                webResponse = response.toString();

            } catch (Exception e) {
                Toast.makeText(ShowCancellationResult.this, "Please try again", Toast.LENGTH_SHORT).show();
            }
            return webResponse;

        }

        protected void onPreExecute() {
            pDialog = new ProgressDialog(ShowCancellationResult.this);
                            pDialog.setMessage("Please Wait ...");
                            pDialog.setIndeterminate(false);
                            pDialog.setCancelable(true);
                            pDialog.show();

            super.onPreExecute();
        }

        protected void onPostExecute(String result) {
            pDialog.dismiss();
            if (result != null) {
                //Get the first property and change the label text

                SubmitRes = result.toString();
                Log.e("result =", SubmitRes);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (SubmitRes.contains("http://")) {

                            Intent inte = new Intent(getApplicationContext(), webviewprint.class);
                            inte.putExtra("URL", SubmitRes);
                            inte.putExtra("Custid",CustId);
                            inte.putExtra("MobileNo", User);
                            inte.putExtra("MailId", Mailid);
                            inte.putExtra("Contactno", Mobile);
                            startActivity(inte);

                        }else {
                            Toast.makeText(ShowCancellationResult.this,
                                    "Some Error Occured!!", Toast.LENGTH_LONG)
                                    .show();
                        }
                    }
                });

            }
        }}


    //////////End async task///////////

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_show_cancellation_result, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onBackPressed()
    {
        finish();
        Intent intent = new Intent(ShowCancellationResult.this, cancellationActivity.class);
        intent.putExtra("MobileNo", User);
        intent.putExtra("MailId", Mailid);
        intent.putExtra("Contactno", Mobile);
        startActivity(intent);

    }
}
