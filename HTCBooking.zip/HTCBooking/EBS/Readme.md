*******************
Android EBS Payment gateway
Version : 2.6
Last Update : 05/04/2016
Features:
* Failed Transaction response page customizable
* Payment options customizable

*******************
Android EBS Payment gateway
Version : 2.5
Last Update : 22/12/2015
Features:
* checked for null in sdk for custom post array.

*******************
Android EBS Payment gateway
Version : 2.4
Last Update : 15/12/2015
Features:
* Given Access to receive payment id and entire response to failed transactions

*******************
Android EBS Payment gateway
Version : 2.3
Last Update : 25/11/2015
Features:
* Fixed issue occured during OTP
* Removed web content block. 
*******************

*******************
Android EBS Payment gateway
Version : 2.2
Last Update : 12/11/2015
Features:
* Added log for Merchant Input parameters
* Increased timeout seconds. 
*******************

Android EBS Payment gateway
Version : 2.1
Last Update : 21/10/2015
Features:
* Removed Home configuration page
* Supports Live and demo
* User can post their custom Values.
* Added Failure page and Idle TimeOut 
*******************

Android EBS Payment gateway
Version : 2.0
Last Update : 01/09/2015
Features:
* Added EBS to post md5, sha1,sha512 compatibility
* Supports to Android Studio



*******************
Android EBS Payment gateway
Version : 2.0
Last Update : 21/10/2015
********************
Features:
* Removed Home configuration page
* Supports Live and demo
* User can post their custom Values.
* Added Failure page and Idle TimeOut 


