/** Automatically generated file. DO NOT MODIFY */
package com.ebs.android.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}